package com.deri.proxy.user.dao;

import java.util.HashMap;
import java.util.List;

public interface CompanyDao {
	
	public int selectCompanyListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectCompanyList(HashMap<String, Object> param);
	
	public HashMap<String, Object> selectCompany(HashMap<String, Object> paramHm);
	
}
