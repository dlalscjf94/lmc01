package com.deri.proxy.common.service;

import java.io.UnsupportedEncodingException;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.MimeUtility;

public class SendMailService {

	
	private static String propertie_host = "email.daishin.com";
	private static String propertie_port = "25";
	private static String propertie_user = "ma.deri_governance";
	private static String propertie_pass = "daishin5333!";
	
	public static String propertie_from_name = "대신경제연구소";
	public static String propertie_from = "ma.deri_governance@daishin.com";
	public static String propertie_bcc = "ma.deri_governance@daishin.com";
	
	
	
	public static boolean sendMail2(String to, String title, String msg){
        Properties properties = System.getProperties();
        properties.put("mail.store.protocol", "smtp");
        properties.put("mail.smtp.host", propertie_host);
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.debug", "true");

          Session sessions = Session.getInstance(properties,null);

          MimeMessage message = new MimeMessage(sessions);

          String content = msg;

          try{
           message.setFrom(new InternetAddress(propertie_from));
           message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
           message.setSubject(title);

           message.setContent(content,"text/html;charset=euc-kr");
           Transport transport = sessions.getTransport("smtp");
           transport.connect(propertie_host,propertie_user,propertie_pass);
           transport.sendMessage(message, message.getAllRecipients());
           transport.close();
           
           return true;
          }catch(Exception e){
           e.printStackTrace();
           return false;
          }


        }
	
	
	
	
	
	public static boolean sendMail(String to, String title, String msg) throws UnsupportedEncodingException{
	      String authId = propertie_user;
	      String authPwd = propertie_pass;
	      
	      Properties properties = System.getProperties();
	      properties.put("mail.smtp.port",propertie_port); //tls 를 사용하는지 안하는지에따라 포트번호가 달라질 수 있다.
	      properties.put("mail.smtp.host",propertie_host);
	      properties.put("mail.transport.protocol","smtp");
	      properties.put("mail.smtp.ssl.trust",propertie_host);
	      //properties.put("mail.smtp.starttls.enable", "true"); //tls를 사용하지 않는다면 이부분은 필요 없다.
	      //properties.put("mail.smtp.starttls.required", "true");//tls를 사용하지 않는다면 이부분은 필요 없다.
	      //properties.put("mail.smtp.auth", "true"); //550 [sniper] isn't allowed to relay 오류 발생시 넣어준다. 보내는 메일서버 인증하기 옵션이다.
	    
	    
	      MailAuth auth = new MailAuth (authId, authPwd);
	    
	      Session mailSession = Session.getDefaultInstance(properties, auth);
	      MimeMessage message = new MimeMessage(mailSession);
	      try {
	    	  
	    	  message.setFrom(new InternetAddress(propertie_from, propertie_from_name, "UTF-8"));  
	    	  message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));
	    	  
//	    	  message.addRecipient(Message.RecipientType.BCC, new InternetAddress(propertie_bcc));
	      
	    	  message.setSubject(MimeUtility.encodeText(title, "UTF-8", "B"));  
	    	  String content = msg;
	    	  
	    	  
	    	  
	    	  //첨부파일 처리      
	    	  Multipart multipart = new MimeMultipart();
	    	  MimeBodyPart messageBodyPart = new MimeBodyPart();
	          messageBodyPart = new MimeBodyPart();
/*	          
	          //String file = "path of file to be attached";
	          String fileName = "파일명.확장자";          
	          DataSource source = new FileDataSource(path); //전체 경로
	          messageBodyPart.setDataHandler(new DataHandler(source));
	          messageBodyPart.setFileName(MimeUtility.encodeText(fileName));         
	          multipart.addBodyPart(messageBodyPart);
*/		          
	          
	          MimeBodyPart messageBodyPart2 = new MimeBodyPart();
	          messageBodyPart2 = new MimeBodyPart();      
	          messageBodyPart2.setContent(content, "text/html; charset=utf-8");
	          multipart.addBodyPart(messageBodyPart2);
          
	          
	          
	          message.setContent(multipart);
	    
	          Transport transport=mailSession.getTransport("smtp");
	          transport.connect(propertie_host,authId,authPwd);
	      
	      
	          Address[] add = message.getAllRecipients();      
	      
	          transport.sendMessage(message,add);
	          transport.close();
	    
	          return true;
	      } catch (AddressException e) {
	    	  // TODO Auto-generated catch block
	    	  e.printStackTrace();
	    	  return false;
	      } catch (MessagingException e) {
	    	  // TODO Auto-generated catch block
	    	  e.printStackTrace();
	    	  return false;
	      }
	}
	
}
