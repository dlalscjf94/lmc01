package com.deri.proxy.report.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.deri.common.util.BoardFileVo;
import com.deri.common.util.SessionManager;
import com.deri.common.util.StringUtil;
import com.deri.common.util.PageUtil;
import com.deri.proxy.Define;
import com.deri.proxy.common.service.SendMailService;
import com.deri.proxy.job.service.JobCustomerService;
import com.deri.proxy.job.service.JobService;
import com.deri.proxy.report.service.ReportService;
import com.deri.proxy.user.service.CompanyService;
import com.deri.proxy.user.service.UserService;

/**
 * 
 * 의안분석 보고서 업로드 컨트롤러
 * 
 * @author 
 *
 */
@Controller
public class ReportController {

	private static final Logger logger = LoggerFactory.getLogger(ReportController.class);
	
	@Autowired private ReportService			reportService			= new ReportService();
	@Autowired private JobService				jobService				= new JobService();
	@Autowired private JobCustomerService		jobCustomerService		= new JobCustomerService();
	@Autowired private CompanyService			companyService			= new CompanyService();
	@Autowired private UserService				userService;
	
	String uploadPath = "/resources/upload/report";
	
	/**
	 * 의안분석 목록
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/report"}, method = RequestMethod.GET)
	public String list( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="use_yn", required=false, defaultValue="") String use_yn,
							@RequestParam(value="co_code", required=false, defaultValue="") String co_code,
							@RequestParam(value="jm_code", required=false, defaultValue="") String jm_code,
							@RequestParam(value="jm_name", required=false, defaultValue="") String jm_name,
							
							@RequestParam(value="doc_title_content", required=false, defaultValue="") String doc_title_content,
							
							@RequestParam(value="pageno", required=false, defaultValue="1") String pageno,
				
							@RequestParam(value="pagecount", required=false, defaultValue="10") String pagecount,
							
							Model model	) {
	
		String loginType = SessionManager.getSession(request, "loginType");
		String viewPage = "report";
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		if ( Define.LOGIN_TYPE_C.equals(loginType) ) {
			//고객용
			viewPage = "cust";
			
			co_code = SessionManager.getSession(request, "co_code");
			dbparam.put("co_code", co_code);
			
		} else if ( Define.LOGIN_TYPE_M.equals(loginType) ) {
			//분석담당자
			viewPage = "admin";
		} else if ( Define.LOGIN_TYPE_A.equals(loginType) ) {
			//관리자
			viewPage = "admin";
		}
		viewPage = "report";
		
		
		
		//검색어 처리 영역
		dbparam.put("use_yn", use_yn);
		dbparam.put("co_code", co_code);
		dbparam.put("jm_code", jm_code);
		dbparam.put("jm_name", jm_name);
		dbparam.put("doc_title_content", doc_title_content);
		
		
		
		
		//전체 갯수 및 목록 호출부
		List<HashMap<String, Object>> list;
		int totalcnt = 0;
		Map<String, String> pageMap = new HashMap<String, String>();
		
		totalcnt = reportService.selectReportListCount(dbparam);
		PageUtil.pageSet(Integer.parseInt(pagecount),10);
		
		pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		list = reportService.selectReportList(dbparam);
		
		
		//목록
		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("pageno", pageno);
		model.addAttribute("pageMap", pageMap);
		model.addAttribute("list", list);
		
		
		model.addAttribute("pageno", pageno);
		
		
		//기관목록
		dbparam.clear();
		PageUtil.pageSet(40,10);
		pageMap = PageUtil.getPageStructure(1, 10000);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		model.addAttribute("companyList", companyService.selectCompanyList(dbparam));
		
		
		return "/web/report/"+viewPage+".tiles";
	}
	
	/**
	 * 의안분석 조회
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/report/view"}, method = RequestMethod.GET)
	public String view( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="doc_seq", required=false, defaultValue="") String doc_seq,
							
							Model model	) {
	
		String loginType = SessionManager.getSession(request, "loginType");
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		HashMap<String, Object> content = new HashMap<String, Object>();
		
		if ( Define.LOGIN_TYPE_C.equals(loginType) ) {
			String co_code = SessionManager.getSession(request, "co_code");
			dbparam.put("co_code", co_code);
		}
		
		if ( !"".equals(doc_seq) ) {
			dbparam.put("doc_seq",  doc_seq);
			content = reportService.selectReport(dbparam, false);
		} 

		if ( content == null ) {
			content = new HashMap<String, Object>();
			content.put("error", "Y");
		}
		
		
		boolean isCustomer = false;
		
		if ( Define.LOGIN_TYPE_C.equals(SessionManager.getSession(request, "loginType") ) ) {
			isCustomer = true;
					
			//읽기 카운트 증가하고 로그 쌓는다
			
			String ip = request.getHeader("X-Forwarded-For");
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("Proxy-Client-IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("WL-Proxy-Client-IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("HTTP_CLIENT_IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getRemoteAddr(); 
	    	}
	    	String aip = ip;
	    	
	    	//처리 결과를 입력한다.
			HashMap<String, Object> resultHm = new HashMap<String, Object>();
			if ( isCustomer ) {
				//고객의 경우 Log 쌓기.
				reportService.updateReportReadCnt(dbparam);	
				//	doc_seq, co_code, addr_email, regdate
				resultHm.put("doc_seq", doc_seq);
				resultHm.put("co_code", SessionManager.getSession(request, "co_code"));
				resultHm.put("addr_email", SessionManager.getSession(request, "addr_email"));
					
				reportService.insertReportReadCnt(resultHm);
			}
		}
		
		model.addAttribute("content", content);
		
		
		return "/web/report/report_view.tiles";
	}
	
	/**
	 * 의안분석 등록하기/수정하기
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/report/form", "/report/popform"}, method = RequestMethod.GET)
	public String write( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="req_seq", required=false, defaultValue="") String req_seq,
							@RequestParam(value="doc_seq", required=false, defaultValue="") String doc_seq,
							
							Model model	) {
	
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		

		HashMap<String, Object> content = new HashMap<String, Object>();
		if ( !"".equals(doc_seq) ) {
			dbparam.put("doc_seq",  doc_seq);
			content = reportService.selectReport(dbparam, false);
		}
		model.addAttribute("content", content);
		
		
		//1. req_seq 로 미팅 시퀀스등 기본 정보 조회
		
		dbparam.put("req_seq", req_seq);
		HashMap<String, Object> jobCustomer = jobCustomerService.selectJobCustomer(dbparam); //발송대상정보
		
		//2. meet_seq 로 주총 정보 조회
		dbparam.put("meet_seq", jobCustomer.get("meet_seq"));
		dbparam.put("job_type", jobCustomer.get("tem_type"));
		//System.out.println(dbparam);
		HashMap<String, Object> job = jobService.selectJob(dbparam); //주총정보(분석상황포함)
		
		model.addAttribute("jobCustomer", jobCustomer);
		model.addAttribute("job", job);
		
		//이메일 대상 목록
		PageUtil.pageSet(10000,10);
		Map<String, String> pageMap = new HashMap<String, String>();
		pageMap = PageUtil.getPageStructure(1, 10000);
		dbparam.put("co_code", jobCustomer.get("co_code"));
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		model.addAttribute("userList", userService.selectUserList(dbparam));
		
		
		if (request.getRequestURL().indexOf("/report/popform") > -1 ) { // url 로 현재 경로 판단 하여 변수 셋팅
			return "/web/report/report_pop.pop-tiles";
		} else {
			return "/web/report/report_form.tiles";
		}
	}
	
	/**
	 * 의안분석 보고서 프로세스
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = {"/report/proc"}, method = {RequestMethod.GET, RequestMethod.POST})
	public HashMap<String, Object> proc( 	HttpServletRequest request, HttpServletResponse response, 
			
							@RequestParam(value="procMode", required=false, defaultValue="") String procMode,
							@RequestParam(value="doc_seq", required=false, defaultValue="") String doc_seq,
							@RequestParam(value="bef_doc_seq", required=false, defaultValue="") String bef_doc_seq,
							@RequestParam(value="email_yn", required=false, defaultValue="") String email_yn,
									
							@ModelAttribute("BoardFileVo") BoardFileVo files,
			 
							Model model) {
		
		HashMap<String, Object> result = new HashMap<String, Object>();
		
		String boardType = "";
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		String loginId = SessionManager.getSession(request, "loginId");
		dbparam.put("loginId", loginId);
		
		if ( "".equals(loginId)) {
			result.put("result", "false");
			result.put("message", "로그인 정보가 사라졌습니다. 새창으로 다시 로그인하여 주십시요.");
			
			model.addAttribute("result",result);
			return result;
		}
		
		//meet_seq, co_code, doc_title, doc_content, file_sys_nm, file_nm, file_dn_cnt, 
		//,res_first_rcpno, first_rcpno, rcp_no, read_cnt, snum, regdate
		
		String meet_seq = StringUtil.nullToEmpt(request.getParameter("meet_seq"));
		String co_code = StringUtil.nullToEmpt(request.getParameter("co_code"));
		String doc_title = StringUtil.nullToEmpt(request.getParameter("title"));
		String doc_content = StringUtil.nullToEmpt(request.getParameter("content"));
		
		String doc_title_email = StringUtil.nullToEmpt(request.getParameter("title_email"));
		String doc_content_email = StringUtil.nullToEmpt(request.getParameter("content_email"));
		
		String res_first_rcpno = StringUtil.nullToEmpt(request.getParameter("res_first_rcpno"));
		String first_rcpno = StringUtil.nullToEmpt(request.getParameter("first_rcpno"));
		String rcp_no = StringUtil.nullToEmpt(request.getParameter("rcp_no"));
		
		String snum = SessionManager.getSession(request, "snum");
		
		String del_yn = "N";
		
		//디비에 저장하고
		result.put("result", "true");
		
		//결과 화면 RUL
		result.put("url", "");
		
		if ( !"".equals(doc_seq) ) {
			dbparam.put("doc_seq", doc_seq);
		}
		
		dbparam.put("meet_seq", meet_seq);
		dbparam.put("co_code",co_code);
		dbparam.put("doc_title", doc_title);
		dbparam.put("doc_content", doc_content);
		dbparam.put("res_first_rcpno", res_first_rcpno);
		dbparam.put("first_rcpno", first_rcpno);
		dbparam.put("rcp_no", rcp_no);
		dbparam.put("snum", snum);
		
		dbparam.put("del_yn", del_yn);
		
		
		MultipartFile file01 = files.getUploadFile01();
		
		String realPath = request.getSession().getServletContext().getRealPath(uploadPath)+ "/";
		
		int isup = 0;
		try {
			
			if ( file01 != null ) { 
				
				Calendar cal = Calendar.getInstance();
				String fileType = "";//fileName.substring(fileName.lastIndexOf("."), fileName.length());
				String replaceName = "";//cal.getTimeInMillis() + fileType;
				String filesize = "";
				//
				File rPath = new File(realPath); //경로생성
				if ( !rPath.exists() ) {
					rPath.mkdirs(); //디렉토리 생성
				}
				
				if ( file01 != null ) { 
					if ( !file01.isEmpty() ) {
						fileType = file01.getOriginalFilename().substring(file01.getOriginalFilename().lastIndexOf("."), file01.getOriginalFilename().length());
						replaceName = cal.getTimeInMillis() + fileType;
						isup = FileCopyUtils.copy(file01.getInputStream(), new FileOutputStream(realPath+replaceName));
						if ( isup > 0 && !"".equals(file01.getName()) ) {
							dbparam.put("file_sys_nm", replaceName);
							dbparam.put("file_nm", file01.getOriginalFilename());
						}
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			result.put("result", "false");
			result.put("message", "파일 업로드에 실패하였습니다. 다시실행하여 주십시요.");
			
			model.addAttribute("result",result);
			return result;
		}
		
		String message = "";
		
		//프로세싱 영역
		int resultcnt = 0;
		if ( "S".equals(procMode) ) { //글저장
			
			dbparam.put("bef_doc_seq", 0);
			resultcnt = reportService.insertReport(dbparam);
			
			if ( resultcnt == 1 ) message = "등록 완료 되었습니다. ";

			
			if ( "Y".equals(email_yn) ) {
				//이메일 발송 체크됨. 이메일 발송 시작
				//doc_title_email
				//doc_content_email
				//이메일 대상 목록
				PageUtil.pageSet(10000,10);
				Map<String, String> pageMap = new HashMap<String, String>();
				pageMap = PageUtil.getPageStructure(1, 10000);
				dbparam.put("co_code", co_code);
				dbparam.put("pageHeader", pageMap.get("pageHeader"));
				dbparam.put("pageFooter", pageMap.get("pageFooter"));
				List<HashMap<String, Object>> emailList = userService.selectUserList(dbparam);
				
				int cnt = 0;
				String sendListSuccess = "";
				String sendListError = "";
				for ( HashMap<String, Object> ehm : emailList ) {
					boolean isSend = false;
					try {
						isSend = SendMailService.sendMail(""+ehm.get("addr_email"), doc_title_email, doc_content_email);
					} catch (Exception e) {
						e.printStackTrace();
					}
					if (isSend) {
						System.out.println( ehm.get("addr_email") + " email send finish");
						cnt++;
						sendListSuccess += ehm.get("addr_email") + ", ";
					} else {
						System.out.println( ehm.get("addr_email") + "email send error");
						
						sendListError += ehm.get("addr_email") + ", ";
					}
				}
				
				//누구누구에게 발송되었는지 공유메일에 기록 남기기.
				try {
					String doc_content_email_header = "";
					doc_content_email_header += "발송기록 : <br>";
					doc_content_email_header += "  -  성공["+sendListSuccess+"]<br><br>";
					doc_content_email_header += "  -  실패["+sendListError+"]<br><br>";
					
					SendMailService.sendMail("deri_governance@daishin.com", "[CRM 발송기록] ["+co_code+"]" + doc_title_email, doc_content_email_header + doc_content_email);
				} catch (Exception e) { }
				
				message += "이메일 ("+cnt+")건 발송";
			} else {
				message += "이메일 발송 없음";
			}
			
		} else if ( "M".equals(procMode) ) { //글수정
			
			//수정은 기존 컨텐츠를 M 으로 변경하고 새로 insert 한다.
			dbparam.put("bef_doc_seq", bef_doc_seq);
			resultcnt = reportService.insertReport(dbparam);
			
			dbparam.put("del_yn", "M");
			dbparam.put("doc_seq", bef_doc_seq);
			resultcnt = reportService.deleteGbReport(dbparam);
			
			if ( resultcnt == 1 ) message = "수정 등록 완료 되었습니다. ";
			
			
			if ( "Y".equals(email_yn) ) {
				//이메일 발송 체크됨. 이메일 발송 시작
				//doc_title_email
				//doc_content_email
				//이메일 대상 목록
				PageUtil.pageSet(10000,10);
				Map<String, String> pageMap = new HashMap<String, String>();
				pageMap = PageUtil.getPageStructure(1, 10000);
				dbparam.put("co_code", co_code);
				dbparam.put("pageHeader", pageMap.get("pageHeader"));
				dbparam.put("pageFooter", pageMap.get("pageFooter"));
				List<HashMap<String, Object>> emailList = userService.selectUserList(dbparam);
				
				int cnt = 0;
				String sendListSuccess = "";
				String sendListError = "";
				for ( HashMap<String, Object> ehm : emailList ) {
					boolean isSend = false;
					try {
						isSend = SendMailService.sendMail(""+ehm.get("addr_email"), doc_title_email, doc_content_email);
					} catch (Exception e) {
						e.printStackTrace();
					}
					if (isSend) {
						System.out.println( ehm.get("addr_email") + " email send finish");
						cnt++;
						sendListSuccess += ehm.get("addr_email") + ", ";
					} else {
						System.out.println( ehm.get("addr_email") + "email send error");
						
						sendListError += ehm.get("addr_email") + ", ";
					}
				}
				
				//누구누구에게 발송되었는지 공유메일에 기록 남기기.
				try {
					String doc_content_email_header = "";
					doc_content_email_header += "발송기록 : <br>";
					doc_content_email_header += "  -  성공["+sendListSuccess+"]<br><br>";
					doc_content_email_header += "  -  실패["+sendListError+"]<br><br>";
					
					SendMailService.sendMail("deri_governance@daishin.com", "[CRM 발송기록] " + doc_title_email + " 수정등록", doc_content_email_header + doc_content_email);
				} catch (Exception e) { }
				
				message += "이메일 ("+cnt+")건 발송";
			} else {
				message += "이메일 발송 없음";
			}
			
			
		} else if ( "D".equals(procMode) ) { //글삭제
			
			dbparam.put("del_yn", "Y");
			resultcnt = reportService.deleteGbReport(dbparam);
			
			if ( resultcnt == 1 ) message = "삭제 완료 되었습니다. ";
			
		} else if ( "DD".equals(procMode) ) { //글 완전 삭제
			
			resultcnt = reportService.deleteReport(dbparam);
			
			if ( resultcnt == 1 ) message = "완전 삭제 완료 되었습니다. ";
		}
		
		if ( resultcnt == 1 ) {
			result.put("message", message);
				
		} else {
			result.put("resultcnt", "["+resultcnt+"]");
			result.put("result", "false");
			result.put("message", "오류가 발생 하였습니다.");
		}
	
		//프로세스 처리결과
		model.addAttribute("result",result);
		
		return result;
	}
	
	
	//파일 다운로드
	@RequestMapping(value = {"/report/file"}, method = {RequestMethod.GET, RequestMethod.POST})
	protected void fileopen( HttpServletRequest request, HttpServletResponse response,
			
							@RequestParam(value="doc_seq", required=false, defaultValue="") String doc_seq,
							@RequestParam(value="file_nm", required=false, defaultValue="") String file_nm,
							
							@ModelAttribute("BoardFileVo") BoardFileVo param
							) throws Exception {
			  
System.out.println(doc_seq);
System.out.println(file_nm);
		String realPath = request.getSession().getServletContext().getRealPath(uploadPath)+ "/"+param.getBoardType()+"/";
				
		//게시물을 조회하고
				
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		dbparam.put("doc_seq",  doc_seq);
		//dbparam.put("file_nm",  file_nm);
		
		//System.out.println(dbparam);
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm = reportService.selectReport(dbparam, false);
		
		//file_nm 값이 없을경우 어떻게 할 것인가. empty text 파일을 내린다.
		File file = null;
		String fileName = "";
		
		if ( hm == null ) {
			response.setContentType("text/html; utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('잘못된 페이지 요청입니다.1');location.href='#';</script>");
			out.flush();
			return;
		}
		
		//System.out.println(param.getFile_nm());
		//System.out.println(hm.get("file_nm"));
		
		if ( param.getFile_nm().equals(hm.get("file_nm")) ) {
			
			file = new File(realPath + hm.get("file_sys_nm"));
			fileName = String.valueOf(hm.get("file_nm"));
			
		} else {
			
			response.setContentType("text/html; utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('잘못된 페이지 요청입니다.2');location.href='#';</script>");
			out.flush();
			return;
		
		}
		
		//파일 다운로드 로그를 남긴다.
		boolean isCustomer = false;
		
		if ( Define.LOGIN_TYPE_C.equals(SessionManager.getSession(request, "loginType") ) ) {
			isCustomer = true;
		}
		
		if ( file != null ) {
					
			//파일 다운로드 카운트 증가하고 로그 쌓는다
			
			String snum = SessionManager.getSession(request, "snum");
			String addr_email = SessionManager.getSession(request, "addr_email");
			
			
			String ip = request.getHeader("X-Forwarded-For");
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("Proxy-Client-IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("WL-Proxy-Client-IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("HTTP_CLIENT_IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getRemoteAddr(); 
	    	}
	    	String aip = ip;
	    	
	    	
	    	//처리 결과를 입력한다.
			HashMap<String, Object> resultHm = new HashMap<String, Object>();
			if ( isCustomer ) {
				//고객의 경우 Log 쌓기.
				reportService.updateReportDownCnt(dbparam);
				
				//doc_seq, co_code, addr_email, regdate
				resultHm.put("doc_seq", doc_seq);
				resultHm.put("co_code", SessionManager.getSession(request, "co_code"));
				resultHm.put("addr_email", SessionManager.getSession(request, "addr_email"));
				reportService.insertReportDownCnt(resultHm);
				
			}
			
			
			
			
			response.setContentType("application/pdf; utf-8");
			response.setContentLength((int) file.length());
				 
			String userAgent = request.getHeader("User-Agent");
					
			//fileName = java.net.URLEncoder.encode(fileName,"utf-8");
			//fileName = fileName.replace("+"," ");
					
			if ( !"".equals(param.getViewmode()) ) {
				response.setHeader("Content-Disposition", "inline;");
			} else {
				if (userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("Trident") > -1) {   // 					
					fileName = java.net.URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
					response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
				} else {                                                                                             					
					response.setHeader("Content-Disposition", "attachment; filename="  + new String(fileName.getBytes("UTF-8"), "ISO-8859-1").replaceAll("\\+", "\\ ") + ";");
				}
				
				response.setHeader("Content-Transfer-Encoding", "binary");
			}
			
			
			OutputStream out = response.getOutputStream();
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				FileCopyUtils.copy(fis, out);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (fis != null) {
					try {
						fis.close();
					} catch (Exception e) {
					}
				}
			}
			out.flush();
		}
	}
	
}


