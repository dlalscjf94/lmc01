package com.deri.proxy.login.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.login.dao.LoginDao;

@Service
public class LoginService {

	
	@Autowired private LoginDao loginDao;
	
	public HashMap<String,Object> selectUserInfo(HashMap<String,Object> dbparam) {
		
		HashMap<String, Object> result = null;
		
		try {
			
			result = loginDao.selectUserInfo(dbparam);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}

	
	public int insertUserLog(HashMap<String,Object> dbparam) {
		
		int result = 0;
		
		try {
			
			result = loginDao.insertUserLog(dbparam);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	
	public int updateUserPassword(HashMap<String,Object> dbparam) {
		
		int result = 0;
		
		try {
			
			result = loginDao.updateUserPassword(dbparam);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public int updateUserInfo(HashMap<String,Object> dbparam) {
		
		int result = 0;
		
		try {
			
			result = loginDao.updateUserInfo(dbparam);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
	public int updateUserLogin(HashMap<String,Object> dbparam) {
		
		int result = 0;
		
		try {
			
			result = loginDao.updateUserLogin(dbparam);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return result;
	}
	
}
