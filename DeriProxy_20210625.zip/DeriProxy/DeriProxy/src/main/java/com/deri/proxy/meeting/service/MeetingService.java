package com.deri.proxy.meeting.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.meeting.dao.MeetingDao;


@Service
public class MeetingService {

	@Autowired private MeetingDao meetingDao;
	
	
	//목록
	public int selectMeetingListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = meetingDao.selectMeetingListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectMeetingList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = meetingDao.selectMeetingList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	
	//조회
	public HashMap<String, Object> selectMeeting(HashMap<String, Object> param, boolean isread) {
		HashMap<String, Object> result = null;
		try {

			result = meetingDao.selectMeeting(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
			
	
}
