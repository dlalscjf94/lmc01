package com.deri.proxy.user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.deri.common.util.PageUtil;
import com.deri.common.util.PasswordEncoding;
import com.deri.common.util.SHAPasswordEncoder;
import com.deri.common.util.SessionManager;
import com.deri.common.util.StringUtil;
import com.deri.proxy.Define;
import com.deri.proxy.login.service.LoginService;
import com.deri.proxy.user.service.CompanyService;
import com.deri.proxy.user.service.JikService;
import com.deri.proxy.user.service.UserService;

/**
 * 사용자 계정 컨트롤러
 * @author 
 */
@Controller
public class UserController {

	@Autowired private LoginService				loginService;
	@Autowired private UserService				userService;
	@Autowired private CompanyService			companyService;
	@Autowired private JikService				jikService;
	
	
	@RequestMapping(value = { "/user/company", "/user/account", "/user/jik" }, method = RequestMethod.GET)
	public String index( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="use_yn", required=false, defaultValue="") String use_yn,
							@RequestParam(value="co_code", required=false, defaultValue="") String co_code,
							
							@RequestParam(value="addr_email", required=false, defaultValue="") String addr_email,
							
							@RequestParam(value="pageno", required=false, defaultValue="1") String pageno,
				
							@RequestParam(value="pagecount", required=false, defaultValue="10") String pagecount,			
			
							Model model	) {
	
		String retUrl = "";
		
		
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		//검색어 처리 영역
		dbparam.put("use_yn", use_yn);
		dbparam.put("co_code", co_code);
		dbparam.put("addr_email", addr_email);
		
		
		//전체 갯수 및 목록 호출부
		List<HashMap<String, Object>> list;
		int totalcnt = 0;
		Map<String, String> pageMap = new HashMap<String, String>();
		
		
		if (request.getRequestURL().indexOf("/user/company") > -1 ) { // url 로 현재 경로 판단 하여 변수 셋팅
			retUrl = "company";
			
			totalcnt = companyService.selectCompanyListCount(dbparam);
			PageUtil.pageSet(40,10);
			
			pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
			dbparam.put("pageHeader", pageMap.get("pageHeader"));
			dbparam.put("pageFooter", pageMap.get("pageFooter"));
			list = companyService.selectCompanyList(dbparam);
			
		} else if (request.getRequestURL().indexOf("/user/account") > -1 ) { 
			retUrl = "account";
			
			totalcnt = userService.selectUserListCount(dbparam);
			PageUtil.pageSet(Integer.parseInt(pagecount),10);
			
			pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
			dbparam.put("pageHeader", pageMap.get("pageHeader"));
			dbparam.put("pageFooter", pageMap.get("pageFooter"));
			list = userService.selectUserList(dbparam);
			
		} else {
			retUrl = "jik";
			
			totalcnt = jikService.selectJikListCount(dbparam);
			PageUtil.pageSet(Integer.parseInt(pagecount),10);
			
			pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
			dbparam.put("pageHeader", pageMap.get("pageHeader"));
			dbparam.put("pageFooter", pageMap.get("pageFooter"));
			list = jikService.selectJikList(dbparam);
		}
		
		
		
		//목록
		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("pageno", pageno);
		model.addAttribute("pageMap", pageMap);
		model.addAttribute("list", list);
		
		model.addAttribute("pageno", pageno);
		
		
		//기관목록
		dbparam.clear();
		PageUtil.pageSet(40,10);
		pageMap = PageUtil.getPageStructure(1, 10000);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		model.addAttribute("companyList", companyService.selectCompanyList(dbparam));
		
		
		
		return "/web/user/user_"+retUrl+".tiles";
	}
	

	
	
	@RequestMapping(value = {"/user/form"}, method = RequestMethod.GET)
	public String form( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/user/user_form.pop-tiles";
	}
	
	
	@ResponseBody
	@RequestMapping(value = {"/user//user/info_proc"}, method = {RequestMethod.GET, RequestMethod.POST})
	public HashMap<String, Object> passwordProc( 	HttpServletRequest request, HttpServletResponse response, 
	
							@RequestParam(value="input_id", required=false, defaultValue="") String input_id,
							@RequestParam(value="input_password", required=false, defaultValue="") String input_password,
							@RequestParam(value="addr_name", required=false, defaultValue="") String addr_name,
							@RequestParam(value="addr_tel", required=false, defaultValue="") String addr_tel,
							
							Model model	) {
	
		HashMap<String, Object> paramHm = new HashMap<String, Object>();
		HashMap<String, Object> resultHm = new HashMap<String, Object>();
		HashMap<String, Object> messageHm = new HashMap<String, Object>();
		
		messageHm.put("isLogin", "false");
		
		String loginType = "";
		//로그인 처리시 6자리 텍스트면 직원, @ 있으면 고객이다.
		if ( input_id.indexOf("@") > -1 ) {
			loginType = Define.LOGIN_TYPE_C;
		} else if ( input_id.length() == 6 ){
			loginType = Define.LOGIN_TYPE_M;
		}
		
		paramHm.put("gubun", loginType);
		paramHm.put("input_id", input_id);
		
		//login_ip
		//외부망 아이피
		String ip = request.getRemoteAddr();
		//내부망 아이피
		String pip = StringUtil.nullToEmpt(request.getHeader("Proxy-Client-IP"));
		if ( !"".equals(pip) ) {
			paramHm.put("login_ip", pip);
		} else {
			paramHm.put("login_ip", ip);
		}
				
				
		//1. DB 조회한후
		resultHm = loginService.selectUserInfo(paramHm);
		

		//1.1 조회값이 없으면 바로 리턴 한다.
		if ( resultHm == null ) {
			
			messageHm.put("message", "잘못된 사용자 정보입니다.");
			return messageHm;
		}
		 
		//2. 비밀번호를 체크하고
		String dbPassword = "";
		if ( loginType.equals(Define.LOGIN_TYPE_C ) ) {
			dbPassword = StringUtil.nullToEmpt(resultHm.get("addr_pwd")); 
		} else {
			dbPassword = StringUtil.nullToEmpt(resultHm.get("s_pwd"));
		}
		
		paramHm.clear();
		paramHm.put("gubun", loginType);
		paramHm.put("login_type", loginType);
		paramHm.put("login_id", input_id);
		
		//암호화
		SHAPasswordEncoder shaPasswordEncoder = new SHAPasswordEncoder(256);
        shaPasswordEncoder.setEncodeHashAsBase64(true);
        PasswordEncoding passwordEncoding = new PasswordEncoding(shaPasswordEncoder);
        String loginpw_enc = passwordEncoding.encode(input_password);
        boolean match_pw = passwordEncoding.matches(input_password, dbPassword);
        
        String ERROR_MESSAGE_02 = "비밀번호를 확인하시기 바랍니다.";
        
        if ( match_pw == false ) { //비밀번호 불일치
        	messageHm.put("message", ERROR_MESSAGE_02);
			
			//로그인 실패 로그
			//login_type, id_seq, login_time, login_ip, success_yn, bigo			
        	paramHm.put("success_yn","N");
			paramHm.put("bigo", "비밀번호 틀림");
			loginService.insertUserLog(paramHm);
			
			return messageHm;

		} else {
			//비밀번호가 일치하니. 정보를 변경하고 로그인 프로세스를 진행한다 (세션저장)
			//세션저장을 완료하고 메인 프레임을 main 으로 이동시킨다.
			paramHm.put("addr_email", input_id);
			paramHm.put("addr_tel", addr_tel);
			paramHm.put("addr_seq", resultHm.get("addr_seq"));
			//paramHm.put("addr_pwd", loginpw_enc);
		
			int rcnt = loginService.updateUserInfo(paramHm);
			if ( rcnt == 0 ) {
				//업데이트 안됨
				messageHm.put("message", "비밀번호 업데이트에 실패하였습니다.");
			} else {
				//업데이트 됨
				messageHm.put("isLogin", "true");
				messageHm.put("message", "비밀번호가 변경되었습니다.");
				
				HttpSession session  			=  request.getSession();
				resultHm.put("loginType", loginType);
				resultHm.put("addr_tel", addr_tel);
				SessionManager.MakeSession(session, resultHm, StringUtil.nullToEmpt(paramHm.get("login_ip")));
				
				messageHm.put("loginsuccess", "N");
				loginService.updateUserLogin(paramHm);
			}
			
		}
		return messageHm;
	}
	
}
