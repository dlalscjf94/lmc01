package com.deri.proxy.main.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.deri.common.util.PageUtil;
import com.deri.common.util.SessionManager;
import com.deri.proxy.Define;
import com.deri.proxy.proxy.service.ProxyService;
import com.deri.proxy.report.service.ReportService;
import com.deri.proxy.req.service.ReqService;

/**
 * 
 * 홈화면 컨트롤러
 * 
 * 홈 화면
 * 
 * @author 
 *
 */
@Controller
public class MainController {

	@Autowired private ReqService				reqService				= new ReqService();
	@Autowired private ProxyService				proxyService				= new ProxyService();
	@Autowired private ReportService			reportService			= new ReportService();
	
	@RequestMapping(value = {"/main"}, method = RequestMethod.GET)
	public String index( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		String loginType = SessionManager.getSession(request, "loginType");
		
		//로그인 상태에 따라 페이지를 분기한다.
		//고객용 메인 : main_company
		//관리자용 메인 : main_admin
		//분석담당자용 메인 : main_member
		
		String viewPage = "cust";
		
		if ( Define.LOGIN_TYPE_C.equals(loginType) ) {
			//고객용
			viewPage = "cust";
			
			
			HashMap<String, Object> dbparam = new HashMap<String, Object>();
			String co_code = SessionManager.getSession(request, "co_code");
			dbparam.put("co_code", co_code);
			
			Map<String, String> pageMap = new HashMap<String, String>();
			PageUtil.pageSet(5,10);
			pageMap = PageUtil.getPageStructure(1, 10000);
			dbparam.put("pageHeader", pageMap.get("pageHeader"));
			dbparam.put("pageFooter", pageMap.get("pageFooter"));
			
			//요청현황 목록
			model.addAttribute("reqList", reqService.selectReqList(dbparam));
			//요청종목현황 목록
			model.addAttribute("proxyList", proxyService.selectProxyList(dbparam));
			//보고서목록
			model.addAttribute("reportList", reportService.selectReportList(dbparam));
			//Q&A 목록
			
			
			return "/web/main/main_"+viewPage+".tiles";
			
		} else if ( Define.LOGIN_TYPE_M.equals(loginType) ) {
			//분석담당자
			viewPage = "manager";
			
			return "redirect:/job";
			
		} else if ( Define.LOGIN_TYPE_A.equals(loginType) ) {
			//관리자
			viewPage = "admin";
			
			return "redirect:/req";
		} else  {
			
			return "/web/main/main_"+viewPage+".tiles";
		}
		
		
		
		
	}
	
	
	
	
	
	
}
