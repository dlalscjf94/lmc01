package com.deri.proxy.data.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 
 * 데이타 컨트롤러 
 *
 */
@Controller
public class DataController {

	@RequestMapping(value = {"/data"}, method = RequestMethod.GET)
	public String index( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/data/data.tiles";
	}
	
	@RequestMapping(value = {"/data/type"}, method = RequestMethod.GET)
	public String analysis( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/data/type.tiles";
	}
	
	
}
