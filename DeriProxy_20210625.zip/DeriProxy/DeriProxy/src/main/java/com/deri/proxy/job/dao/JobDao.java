package com.deri.proxy.job.dao;

import java.util.HashMap;
import java.util.List;

public interface JobDao {

	///////////////////////////////목록/////////////////////////////////////////////////
	//목록
	public int selectJobListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectJobList(HashMap<String, Object> param);
	
	
	///////////////////////////////조회/////////////////////////////////////////////////
	//조회
	public HashMap<String, Object> selectJob(HashMap<String, Object> param);
	
	
	///////////////////////////////등록/////////////////////////////////////////////////
	//등록
	public int insertJob(HashMap<String, Object> param);
	
	
	///////////////////////////////수정/////////////////////////////////////////////////
	//수정
	public int updateJob(HashMap<String, Object> param);
	
	
	///////////////////////////////삭제/////////////////////////////////////////////////
	//삭제
	public int deleteGbJob(HashMap<String, Object> param);
	
	
	///////////////////////////////완전 삭제/////////////////////////////////////////////////
	//완전 삭제
	public int deleteJob(HashMap<String, Object> param);
	
	
	public int updateJobFinish(HashMap<String, Object> param);
	
	
	public int insertJobFinishLog(HashMap<String, Object> param);
}
