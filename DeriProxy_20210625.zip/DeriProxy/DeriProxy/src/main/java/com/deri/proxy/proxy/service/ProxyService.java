package com.deri.proxy.proxy.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.proxy.dao.ProxyDao;


@Service
public class ProxyService {

	@Autowired private ProxyDao proxyDao;
	
	
	//목록
	public int selectProxyListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = proxyDao.selectProxyListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectProxyList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = proxyDao.selectProxyList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//조회
	public HashMap<String, Object> selectProxy(HashMap<String, Object> param, boolean isread) {
		HashMap<String, Object> result = null;
		try {

			result = proxyDao.selectProxy(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
			
	//등록
	public int insertProxy(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = proxyDao.insertProxy(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//수정
	public int updateProxy(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = proxyDao.updateProxy(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//삭제
	public int deleteGbProxy(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = proxyDao.deleteGbProxy(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//완전 삭제
	public int deleteProxy(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = proxyDao.deleteProxy(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
}
