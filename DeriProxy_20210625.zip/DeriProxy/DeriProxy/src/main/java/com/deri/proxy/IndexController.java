package com.deri.proxy;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 
 * 인덱스 화면 컨트롤러
 * 
 * 홈 화면
 * 
 * @author 
 *
 */
@Controller
public class IndexController {

	@RequestMapping(value = {"/", "/index"}, method = RequestMethod.GET)
	public String index( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		System.out.println("/ index");
		
		boolean isLogin = false;
		
		if ( isLogin ) {
			//	로그인하지 않은 사용자면 로그인 화면으로
			return "redirect:/login";
		} else {
			//	로그인한 사용자면 메인 화면으로
			return "redirect:/main";
		}

	}
	
}