package com.deri.proxy.job.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.job.dao.JobDao;


@Service
public class JobService {

	@Autowired private JobDao jobDao;
	
	
	//목록
	public int selectJobListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobDao.selectJobListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectJobList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = jobDao.selectJobList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//조회
	public HashMap<String, Object> selectJob(HashMap<String, Object> param) {
		HashMap<String, Object> result = null;
		try {

			result = jobDao.selectJob(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
			
	//등록
	public int insertJob(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobDao.insertJob(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//수정
	public int updateJob(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobDao.updateJob(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//삭제
	public int deleteGbJob(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobDao.deleteGbJob(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//완전 삭제
	public int deleteJob(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobDao.deleteJob(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public int updateJobFinish(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobDao.updateJobFinish(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public int insertJobFinishLog(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobDao.insertJobFinishLog(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
}
