package com.deri.proxy;

import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.SocketException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

public class Define {

	public static String DEV_MODE = "devmode";
	public static String DEV_MODE_Y = "Y";
	public static String DEV_MODE_N = "N";
    
	public static boolean IS_DEV_MODE = false;
	
	public static String SERVER_IP = "";
	
	public static String LOGIN_TYPE = "";
	public static String LOGIN_TYPE_C = "C"; //"Customer";
	public static String LOGIN_TYPE_M = "M"; //"Manager";
	public static String LOGIN_TYPE_A = "A"; //"Admin";
	
	public static String LOGIN_ID = "";
	public static String LOGIN_NAME = "";
	
	public static void setLoginValue(HttpServletRequest request) {
		
		/*
		LOGIN_TYPE = "C";
		LOGIN_ID = "tester";
		LOGIN_NAME = "테스트";
		*/
		
		//LOGIN_TYPE = SessionManager.getSession(request, "snum");
		
		
		
	}
	
	/**
	 * 현재 서버의 IP 주소를 가져옵니다.
	 * 
	 * @return IP 주소
	 */
	public static String getLocalServerIp()
	{
		try
		{
		    for (Enumeration<NetworkInterface> en = NetworkInterface.getNetworkInterfaces(); en.hasMoreElements();)
		    {
		        NetworkInterface intf = en.nextElement();
		        for (Enumeration<InetAddress> enumIpAddr = intf.getInetAddresses(); enumIpAddr.hasMoreElements();)
		        {
		            InetAddress inetAddress = enumIpAddr.nextElement();
		            if (!inetAddress.isLoopbackAddress() && !inetAddress.isLinkLocalAddress() && inetAddress.isSiteLocalAddress())
		            {
		            	return inetAddress.getHostAddress().toString();
		            }
		        }
		    }
		}
		catch (SocketException ex) {}
		return null;
	}
	
}
