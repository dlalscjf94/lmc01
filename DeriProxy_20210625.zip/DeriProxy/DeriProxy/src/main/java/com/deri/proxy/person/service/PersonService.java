package com.deri.proxy.person.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.person.dao.PersonDao;

@Service
public class PersonService {

	
	@Autowired private PersonDao personDao;
	
	
	//목록
	public int selectPersonListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = personDao.selectPersonListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectPersonList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = personDao.selectPersonList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//인물 조회
	public HashMap<String, Object> selectPerson(HashMap<String, Object> param) {
		HashMap<String, Object> result = null;
		try {

			result = personDao.selectPerson(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	//인물 소속 기업 정보 목록
	public List<HashMap<String, Object>> selectPersonCompanyGeneralInfo(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = personDao.selectPersonCompanyGeneralInfo(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	//인물 소속 기업 이사회 목록
	public List<HashMap<String, Object>> selectPersonCommitteList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = personDao.selectPersonCommitteList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	/****
	<!-- 임원별 이사회 활동 내역 -->
	<찬반여부> 
	Y : 찬성
	N : 반대
	G : 기권
	J : 제한
	B : 보류
	S : 보완
	X : 보고
	E : 알수없음
	 
	<참석여부>
	Y : 참석
	N : 불참
	X : 보고
	E : 알수없음
	 -->
	****/
	
	//<!-- 경력 리스트 -->
	public List<HashMap<String, Object>> selectPersonCarrerList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = personDao.selectPersonCarrerList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//<!-- 출석률 용 이사회 목록 -->
	public List<HashMap<String, Object>> selectPersonMeetingList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = personDao.selectPersonMeetingList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//<!-- 주총 및 권고의견 목록 -->
	public List<HashMap<String, Object>> selectPersonProxyList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = personDao.selectPersonProxyList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

}
