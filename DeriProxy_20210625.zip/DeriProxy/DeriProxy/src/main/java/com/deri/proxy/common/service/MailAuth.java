package com.deri.proxy.common.service;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

public class MailAuth extends Authenticator {
	String smtpUsername = null;
	String smtpPassword = null;
	public MailAuth(String username, String password) {
		smtpUsername = username;
		smtpPassword = password;
	}
	public PasswordAuthentication getPasswordAuthentication() {
		return new PasswordAuthentication(smtpUsername, smtpPassword);
	}

}
