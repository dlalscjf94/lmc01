package com.deri.proxy.user.dao;

import java.util.HashMap;
import java.util.List;

public interface UserDao {
	
	public int selectUserListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectUserList(HashMap<String, Object> param);
	
	
	public HashMap<String, Object> selectUser(HashMap<String, Object> paramHm);
	
	public int updateUser(HashMap<String, Object> paramHm);
}
