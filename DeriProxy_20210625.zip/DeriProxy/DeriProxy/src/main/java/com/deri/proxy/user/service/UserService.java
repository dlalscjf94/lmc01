package com.deri.proxy.user.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.user.dao.UserDao;


@Service
public class UserService {

	@Autowired private UserDao userDao;
	
	
	//목록
	public int selectUserListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = userDao.selectUserListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectUserList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = userDao.selectUserList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//조회
	public HashMap<String, Object> selectUser(HashMap<String, Object> param, boolean isread) {
		HashMap<String, Object> result = null;
		try {
			result = userDao.selectUser(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	/*
	public int updateUser(HashMap<String, Object> param) {
		int result = 0;
		try {
			userDao.updateUser(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	*/
		
}
