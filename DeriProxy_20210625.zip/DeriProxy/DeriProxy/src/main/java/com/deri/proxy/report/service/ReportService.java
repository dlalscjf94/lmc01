package com.deri.proxy.report.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.report.dao.ReportDao;


@Service
public class ReportService {

	@Autowired private ReportDao reportDao;
	
	
	//목록
	public int selectReportListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reportDao.selectReportListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectReportList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = reportDao.selectReportList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//조회
	public HashMap<String, Object> selectReport(HashMap<String, Object> param, boolean isread) {
		HashMap<String, Object> result = null;
		try {
			
			//조회수 증가 여부 체크
			if ( isread ) {
				reportDao.updateReportReadCnt(param);
			}
			result = reportDao.selectReport(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
			
	//등록
	public int insertReportReadCnt(HashMap<String, Object> param) {
		int result = 0;
		try {
			reportDao.insertReportReadCnt(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public int updateReportReadCnt(HashMap<String, Object> param) {
		int result = 0;
		try {
			reportDao.updateReportReadCnt(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public int insertReportDownCnt(HashMap<String, Object> param) {
		int result = 0;
		try {
			reportDao.insertReportDownCnt(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	public int updateReportDownCnt(HashMap<String, Object> param) {
		int result = 0;
		try {
			reportDao.updateReportDownCnt(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//등록
	public int insertReport(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reportDao.insertReport(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
		
	//수정
	public int updateReport(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reportDao.updateReport(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//삭제
	public int deleteGbReport(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reportDao.deleteGbReport(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//완전 삭제
	public int deleteReport(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reportDao.deleteReport(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
}
