package com.deri.proxy.common.dao;

import java.util.HashMap;
import java.util.List;

public interface CommonDao {

	///////////////////////////////목록/////////////////////////////////////////////////
	//고객목록
	public List<HashMap<String, Object>> selectCoList(HashMap<String, Object> param);
	
	public HashMap<String, Object> selectCo(HashMap<String, Object> param);

	public int insertMessageContent(HashMap<String, Object> param);

}
