package com.deri.common.util;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * @author jangjaeyoung
 *
 */
public class StringUtil {

	public static final String EMPTY_STRING = "";
	public static final String SPACE = " ";
	
	private static final Pattern WHITESPACE_PATTERN = Pattern.compile("(?: |\\u00A0|\\s|[\\s&&[^ ]])\\s*");
	
	public static String trim(final String str) {
        return str == null ? null : str.trim();
    }
	public static String normalizeSpace(final String str) {
        if (str == null) {
            return null;
        }
        return WHITESPACE_PATTERN.matcher(trim(str)).replaceAll(SPACE);
    }
	
	//형변환
	public static int Integer( Object src ) {
		try {
			return Integer.parseInt(String.valueOf(src));
		} catch (Exception e) {
			return 0;
		}
	}
	public static double Double( Object src ) {
		try {
			return Double.parseDouble(String.valueOf(src));
		} catch (Exception e) {
			e.toString();
			return 0;
		}
	}
	
	public static boolean isNullObject( Object src ) {
		if ( src == null )
			return true; 
		else if ( src.equals( "null" ) ) 
			return true;
		else if ( trim(String.valueOf(src)).equals( EMPTY_STRING ) )	//DB 데이터에 엑셀 때문에 empty_string이 공백 한문자가 있을경우
			return true; 
		else 
			return false;
	}
	public static String nullToEmpt( String src ) {
		if ( src == null )
			return EMPTY_STRING; 
		else if ( src.equals( "null" ) ) 
			return EMPTY_STRING; 
		else 
			return trim(src);
	}
	public static String nullToEmpt( Object src ) {
		if ( src == null )
			return EMPTY_STRING; 
		else if ( src.equals( "null" ) ) 
			return EMPTY_STRING; 
		else 
			return trim(String.valueOf(src));
	}
	public static String nullToEmpt( String src, int define ) {
		return nullToEmpt( src, String.valueOf(define) );
	}
	public static String nullToEmpt( String src, String define ) {
		if ( src == null )
			return define; 
		else if ( src.equals( "null" ) )
			return define;
		else if ( EMPTY_STRING.equals( src ) ) 
			return define; 
		else 
			return trim(src);
	}
	public static String nullToEmpt( Object src, String define ) {
		if ( src == null )
			return define; 
		else if ( src.equals( "null" ) )
			return define;
		else if ( EMPTY_STRING.equals( src ) ) 
			return define; 
		else 
			return trim(String.valueOf(src));
	}
	/**
	 * 소숫점 두자리 반올림
	 * @param data
	 * @return
	 */
	public static String getIndexRoundUp(Object data) {
		
		return getIndexRoundUp(data, "2");
		
	}
	//소숫점 반올림
	public static String getIndexRoundUp(Object data, int str) {
		return getIndexRoundUp(data, String.valueOf(str));
	}
	public static String getIndexRoundUp(Object data, String str) {
		
		String result = "";
		String format = ".00";
		
		if ( "0".equals(str)) {
			format = "";
		} else if ( "1".equals(str)) {
			format = ".0";
		} else if ( "2".equals(str)) {
			format = ".00";
		} else if ( "3".equals(str)) {
			format = ".000";
		} else if ( "4".equals(str)) {
			format = ".0000";
		} else if ( "5".equals(str)) {
			format = ".00000";
		} else if ( "6".equals(str)) {
			format = ".000000";
		} else if ( "7".equals(str)) {
			format = ".0000000";
		} else if ( "8".equals(str)) {
			format = ".00000000";
		} else if ( "9".equals(str)) {
			format = ".000000000";
		}
		try {
			data = Double.parseDouble(String.valueOf(data));
			DecimalFormat df = new DecimalFormat("###,##0"+format) ;
			data = Double.parseDouble(String.valueOf(data).replaceAll(",", ""));
			result = df.format(data);
		
		} catch (Exception e) {
			//e.printStackTrace();
			result = "-";
		}
		
		return result;
		
	}
	//소숫점 자르기
	public static String getIndexFloorLength(Object data, int length) {
		String result = "";
		String format = ".00";
		if ( length == 0 ) {
			format = "";
		} else if ( length == 1 ) {
			format = ".0";
		} else if ( length == 2 ) {
			format = ".00";
		} else if ( length == 3 ) {
			format = ".000";
		} else if ( length == 4 ) {
			format = ".000";
		}
		try {

			data = Float.parseFloat(String.valueOf(data));
			DecimalFormat df = new DecimalFormat("###,##0"+format) ;
			data = Double.parseDouble(String.valueOf(data).replaceAll(",", ""));
			result = df.format(data);
			
			
		} catch (Exception e) {
			//e.printStackTrace();
			result = "-";
		}
		
		return result;
	}
	
	public static String getIndexRoundUpAppendStr(Object data, String str) {
		
		String result = "";
		try {
			//String temp = String.valueOf(data);
			DecimalFormat df = new DecimalFormat("###,##0.00") ;
			data = Double.parseDouble(String.valueOf(data).replaceAll(",", ""));
			result = df.format(data);
			result += str;
		} catch (Exception e) {
			result = "-";
		}
		
		return result;
		
	}

	public static String getIndexRoundUpFormat(Object data, String format) {
		
		String result = "";
		try {
			//String temp = String.valueOf(data);
			DecimalFormat df = new DecimalFormat(format) ;
			data = Double.parseDouble(String.valueOf(data).replaceAll(",", ""));
			result = df.format(data);
		
		} catch (Exception e) {
			result = "-";
		}
		
		return result;
		
	}
	public static double getIndexRoundUpDouble(Object data) {
		String result = "";
		try {
			//String temp = String.valueOf(data);
			DecimalFormat df = new DecimalFormat("#####0.00") ;
			data = Double.parseDouble(String.valueOf(data).replaceAll(",", ""));
			result = df.format(data);
		} catch (Exception e) {
			result = "0.0";
		}
		return Double.parseDouble(result);
		
	}
	public static String getMoneyComma(Object data) {
		String result = "";
		try {
			DecimalFormat df = new DecimalFormat("###,###,###,###,###") ;
			data = Double.parseDouble(String.valueOf(data).replaceAll(",", ""));
			result = df.format(data);
		} catch (Exception e) {
			result = "-";
		}
		return result;
		
	}
	public static String getMoneyCommaLength(Object data, int len) {
		String result = "";
		try {
			String lenstr = "";
			if ( len > 0 ) {
				for ( int i = 0; i < len; i++) {
					if ( "".equals(lenstr) ) lenstr = ".";
					
					lenstr += "0";
				}
			}
			DecimalFormat df = new DecimalFormat("###,###,###"+lenstr) ;
			data = Double.parseDouble(String.valueOf(data).replaceAll(",", ""));
			result = df.format(data);
		} catch (Exception e) {
			result = "-";
		}
		return result;
		
	}
	
	/**
	 * 중요도 FA_PRIO
	 * @param data
	 * @return
	 */
	public static String getFaPRIOToIcon(Object data) {
		String result = "";
		try {
			String temp = String.valueOf(data);			
			
			if ( "3".equals(temp) ) { 
				result = "***";
			} else if ( "2".equals(temp) ) {
				result = "**";
			} else if ( "1".equals(temp) ) {
				result = "*";
			}
			
		} catch (Exception e) {
			return "-";
		}
		
		return result;
	}
	
	/**
	 * 방향성
	 * @param data
	 * @return
	 */
	public static String getFaDirToIcon(Object data) {
		
		String result = "";
		try {
			String temp = String.valueOf(data);			
			
			if ( "2".equals(temp) ) { 
				result = "↑";
			} else if ( "1".equals(temp) ) {
				result = "↗";
			} else if ( "0".equals(temp) ) {
				//result = "<div style='font-size:12px;float:left'>-</div>";
				result = "―";
			} else if ( "-1".equals(temp) ) {
				result = "↘";
			} else if ( "-2".equals(temp) ) {
				result = "↓";
			}
			
		} catch (Exception e) {
			return "-";
		}
		
		return result;
		
	}
	
	/**
	 * 
	 * @param data
	 * @return
	 */
	public static String getDateFormatString(Object data, String format) {
		String result = "";
		
		try {
			String temp = String.valueOf(data);
			
			if ( temp.length() > 7 )
				result = temp.substring(0,4) + format + temp.substring(4,6) + format + temp.substring(6,8);
			
		} catch (Exception e) {
			e.printStackTrace();
			return String.valueOf(data);
		}	
		
		return result;
	}
	
	/**
	 * 
	 * @param data
	 * @return
	 */
	public static String getTimeFormatString(Object data, String format) {
		String result = "";
		
		try {
			String temp = String.valueOf(data);
			
			result = temp.substring(0,2) + format + temp.substring(2,4);
			
		} catch (Exception e) {
			e.printStackTrace();
			return String.valueOf(data);
		}	
		
		return result;
	}
	
	
	/**
	 * 
	 */
	public static String getMoneyStr(String data) {
		String result = "";
		
		try {
			
			String temp = String.valueOf(data);
			
			//소숫점 이하는 버린다.
			if ( temp.indexOf(".") > -1 ) {
				temp = temp.substring(0, temp.indexOf("."));
			}
					
			//만원, 천만원, 억원 단위로 파싱.
			if ( temp.length() < 4 ) {
				result = temp + "만원";
			} else { 
				if ( temp.length() == 4 ) {
					result = temp.substring(0,1)+"천"+temp.substring(1,temp.length())+"만원";
				} else if ( temp.length() == 5 ) {
					result = temp.substring(0,1)+"억"+temp.substring(1,2)+"천"+temp.substring(2,temp.length())+"만원";
				} else {
					result = temp.substring(0, temp.length()-4)+"억";
					result += temp.substring(temp.length()-4, temp.length()-3)+"천";
					result += temp.substring(temp.length()-3, temp.length())+"만원";
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace(); 
			return String.valueOf(data);
		}
		
		if ( result.indexOf("0천000만원") > -1 ) result = result.replace("0천000만원", "원");
		else if ( result.indexOf("000만원") > -1 ) result = result.replace("000만원", "만원");
		else if ( result.indexOf("0천") > -1 ) result = result.replace("0천", "");
		
		
		return result;
	}
	
	/**
	 * 
	 */
	public static String getMoneyStrEn(Object obj) {
		return getMoneyStrEn(String.valueOf(obj));
	}
	public static String getMoneyStrEn(String data) {
		String result = "";
		
		try {
			
			String temp = String.valueOf(data);
			
			//소숫점 이하는 버린다.
			if ( temp.indexOf(".") > -1 ) {
				temp = temp.substring(0, temp.indexOf("."));
			}
					
			//만원, 천만원, 억원 단위로 파싱.
			if ( temp.length() < 4 ) {
				result = temp + "만원";
			} else { 
				if ( temp.length() == 4 ) {
					result = temp.substring(0,1)+"천"+temp.substring(1,temp.length())+"만원";
				} else if ( temp.length() == 5 ) {
					result = temp.substring(0,1)+"억"+temp.substring(1,2)+"천"+temp.substring(2,temp.length())+"만원";
				} else {
					result = temp.substring(0, temp.length()-4)+"억";
					result += temp.substring(temp.length()-4, temp.length()-3)+"천";
					result += temp.substring(temp.length()-3, temp.length())+"만원";
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace(); 
			return String.valueOf(data);
		}
		
		if ( result.indexOf("0천000만원") > -1 ) result = result.replace("0천000만원", "원");
		else if ( result.indexOf("000만원") > -1 ) result = result.replace("000만원", "만원");
		else if ( result.indexOf("0천") > -1 ) result = result.replace("0천", "");
		
		
		return result;
	}
	
	public static String replaceBr(String data) {
		return data.replaceAll("\n", "<br/>");
	}
	
	//수익률 계산
	public static String suik(double st, double ed) {
		String result = "";
		double suik = 0.0;
		if ( ed == 0.0 ) {
			result = "-";
		} else {
			suik = ((st / ed - 1 ) * 100);
			result = String.valueOf(suik);
		}
		return result;
	}
	
	//차트의 상하단 컷 라인을 설정한다.
	public static String minMaxRange(int datediff, String y) {
		
		//검색기간에 따라 상하단 범위를 조정한다.
		/*
		일자별 구간		상단	하단
		5000일 이상		400%	-35%
		2000일 이상	4999일 이하	200%	-35%
		1500일 이상	1999일이하	100%	-35%
		1000일 이상	1499일이하	50%	-20%
		700일 이상	999일 이하	35%	-15%
		365일 이상	699일 이하	25%	-10%
		180일 이상	364일 이하	25%	-10%
		90일 이상	179일 이하	15%	-5%
		30일이상	89일 이하	7%	-5%
		30일 미만		5%	-3%
		*/		
		if ( datediff < 30 ) {
			if ( Double.parseDouble(y) > 5.0 ) y = "5";
			if ( Double.parseDouble(y) < -3.0 ) y = "-3";	
		} else if ( datediff >= 30 && datediff < 90) {
			if ( Double.parseDouble(y) > 7.0 ) y = "7";
			if ( Double.parseDouble(y) < -5.0 ) y = "-5";
		} else if ( datediff >= 90 && datediff < 180) {
			if ( Double.parseDouble(y) > 15.0 ) y = "15";
			if ( Double.parseDouble(y) < -5.0 ) y = "-5";
		} else if ( datediff >= 180 && datediff < 365) {
			if ( Double.parseDouble(y) > 25.0 ) y = "25";
			if ( Double.parseDouble(y) < -10.0 ) y = "-10";
		} else if ( datediff >= 365 && datediff < 700) {
			if ( Double.parseDouble(y) > 25.0 ) y = "25";
			if ( Double.parseDouble(y) < -10.0 ) y = "-10";
		} else if ( datediff >= 700 && datediff < 1000) {
			if ( Double.parseDouble(y) > 35.0 ) y = "35";
			if ( Double.parseDouble(y) < -15.0 ) y = "-15";
		} else if ( datediff >= 1000 && datediff < 1500) {
			if ( Double.parseDouble(y) > 50.0 ) y = "50";
			if ( Double.parseDouble(y) < -20.0 ) y = "-20";
		} else if ( datediff >= 1500 && datediff < 2000) {
			if ( Double.parseDouble(y) > 100.0 ) y = "100";
			if ( Double.parseDouble(y) < -35.0 ) y = "-35";
		} else if ( datediff >= 2000 && datediff < 5000) {
			if ( Double.parseDouble(y) > 200.0 ) y = "200";
			if ( Double.parseDouble(y) < -35.0 ) y = "-35";
		} else if ( datediff >= 5000 ) {
			if ( Double.parseDouble(y) > 400.0 ) y = "400";
			if ( Double.parseDouble(y) < -35.0 ) y = "-35";
		}
		
		return y;
	}
	
	public static String substring(Object str, int stIndex, int edIndex) {
		String result = "";
		try {
			result = String.valueOf(str).substring(stIndex, edIndex);
		} catch (Exception e) {
			result = String.valueOf(str);
			e.toString();
			
		}
		return result;
	}
	public static String substring(String str, int stIndex, int edIndex) {
		String result = "";
		try {
			result = str.substring(stIndex, edIndex);
		} catch (Exception e) {
			result = str;
			e.toString();
//			System.out.println("err_substr:"+str);
			
		}
		return result;
	}
	
	public static String[] split(Object str, String define, int size) {
		String[] result = new String[size+1];
		try {
			String[] temp = String.valueOf(str).split(define);
			for ( int i = 0; i <= size; i++ ) {
				result[i] = temp[i];
			}
		} catch (Exception e) {
			e.toString();
		}
		return result;
	}
	public static String[] split(String str, String define, int size) {
		String[] result = new String[size+1];
		try {
			String[] temp = str.split(define);
			for ( int i = 0; i <= size; i++ ) {
				result[i] = temp[i];
			}
		} catch (Exception e) {
			e.toString();
//			System.out.println("err_split:"+str);
//			e.printStackTrace();
		}
		return result;
	}
	
	/**
	* 한글 정 글자 가져오기
	*
	* @param addr 검색어
	* @return 한글 정 글자
	*/
	public static String getSearchKeyword(String addr) {
		String retString = "";
		for (int i = 0; i < addr.length(); i++) {
			if(!isKoreanHead(addr.substring(i, i+1))){
				//	한글 초성 글자가 아니라면 문자열 추가
				retString += addr.substring(i, i+1);
			}
		}
		return retString;
	}
	
	/**
	* 한글 초성 글자 가져오기
	*
	* @param addr 검색어
	* @return 한글 초성 글자
	*/
	public static String getSearchKeywordHead(String addr) {
		String retString = "";
		for (int i = 0; i < addr.length(); i++) {
			if(isKoreanHead(addr.substring(i, i+1))){
				//	한글 초성 글자이면 문자열 추가
				retString = addr.substring(i, i+1);
				break;
			}
		}
		return retString;
	}
	/**
	* 글자가 한글 초성인지 여부 확인
	* @param data 체크할 글자
	* @return 한글여부
	*/
	public static boolean isKoreanHead(String data){
		Pattern p = Pattern.compile("[ㄱ-ㅎ]");
		Matcher m = p.matcher(data);
		if (m.matches()) {
			return true;
		} else {
			// 	System.out.println("not match!");
			return false;
		}
	}
}
