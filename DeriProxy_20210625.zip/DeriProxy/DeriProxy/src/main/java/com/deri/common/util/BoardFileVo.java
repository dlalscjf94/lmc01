package com.deri.common.util;

import org.springframework.web.multipart.MultipartFile;

public class BoardFileVo {

	String boardType = "";
	String idx = "";
	String file_nm = "";
	String viewmode = "";
	
	
	MultipartFile uploadFile01;
	MultipartFile uploadFile02;
	MultipartFile uploadFile03;
	
	
	
	
	
	public String getViewmode() {
		return viewmode;
	}
	public void setViewmode(String viewmode) {
		this.viewmode = viewmode;
	}
	public String getBoardType() {
		return boardType;
	}
	public void setBoardType(String boardType) {
		this.boardType = boardType;
	}
	public String getIdx() {
		return idx;
	}
	public void setIdx(String idx) {
		this.idx = idx;
	}
	public String getFile_nm() {
		return file_nm;
	}
	public void setFile_nm(String file_nm) {
		this.file_nm = file_nm;
	}
	public MultipartFile getUploadFile01() {
		return uploadFile01;
	}
	public void setUploadFile01(MultipartFile uploadFile01) {
		this.uploadFile01 = uploadFile01;
	}
	public MultipartFile getUploadFile02() {
		return uploadFile02;
	}
	public void setUploadFile02(MultipartFile uploadFile02) {
		this.uploadFile02 = uploadFile02;
	}
	public MultipartFile getUploadFile03() {
		return uploadFile03;
	}
	public void setUploadFile03(MultipartFile uploadFile03) {
		this.uploadFile03 = uploadFile03;
	}
	
}
