package com.deri.proxy.req.dao;

import java.util.HashMap;
import java.util.List;

public interface ReqDao {

	///////////////////////////////목록/////////////////////////////////////////////////
	//목록 
	public int selectReqListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectReqList(HashMap<String, Object> param);
	
	
	///////////////////////////////조회/////////////////////////////////////////////////
	//조회 
	public HashMap<String, Object> selectReq(HashMap<String, Object> param);
	public int updateReqReadCnt(HashMap<String, Object> param);
	public int updateReqDownCnt(HashMap<String, Object> param);
	
	
	///////////////////////////////등록/////////////////////////////////////////////////
	//등록 
	public int insertReq(HashMap<String, Object> param);
	
	
	///////////////////////////////수정/////////////////////////////////////////////////
	//수정 
	public int updateReq(HashMap<String, Object> param);
	
	
	///////////////////////////////삭제/////////////////////////////////////////////////
	//삭제 
	public int deleteGbReq(HashMap<String, Object> param);
	
	
	///////////////////////////////완전 삭제/////////////////////////////////////////////////
	//완전 삭제 
	public int deleteReq(HashMap<String, Object> param);
	
	
	
	public int selectRepListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectRepList(HashMap<String, Object> param);
	public int insertRep(HashMap<String, Object> param);


}
