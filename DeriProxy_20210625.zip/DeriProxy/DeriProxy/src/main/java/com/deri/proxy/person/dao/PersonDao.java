package com.deri.proxy.person.dao;

import java.util.HashMap;
import java.util.List;

public interface PersonDao {

	///////////////////////////////목록/////////////////////////////////////////////////
	//목록 - 인물 검색 목록
	public int selectPersonListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectPersonList(HashMap<String, Object> param);


	///////////////////////////////조회/////////////////////////////////////////////////
	//<!-- 인물 조회 -->
	public HashMap<String, Object> selectPerson(HashMap<String, Object> param);
	
	//<!-- 인물 소속 기업 정보 리스트 -->
	public List<HashMap<String, Object>> selectPersonCompanyGeneralInfo(HashMap<String, Object> param);
	//<!-- 인물 소속 기업 소속 이사회 -->
	public List<HashMap<String, Object>> selectPersonCommitteList(HashMap<String, Object> param);
	
	//<!-- 경력 리스트 -->
	public List<HashMap<String, Object>> selectPersonCarrerList(HashMap<String, Object> param);
	
	//<!-- 출석률 용 이사회 목록 -->
	public List<HashMap<String, Object>> selectPersonMeetingList(HashMap<String, Object> param);
	
	//<!-- 주총 및 권고의견 목록 -->
	public List<HashMap<String, Object>> selectPersonProxyList(HashMap<String, Object> param);

}
