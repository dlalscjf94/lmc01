package com.deri.proxy.meeting.dao;

import java.util.HashMap;
import java.util.List;

public interface MeetingDao {

	///////////////////////////////목록/////////////////////////////////////////////////
	//목록
	public int selectMeetingListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectMeetingList(HashMap<String, Object> param);
	
	///////////////////////////////조회/////////////////////////////////////////////////
	//조회
	public HashMap<String, Object> selectMeeting(HashMap<String, Object> param);
	

}
