package com.deri.proxy.user.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.user.dao.JikDao;


@Service
public class JikService {

	@Autowired private JikDao jikDao;
	
	
	//목록
	public int selectJikListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jikDao.selectJikListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectJikList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = jikDao.selectJikList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//조회
	public HashMap<String, Object> selectJik(HashMap<String, Object> param, boolean isread) {
		HashMap<String, Object> result = null;
		try {
			result = jikDao.selectJik(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
		
}
