package com.deri.proxy.req.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.req.dao.ReqDao;


@Service
public class ReqService {

	@Autowired private ReqDao reqDao;
	
	
	//목록
	public int selectReqListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reqDao.selectReqListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectReqList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = reqDao.selectReqList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//조회
	public HashMap<String, Object> selectReq(HashMap<String, Object> param, boolean isread) {
		HashMap<String, Object> result = null;
		try {
			
			//조회수 증가 여부 체크
			if ( isread ) {
				reqDao.updateReqReadCnt(param);
			}
			result = reqDao.selectReq(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
			
	//등록
	public int updateReqDownCnt(HashMap<String, Object> param) {
		int result = 0;
		try {
			reqDao.updateReqDownCnt(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//등록
	public int insertReq(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reqDao.insertReq(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//수정
	public int updateReq(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reqDao.updateReq(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//삭제
	public int deleteGbReq(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reqDao.deleteGbReq(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//완전 삭제
	public int deleteReq(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reqDao.deleteReq(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public int selectRepListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reqDao.selectRepListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectRepList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = reqDao.selectRepList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	public int insertRep(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = reqDao.insertRep(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
