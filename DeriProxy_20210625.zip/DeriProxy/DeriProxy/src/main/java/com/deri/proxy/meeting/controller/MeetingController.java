package com.deri.proxy.meeting.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.deri.common.util.SessionManager;
import com.deri.common.util.PageUtil;
import com.deri.proxy.common.service.CommonService;
import com.deri.proxy.job.service.JobCustomerService;
import com.deri.proxy.job.service.JobService;
import com.deri.proxy.meeting.service.MeetingService;
import com.deri.proxy.proxy.service.ProxyService;
import com.deri.proxy.user.service.CompanyService;

/**
 * 
 * 의안분석 요청 종목 관리 컨트롤러
 * 
 * @author 
 *
 */
@Controller
public class MeetingController {

	private static final Logger logger = LoggerFactory.getLogger(MeetingController.class);
	
	@Autowired private CommonService			commonService				= new CommonService();
	@Autowired private MeetingService			meetingService				= new MeetingService();
	@Autowired private ProxyService				proxyService				= new ProxyService();
	@Autowired private JobService				jobService					= new JobService();
	@Autowired private JobCustomerService		jobCustomerService			= new JobCustomerService();
	@Autowired private CompanyService			companyService				= new CompanyService();
	
	/**
	 * 주주총회 목록 (데이터 수집완료건)
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/meeting"}, method = RequestMethod.GET)
	public String list( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="use_yn", required=false, defaultValue="") String use_yn,
							@RequestParam(value="co_code", required=false, defaultValue="") String co_code,
							@RequestParam(value="jm_code", required=false, defaultValue="") String jm_code,
							@RequestParam(value="jm_name", required=false, defaultValue="") String jm_name,
							@RequestParam(value="pageno", required=false, defaultValue="1") String pageno,
							@RequestParam(value="meet_gb", required=false, defaultValue="") String meet_gb,
							@RequestParam(value="coverage", required=false, defaultValue="") String coverage,

							@RequestParam(value="reg_check", required=false, defaultValue="") String reg_check,
							@RequestParam(value="meet_ymd", required=false, defaultValue="") String meet_ymd,
							
							@RequestParam(value="pagecount", required=false, defaultValue="10") String pagecount,
			
							Model model	) {
	
		String loginType = SessionManager.getSession(request,"loginType");
		String viewPage = "cust";
		
		//System.out.println("loginType:"+loginType + ":" + SessionManager.getSession(request,"loginType"));
		
		
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		//검색어 처리 영역
		dbparam.put("use_yn", use_yn);
		dbparam.put("co_code", co_code);
		dbparam.put("jm_code", jm_code);
		dbparam.put("jm_name", jm_name);
		dbparam.put("meet_gb", meet_gb);
		dbparam.put("coverage", coverage);
		dbparam.put("reg_check", reg_check); //Y 로 들어오면 등록 갯수가 상이한것이다.
		dbparam.put("meet_ymd", meet_ymd);
		
		//전체 갯수 및 목록 호출부
		List<HashMap<String, Object>> list;
		int totalcnt = 0;
		Map<String, String> pageMap = new HashMap<String, String>();
		
		totalcnt = meetingService.selectMeetingListCount(dbparam);
		PageUtil.pageSet(Integer.parseInt(pagecount),10);
		
		pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		list = meetingService.selectMeetingList(dbparam);
		
		
		//목록
		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("pageno", pageno);
		model.addAttribute("pageMap", pageMap);
		model.addAttribute("list", list);
		
		
		model.addAttribute("pageno", pageno);
		
		
		//기관목록
		dbparam.clear();
		PageUtil.pageSet(40,10);
		pageMap = PageUtil.getPageStructure(1, 10000);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		model.addAttribute("companyList", companyService.selectCompanyList(dbparam));
		
		
		return "/web/meeting/meeting.tiles";
	}
	
		
	@RequestMapping(value = {"/meeting/form"}, method = RequestMethod.GET)
	public String write( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="meet_seq", required=false, defaultValue="") String meet_seq,
							
							Model model	) {
	
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		HashMap<String, Object> content = new HashMap<String, Object>();
		if ( !"".equals(meet_seq) ) {
			dbparam.put("meet_seq",  meet_seq);
			content = meetingService.selectMeeting(dbparam, false);
		}
		model.addAttribute("content", content);
		
		//계약기관목록
		model.addAttribute("coList", commonService.selectCoList(dbparam));		
		
		//커버리지목록
		dbparam.put("jm_code", content.get("jm_code"));
		dbparam.put("use_yn", "Y");
		
		List<HashMap<String, Object>> covList = new ArrayList<HashMap<String, Object>>();
		model.addAttribute("covList", proxyService.selectProxyList(dbparam));
		
		List<HashMap<String, Object>> jobCustomerList = new ArrayList<HashMap<String, Object>>();
		if ( !"".equals(meet_seq )) {
			model.addAttribute("jobCustomerList", jobCustomerService.selectJobCustomerList(dbparam));
		} else {
			model.addAttribute("jobCustomerList", jobCustomerList);
		}
		
		dbparam.put("templet_yn", "all");
		dbparam.put("gumsu_yn", "all");
		dbparam.put("an_01_fi", "all");
		dbparam.put("an_02_fi", "all");
		dbparam.put("an_03_fi", "all");
		dbparam.put("an_04_fi", "all");
		dbparam.put("an_05_fi", "all");
		List<HashMap<String, Object>> jobList = new ArrayList<HashMap<String, Object>>();
		model.addAttribute("jobList", jobService.selectJobList(dbparam));
		
		
		return "/web/meeting/meeting_pop.pop-tiles";
	}


}

