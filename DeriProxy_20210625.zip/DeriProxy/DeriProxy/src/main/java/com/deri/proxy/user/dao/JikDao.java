package com.deri.proxy.user.dao;

import java.util.HashMap;
import java.util.List;

public interface JikDao {
	
	public int selectJikListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectJikList(HashMap<String, Object> param);
	
	public HashMap<String, Object> selectJik(HashMap<String, Object> paramHm);
	
}
