package com.deri.proxy.common.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.common.dao.CommonDao;


@Service
public class CommonService {

	@Autowired private CommonDao commonDao;
	
	
	public List<HashMap<String, Object>> selectCoList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = commonDao.selectCoList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
	public HashMap<String, Object> selectCo(HashMap<String, Object> param) {
		HashMap<String, Object> result = null;
		try {
			result = commonDao.selectCo(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	public int insertMessageContent(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = commonDao.insertMessageContent(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
}
