package com.deri.proxy.manage.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 
 * 관리화면 컨트롤러 - 템플릿

 * @author 
 *
 */
@Controller
public class TempletController {

	@RequestMapping(value = {"/manage/templet"}, method = RequestMethod.GET)
	public String index( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/manage/templet.tiles";
	}
	
}
