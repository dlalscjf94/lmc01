package com.deri.common.util;

import java.util.HashMap;
import java.util.Map;

public class PageUtil {

	
	private static int pagerows = 10;
	private static int pageblock = 5;
	
	public static void pageSet ( int pagerowsSet, int pageblockSet) {
		pagerows = pagerowsSet;
		pageblock = pageblockSet;
	}
	public static Map<String, String> getPageStructure(int pageno, int totalcnt) {
		
		Map<String, String> mResult = new HashMap<String, String>();
		
		int first_page			= 1;		///<페이징 맨 처음으로 
	    int last_page			= 1;		///<페이징 맨 마지막으로
	    
	    int start_page 			= 1;		///<페이징 현재 블럭의 시작
	    int end_page			= 1;		///<페이징 현재 블럭의 마지막
	    
	    int prevPageBlock		= 1;		///<페이징 이전 블럭으로
	    int nextPageBlock		= 1;		///<페이징 다음 블럭으로
	    
	    int limit_st			= 1;		///<페이징 시작
	    int limit_ed			= limit_st * pagerows;	///<페이징 끝
	    
	    //last_page = (totalcnt / pagerows) + 1;
	    last_page = (totalcnt % pagerows > 0 ? totalcnt/pagerows+1 : totalcnt/pagerows);
		
	    mResult.put("totalcnt", String.valueOf(totalcnt)); //전체 카운트
	    
		mResult.put("pageRows", String.valueOf(pagerows)); //1페이지당 리스트
		mResult.put("pageBlock", String.valueOf(pageblock)); //페이지 노출 블럭

		mResult.put("nowPage", String.valueOf(pageno));

		mResult.put("firstPage", String.valueOf(first_page));
		mResult.put("lastPage", String.valueOf(last_page));
		
		
		if(pageno % pageblock > 0) {	
			start_page = ((pageno/pageblock)*pageblock+1); 	///페이지 블럭 시작번호
		} else {
			start_page = ((pageno-pageblock+1));			///페이지 블럭 시작번호
		}
		end_page = (start_page +(pageblock-1)); //페이지 블럭 끝번호
		
		if ( end_page > last_page) end_page = last_page;
		
		//현재 페이지 기준으로 시작, 마감 페이지 확정
		prevPageBlock = start_page - 1;	
		if ( prevPageBlock < 1 ) prevPageBlock = first_page; 
			
		nextPageBlock = end_page + 1;
		if ( last_page < nextPageBlock ) nextPageBlock = last_page;
		
		
		mResult.put("prevPageBlock", String.valueOf(prevPageBlock));
		mResult.put("startPage", String.valueOf(start_page));
		mResult.put("endPage", String.valueOf(end_page));
		mResult.put("nextPageBlock", String.valueOf(nextPageBlock));
		
		
		limit_st = ( pageno - 1 ) * pagerows; 
		limit_ed = pagerows;
		
		//mResult.put("pageHeader", "select * from (");
		//mResult.put("pageFooter", ") result limit "+limit_st+", "+limit_ed);
		mResult.put("pageHeader", " ");
		mResult.put("pageFooter", " limit "+limit_st+", "+limit_ed);
		
		return mResult; 
	}
}
