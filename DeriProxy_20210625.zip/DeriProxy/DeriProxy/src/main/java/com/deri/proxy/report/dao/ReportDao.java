package com.deri.proxy.report.dao;

import java.util.HashMap;

import java.util.List;


public interface ReportDao {

	///////////////////////////////목록/////////////////////////////////////////////////
	//목록 - report
	public int selectReportListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectReportList(HashMap<String, Object> param);
	
	///////////////////////////////조회/////////////////////////////////////////////////
	//조회 - report
	public HashMap<String, Object> selectReport(HashMap<String, Object> param);
	public int updateReportReadCnt(HashMap<String, Object> param);
	public int insertReportReadCnt(HashMap<String, Object> param);
	public int updateReportDownCnt(HashMap<String, Object> param);
	public int insertReportDownCnt(HashMap<String, Object> param);
	
	
	///////////////////////////////등록/////////////////////////////////////////////////
	//등록 - report
	public int insertReport(HashMap<String, Object> param);
	
	
	///////////////////////////////수정/////////////////////////////////////////////////
	//수정 - report
	public int updateReport(HashMap<String, Object> param);
	
	
	///////////////////////////////삭제/////////////////////////////////////////////////
	//삭제 - report
	public int deleteGbReport(HashMap<String, Object> param);
	
	
	///////////////////////////////완전 삭제/////////////////////////////////////////////////
	//완전 삭제 - report
	public int deleteReport(HashMap<String, Object> param);


}
