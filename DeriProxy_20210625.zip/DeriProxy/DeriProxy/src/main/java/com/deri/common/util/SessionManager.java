package com.deri.common.util;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.deri.proxy.Define;

public class SessionManager {

	
	/**
	 * make session
	 */
	public SessionManager(HttpServletRequest req) {
		//DestorySession(req);
	}
	
	public static void CreateSession(HttpServletRequest req, String[] names, String[] values) {
		HttpSession session = req.getSession();
		for (int i = 0; i < names.length ; i ++ ) {
			if ( i < values.length )			
				session.setAttribute(names[i], values[i]);	
		}
	}
	
	public static void CreateSession(HttpServletRequest req, String name, String value) {
		HttpSession session = req.getSession();
		session.setAttribute(name, value);	
	}

	
	/**
	 * getValue Session
	 */
	public static String getSession(HttpServletRequest request, String name) {
		HttpSession session = request.getSession();

		boolean sessionDefault = false;
		if ( sessionDefault ) {
			/*
			if ( "".equals(StringUtil.nullToEmpt((String)session.getAttribute(name))) && ( "snum".equals(name) || "loginid".equals(name) ) ) {
		
				String devmode = request.getServerName();
				
				if ( "localhost".equals(devmode) || "127.0.0.1".equals(devmode) || "172.17.1.7".equals(devmode) ) {
					
					if ( "localhost".equals(devmode) || "127.0.0.1".equals(devmode) ) {
						
						session.setAttribute("snum", "081621");
						session.setAttribute("name", "장재영-자동");
						session.setAttribute("depart", "자동");
					
					} else if ( "172.17.1.7".equals(devmode) ) {
						
						session.setAttribute("snum", "081621");
						session.setAttribute("name", "장재영-자동");
						session.setAttribute("depart", "자동");
						
					}
					session.setAttribute("loginip", devmode);
				}
			}
			*/
		}
		return StringUtil.nullToEmpt((String)session.getAttribute(name));
	}
	
	
	/**
	 * destory session
	 * @return 
	 */
	public static void DestorySession(HttpServletRequest req) {
		HttpSession session = req.getSession();
		session.invalidate();
	}
	
	/**
	 * admin session make
	 */
	public static void  MakeSession(HttpSession session, HashMap<String, Object> mt, String ip) {
		
		//세션을 초기화 하고 다시 저장한다.
		//try { session.invalidate(); } catch (Exception e) {}
		
		//세션 생성시 저장할 값
		String loginType = ""; //로그인유형
		String loginSeq = "";
		String loginId = "";
		String loginNm = "";
		String adminYn = "";
		String job_part = "";
		String tem_yn = "";
		
//		System.out.print("mt");System.out.println(mt);
		//로그인 유형, 로그인 아이디, 성명, 권한 정보 
		
		loginType = StringUtil.nullToEmpt(mt.get("loginType"));
		
		if ( mt.get("loginType").equals(Define.LOGIN_TYPE_C)) {
			//고객정보 저장
			loginSeq = String.valueOf(mt.get("addr_seq"));
			loginId = StringUtil.nullToEmpt(mt.get("addr_email"));
			loginNm = StringUtil.nullToEmpt(mt.get("addr_name"));
			
			Define.LOGIN_TYPE = Define.LOGIN_TYPE_C;
			
		} else if ( mt.get("loginType").equals(Define.LOGIN_TYPE_M)) {
			//직원정보 저장
			loginId = StringUtil.nullToEmpt(mt.get("snum"));
			loginNm = StringUtil.nullToEmpt(mt.get("s_name"));
			adminYn = StringUtil.nullToEmpt(mt.get("admin_yn"));
			job_part = StringUtil.nullToEmpt(mt.get("job_part"));
			tem_yn = StringUtil.nullToEmpt(mt.get("tem_yn"));
			
			Define.LOGIN_TYPE = Define.LOGIN_TYPE_M;
			
			if ( "Y".equals(adminYn)) {
				Define.LOGIN_TYPE = Define.LOGIN_TYPE_A;
				
				loginType = "A";
			}
			
		}
		session.setAttribute("loginType", loginType);
		session.setAttribute("loginSeq", loginSeq);
		session.setAttribute("loginId", loginId);
		session.setAttribute("loginNm", loginNm);
		
		
		//기타정보
		session.setAttribute("co_code", mt.get("cont_co_code"));
		session.setAttribute("co_name", mt.get("co_name"));
		session.setAttribute("addr_email", mt.get("addr_email"));
		session.setAttribute("addr_name", mt.get("addr_name"));
		session.setAttribute("addr_tel", mt.get("addr_tel"));
		session.setAttribute("snum", mt.get("snum"));
		
		//관리정보
		session.setAttribute("adminYn", adminYn);
		session.setAttribute("admin_yn", adminYn);
		session.setAttribute("job_part", job_part);
		session.setAttribute("tem_yn", tem_yn);
		
		
		//세션 후킹을 방지하기 위한 아이피.
		session.setAttribute("ip_address", ip);
		
		
	}
}
