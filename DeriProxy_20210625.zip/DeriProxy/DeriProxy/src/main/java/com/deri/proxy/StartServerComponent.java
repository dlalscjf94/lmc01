package com.deri.proxy;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;

import com.deri.proxy.Define;

/**
 * 서버시작시 자동 실행
 */
public class StartServerComponent {
	
}

/*

@Component
public class StartServerComponent extends WebMvcConfigurerAdapter {
	
	private static final Logger logger = Logger.getLogger(StartServerComponent.class);
	
	@Autowired
	Environment env;
	
	@PostConstruct
	public void init(){
	
		System.out.println(env.getProperty("server.ips"));
		
		// 시스템 시작시 해야할 것
		Define.SERVER_IP = Define.getLocalServerIp();
		System.out.println("IP:::::::" + Define.SERVER_IP);
		//개발 장비
		if ( Define.SERVER_IP.equals("172.17.1.161") ) {
			Define.IS_DEV_MODE = true;
			System.out.println("DEVMODE");
		} else {
			Define.IS_DEV_MODE = false;
			System.out.println("REALMODE");
		}
		
	}
}

*/