package com.deri.proxy.interceptor;

import java.io.PrintWriter;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.deri.common.util.SessionManager;
import com.deri.proxy.Define;

public class DefaultInterceptor extends HandlerInterceptorAdapter {

	static final String[] EXCLUDE_URL_LIST = {	//로그인 페이지, 회원가입 페이지 등은 인터셉터 적용 제외 페이지
			"/index",
			"/resources",
			"/main",
			"/login",
			"/devLogin"
		};
	static final String[] ADMIN_URL_LIST = { //level = A 관리자 만 접근 가능한 페이지
		"/admin/"
	};
	
		
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
			
		String reqUrl = request.getRequestURL().toString(); 
		 
		/** 로그인체크 제외 리스트 */
		for( String target : EXCLUDE_URL_LIST ){
			if(reqUrl.indexOf(target)>-1){ //indexOf 이용 URL주소에 로그인체크 제외 주소가 포함되어 있는지 확인
	    		return true;
	    	}
		}
		
		String loginId = SessionManager.getSession(request, "loginId");
		
		//////// 로그인 권한 체크 //////////////////
		Define.setLoginValue(request);
		
		if ( "".equals(loginId) ) {
			response.setContentType("text/html; charset=UTF-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('접근 권한이 없습니다.로그인 정보를 확인하여 주십시요');location.href='/login';</script>");
			out.flush();
			
			return false;
		}

		return true;
	}
		
}