package com.deri.proxy.login.dao;

import java.util.HashMap;
import java.util.ListResourceBundle;

public interface LoginDao {
	
	public HashMap<String, Object> selectUserInfo(HashMap<String, Object> paramHm);
	
	public int insertUserLog(HashMap<String, Object> paramHm);
	
	public int updateUserPassword(HashMap<String, Object> paramHm);
	
	public int updateUserInfo(HashMap<String, Object> paramHm);
	
	public int updateUserLogin(HashMap<String, Object> paramHm);
	
	
	
	
}
