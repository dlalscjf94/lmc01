package com.deri.proxy.user.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.user.dao.CompanyDao;


@Service
public class CompanyService {

	@Autowired private CompanyDao companyDao;
	
	
	//목록
	public int selectCompanyListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = companyDao.selectCompanyListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectCompanyList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = companyDao.selectCompanyList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//조회
	public HashMap<String, Object> selectCompany(HashMap<String, Object> param, boolean isread) {
		HashMap<String, Object> result = null;
		try {
			result = companyDao.selectCompany(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
		
}
