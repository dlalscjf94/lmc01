package com.deri.proxy.person.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.deri.common.util.PageUtil;
import com.deri.common.util.SessionManager;
import com.deri.proxy.person.service.PersonService;

/**
 * 
 * 인물 정보 조회 컨트롤러
 * 
 * @author 
 *
 */
@Controller
public class PersonController {

	private static final Logger logger = LoggerFactory.getLogger(PersonController.class);
	
	@Autowired private PersonService				personService			= new PersonService();
	
	/**
	 * 인물 목록
	 */
	@RequestMapping(value = {"/person"}, method = RequestMethod.GET)
	public String list( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="sch_co_name", required=false, defaultValue="") String sch_co_name,
							@RequestParam(value="sch_pe_name", required=false, defaultValue="") String sch_pe_name,
							@RequestParam(value="pageno", required=false, defaultValue="1") String pageno,
							
							@RequestParam(value="pagecount", required=false, defaultValue="10") String pagecount,
			
							Model model	) {
	
		String loginType = SessionManager.getSession(request,"loginType");
		String viewPage = "cust";
		
		//System.out.println("loginType:"+loginType + ":" + SessionManager.getSession(request,"loginType"));
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		//검색어 처리 영역
		dbparam.put("sch_co_name", sch_co_name);
		dbparam.put("sch_pe_name", sch_pe_name);
		
		//전체 갯수 및 목록 호출부
		List<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
		int totalcnt = 0;
		Map<String, String> pageMap = new HashMap<String, String>();
		
		if ( !"".equals(sch_pe_name) ) {
			totalcnt = personService.selectPersonListCount(dbparam);
		}
		PageUtil.pageSet(Integer.parseInt(pagecount),10);
		
		pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		
		if ( !"".equals(sch_pe_name) ) {
			list = personService.selectPersonList(dbparam);	
		}
		
		//목록
		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("pageno", pageno);
		model.addAttribute("pageMap", pageMap);
		model.addAttribute("list", list);
		
		model.addAttribute("sch_co_name", sch_co_name);
		model.addAttribute("sch_pe_name", sch_pe_name);
		
		model.addAttribute("pageno", pageno);
		
		
		return "/web/person/person.tiles";
	}
	
	
	@RequestMapping(value = {"/person/view"}, method = RequestMethod.GET)
	public String view( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="pe_code", required=false, defaultValue="") String pe_code,
			
							Model model	) {
	
		String loginType = SessionManager.getSession(request,"loginType");
		String viewPage = "cust";
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		dbparam.put("pe_code", pe_code);
		
		
		
		//인물 기본정보 얻어옴.
		HashMap<String, Object> person = personService.selectPerson(dbparam);

		//인물 기업별 현황 리스트 얻어옴.
		List<HashMap<String, Object>> personCompanyList = personService.selectPersonCompanyGeneralInfo(dbparam);

		
		for( HashMap<String, Object> hm : personCompanyList ){
			//인물 기업별 현황의 위원회 리스트 얻어옴.
			dbparam.put("co_code", hm.get("co_code"));
			List<HashMap<String, Object>> PersonCommitteList = personService.selectPersonCommitteList(dbparam);
			hm.put("PersonCommitteList", PersonCommitteList);
		}
		
		//인물 경력사항 리스트 얻어옴.
		List<HashMap<String, Object>> personCareerList = personService.selectPersonCarrerList(dbparam);
		
		
		//인물 이사회 활동 내역
		List<HashMap<String, Object>> personMeetingList = personService.selectPersonMeetingList(dbparam);
		
		
		//인물 주총 및 권고의견
		dbparam.put("pe_name", person.get("pe_nm"));
		List<HashMap<String, Object>> personProxyList = personService.selectPersonProxyList(dbparam);
		
		
		
		
		model.addAttribute("personInfo", person); //기본정보
		model.addAttribute("personCompanyList", personCompanyList); //기업별
		model.addAttribute("personCareerList", personCareerList); //경력
		model.addAttribute("personMeetingList", personMeetingList); //이사회
		model.addAttribute("personProxyList", personProxyList); //주총권고
		
		
		
		return "/web/person/person_view.tiles";
	}
	
		
}
