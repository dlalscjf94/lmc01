package com.deri.proxy.job.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.deri.common.util.SessionManager;
import com.deri.common.util.StringUtil;
import com.deri.common.util.PageUtil;
import com.deri.proxy.common.controller.CommonController;
import com.deri.proxy.common.service.CommonService;
import com.deri.proxy.job.service.JobCustomerService;
import com.deri.proxy.job.service.JobService;
import com.deri.proxy.user.service.CompanyService;

/**
 * 
 * 의안분석 요청 종목 관리 컨트롤러
 * 
 * @author 
 *
 */
@Controller
public class JobController extends CommonController {

	private static final Logger logger = LoggerFactory.getLogger(JobController.class);
	
	@Autowired private CommonService			commonService;
	@Autowired private JobService				jobService;
	@Autowired private JobCustomerService		jobCustomerService;
	@Autowired private CompanyService			companyService;
	
	/**
	 * 의안분석 요청 목록
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/job"}, method = RequestMethod.GET)
	public String list( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="use_yn", required=false, defaultValue="") String use_yn,
							@RequestParam(value="job_type", required=false, defaultValue="") String job_type,
							@RequestParam(value="jm_code", required=false, defaultValue="") String jm_code,
							@RequestParam(value="jm_name", required=false, defaultValue="") String jm_name,
							@RequestParam(value="pageno", required=false, defaultValue="1") String pageno,
							@RequestParam(value="meet_gb", required=false, defaultValue="") String meet_gb,
							@RequestParam(value="coverage", required=false, defaultValue="") String coverage,
							
							@RequestParam(value="complet_yn", required=false, defaultValue="Y") String complet_yn,
							@RequestParam(value="templet_yn", required=false, defaultValue="all") String templet_yn,
							@RequestParam(value="gumsu_yn", required=false, defaultValue="all") String gumsu_yn,
							@RequestParam(value="an_01_fi", required=false, defaultValue="all") String an_01_fi,
							@RequestParam(value="an_02_fi", required=false, defaultValue="all") String an_02_fi,
							@RequestParam(value="an_03_fi", required=false, defaultValue="all") String an_03_fi,
							@RequestParam(value="an_04_fi", required=false, defaultValue="all") String an_04_fi,
							@RequestParam(value="an_05_fi", required=false, defaultValue="all") String an_05_fi,
							
							@RequestParam(value="meet_ymd", required=false, defaultValue="") String meet_ymd,
							@RequestParam(value="reqdate", required=false, defaultValue="") String reqdate,
							
							@RequestParam(value="pagecount", required=false, defaultValue="10") String pagecount,
							
							
							@RequestParam(value="isExcel", required=false, defaultValue="N") String isExcel,
			
							Model model	) {
	
		String loginType = SessionManager.getSession(request,"loginType");
		String viewPage = "cust";
		
		//System.out.println("loginType:"+loginType + ":" + SessionManager.getSession(request,"loginType"));
		
		//로그인 사용자의 작업 영역을 확인한다.
		String job_part = SessionManager.getSession(request,"job_part");
		String tem_yn = SessionManager.getSession(request,"tem_yn");
		String admin_yn = SessionManager.getSession(request,"admin_yn");

		if ( job_part.length() == 2 && job_part.indexOf("01") > -1 ) {
			if ( "".equals(StringUtil.nullToEmpt(request.getParameter("an_01_fi"))) ) {
				templet_yn = "Y"; an_01_fi = "N";
			}
		}
		if ( job_part.length() == 2 && job_part.indexOf("02") > -1 ) {
			if ( "".equals(StringUtil.nullToEmpt(request.getParameter("an_02_fi"))) ) {
				templet_yn = "Y"; an_02_fi = "N";
			}
		}
		if ( job_part.length() == 2 && job_part.indexOf("03") > -1 ) {
			if ( "".equals(StringUtil.nullToEmpt(request.getParameter("an_03_fi"))) ) {
				templet_yn = "Y"; an_03_fi = "N";
			}
		}
		if ( job_part.length() == 2 && job_part.indexOf("04") > -1 ) {
			if ( "".equals(StringUtil.nullToEmpt(request.getParameter("an_04_fi"))) ) {
				templet_yn = "Y"; an_04_fi = "N";
			}
		}

		model.addAttribute("templet_yn", templet_yn);
		model.addAttribute("an_01_fi", an_01_fi);
		model.addAttribute("an_02_fi", an_02_fi);
		model.addAttribute("an_03_fi", an_03_fi);
		model.addAttribute("an_04_fi", an_04_fi);
		model.addAttribute("an_05_fi", an_05_fi);
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		//검색어 처리 영역
		dbparam.put("use_yn", use_yn);
		dbparam.put("job_type", job_type);
		dbparam.put("jm_code", jm_code);
		dbparam.put("jm_name", jm_name);
		dbparam.put("meet_gb", meet_gb);
		dbparam.put("coverage", coverage);

		dbparam.put("complet_yn", complet_yn);
		dbparam.put("templet_yn", templet_yn);
		dbparam.put("gumsu_yn", gumsu_yn);
		dbparam.put("an_01_fi", an_01_fi);
		dbparam.put("an_02_fi", an_02_fi);
		dbparam.put("an_03_fi", an_03_fi);
		dbparam.put("an_04_fi", an_04_fi);
		dbparam.put("an_05_fi", an_05_fi);
		
		dbparam.put("meet_ymd", meet_ymd);
		dbparam.put("reqdate", reqdate);
		
		//전체 갯수 및 목록 호출부
		List<HashMap<String, Object>> list;
		int totalcnt = 0;
		Map<String, String> pageMap = new HashMap<String, String>();
		
		if ( "Y".equals(isExcel)) {
		} else  {
			totalcnt = jobService.selectJobListCount(dbparam);
			PageUtil.pageSet(Integer.parseInt(pagecount),10);
			pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
			dbparam.put("pageHeader", pageMap.get("pageHeader"));
			dbparam.put("pageFooter", pageMap.get("pageFooter"));
		}
		list = jobService.selectJobList(dbparam);
		
		//목록
		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("pageno", pageno);
		model.addAttribute("pageMap", pageMap);
		model.addAttribute("list", list);
		
		
		model.addAttribute("pageno", pageno);
		
		
		//기관목록
		dbparam.clear();
		PageUtil.pageSet(40,10);
		pageMap = PageUtil.getPageStructure(1, 10000);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		model.addAttribute("companyList", companyService.selectCompanyList(dbparam));
		
		
		
		if ( "Y".equals(isExcel) ) {
			//엑셀다운로드
			excelDownData(request.getSession(), response, list);
			return "/web/excel.empty";
		} else {
		
			return "/web/job/job.tiles";
		}
	}
	
	
	public void excelDownData(HttpSession session, HttpServletResponse response, List<HashMap<String, Object>> list) {
		List<List<String>> lists = new ArrayList<List<String>>();
		List<String> heads = new ArrayList<String>();
		heads.add("No");
		heads.add("유형");
		heads.add("주총");
		heads.add("종목코드");
		heads.add("종목명");
		heads.add("주총일");
		heads.add("기한");
		heads.add("공고번호");
		heads.add("템플릿");
		heads.add("검수");
		heads.add("재무");
		heads.add("정관");
		heads.add("선임");
		heads.add("보수");
		heads.add("기타");
		heads.add("기타(1)");
		heads.add("기타(2)");
		heads.add("기타(3)");
		heads.add("기타(4)");
		heads.add("비고");
//		lists.add(heads);
		
		int i = 1;
		for(HashMap<String, Object> hm : list) {
			List<String> datas = new ArrayList<String>();
			
			datas.add(String.valueOf(i++));
			datas.add(StringUtil.nullToEmpt(hm.get("job_type")));
			
			if ( "1".equals(StringUtil.nullToEmpt(hm.get("meet_gb"))) ) {  datas.add("정기"); } else { datas.add("임시"); }
			datas.add(StringUtil.nullToEmpt(hm.get("jm_code")));
			datas.add(StringUtil.nullToEmpt(hm.get("jm_name")));
			datas.add(StringUtil.nullToEmpt(hm.get("meet_ymd")));
			datas.add(StringUtil.nullToEmpt(hm.get("reqdate")));
			datas.add(StringUtil.nullToEmpt(hm.get("rcp_no")));
			if ( "N".equals(StringUtil.nullToEmpt(hm.get("templet_yn"))) ) { datas.add("생성중"); } else { datas.add("완"); }
			if ( "N".equals(StringUtil.nullToEmpt(hm.get("gumsu_yn"))) ) { datas.add("대기"); } else { datas.add("완"); }
			if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_01_yn"))) ) { datas.add("-"); } else { 
				if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_01_fi"))) ) { datas.add("중"); } else { datas.add("완"); } 
			}
			if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_02_yn"))) ) { datas.add("-"); } else {
				if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_02_fi"))) ) { datas.add("중"); } else { datas.add("완"); }
			}
			if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_03_yn"))) ) { datas.add("-"); } else {
				if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_03_fi"))) ) { datas.add("중"); } else { datas.add("완"); }
			}
			if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_04_yn"))) ) { datas.add("-"); } else {
				if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_04_fi"))) ) { datas.add("중"); } else { datas.add("완"); }
			}
			if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_05_yn"))) ) { datas.add("-"); } else {
				if ( "N".equals(StringUtil.nullToEmpt(hm.get("an_05_fi"))) ) { datas.add("중"); } else { datas.add("완"); }
			}
			if ( "0".equals(StringUtil.nullToEmpt(hm.get("etc_01")))) { datas.add("-"); } else { datas.add("Y"); }
			if ( "0".equals(StringUtil.nullToEmpt(hm.get("etc_02")))) { datas.add("-"); } else { datas.add("Y"); }
			if ( "0".equals(StringUtil.nullToEmpt(hm.get("etc_03")))) { datas.add("-"); } else { datas.add("Y"); }
			if ( "0".equals(StringUtil.nullToEmpt(hm.get("etc_04")))) { datas.add("-"); } else { datas.add("Y"); }
			datas.add(StringUtil.nullToEmpt(hm.get("bigo")));
			
			lists.add(datas);
		}
		excelDown(session.getServletContext().getRealPath("/WEB-INF/excel/job.xlsx"), response, lists, "jobQueue", heads);
	}
	
	
	
	
	@RequestMapping(value = {"/job/form"}, method = RequestMethod.GET)
	public String write( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="job_seq", required=false, defaultValue="") String job_seq,
							@RequestParam(value="finish_type", required=false, defaultValue="") String finish_type,
							
							Model model	) {
	
		HashMap<String, Object> resultHm = new HashMap<String, Object>();
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		HashMap<String, Object> content = new HashMap<String, Object>();
		if ( !"".equals(job_seq) ) {
			dbparam.put("job_seq",  job_seq);
			content = jobService.selectJob(dbparam);
		}
		model.addAttribute("content", content);
		
		return "/web/job/job_pop.jsp";
	}

	
	
	@ResponseBody
	@RequestMapping(value = {"/job/work"}, method = {RequestMethod.GET, RequestMethod.POST})
	public HashMap<String, Object> proc_job( 	HttpServletRequest request, HttpServletResponse response, 

							@RequestParam(value="procMode", required=false, defaultValue="") String procMode,
							@RequestParam(value="job_seq", required=false, defaultValue="") String job_seq,
							
							@RequestParam(value="finish_type", required=false, defaultValue="") String finish_type,
							
							
							Model model	) {

		HashMap<String, Object> resultHm = new HashMap<String, Object>();
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		HashMap<String, Object> content = new HashMap<String, Object>();
		if ( !"".equals(job_seq) ) {
			dbparam.put("job_seq",  job_seq);
			content = jobService.selectJob(dbparam);
		}
		//model.addAttribute("content", content);
		
		String templet_yn = StringUtil.nullToEmpt(content.get("templet_yn"));
		String gumsu_yn = StringUtil.nullToEmpt(content.get("gumsu_yn"));
		
		int resultCnt = 0;
		String resultMessage = "";
		
		dbparam.put("tem_type", content.get("tem_type") );
		dbparam.put("meet_seq", content.get("meet_seq") );
		dbparam.put("an_type", finish_type );
		dbparam.put("an_yn", "Y" );
		
		dbparam.put("snum", SessionManager.getSession(request, "snum"));
		
		if ( "templet".equals(finish_type) ) {
			dbparam.put("job_seq", job_seq);
			dbparam.put(finish_type+"_yn", "Y");
			resultCnt = jobService.updateJobFinish(dbparam);
			
			if ( resultCnt > 0 ) {
				resultMessage += "템플릿 완료\n";
				
				jobService.insertJobFinishLog(dbparam);
				
			} else {
				resultMessage += "템플릿 완료실패(오류)\n";
			}
			
			
		} else if ( "an_01".equals(finish_type) || "an_02".equals(finish_type) || "an_03".equals(finish_type) || "an_04".equals(finish_type) || "an_05".equals(finish_type) ) {
			
			if ( "N".equals(templet_yn) ) {
				resultHm.put("isSuccess", "false");
				resultHm.put("message", "템플릿 생성 전 입니다. (분석 완료 체크를 하실 수 없습니다.)");
				return resultHm;
			} else if ( "Y".equals(gumsu_yn) ) {
				resultHm.put("isSuccess", "false");
				resultHm.put("message", "검수 완료된 템플릿 입니다. (분석 완료 체크를 하실 수 없습니다.)");
				return resultHm;
			} else {
				
				dbparam.put(finish_type+"_yn", "Y");
				resultCnt = jobService.updateJobFinish(dbparam);
				
				if ( resultCnt > 0 ) {
					resultMessage += "안건 완료\n";
					
					jobService.insertJobFinishLog(dbparam);
					
					
					//만약 모든 안건을 완료한 상태라면 finish_yn 값을 Y 로 처리한다.
					//사용안함.
					
					
				} else {
					resultMessage += "안건 완료실패(오류)\n";
				}
				
			}
			
		} else if ( "gumsu".equals(finish_type) ) {
			
			//검수 완료전 모든 안건이 분석 완료 되었는지 확인하자.
			//finish_yn 으로.
			if ( "N".equals(templet_yn) ) {
				resultHm.put("isSuccess", "false");
				resultHm.put("message", "템플릿 생성 전 입니다. (검수 완료 체크를 하실 수 없습니다.)");
				return resultHm;
			} else if ( "Y".equals(gumsu_yn) ) {
				resultHm.put("isSuccess", "false");
				resultHm.put("message", "검수 완료된 템플릿 입니다. (검수 완료 체크를 하실 수 없습니다.)");
				return resultHm;
			} else {
				dbparam.put(finish_type+"_yn", "Y"); //검수완료
				resultCnt = jobService.updateJobFinish(dbparam);
				
				if ( resultCnt > 0 ) {
					resultMessage += "검수 완료\n";
					jobService.insertJobFinishLog(dbparam);
					
					//검수가 완료되면 모든 처리가 완료된 건.
					
					
					
				} else {
					resultMessage += "검수 완료실패(오류)\n";
				}
			}
		}
		
		resultHm.put("message", resultMessage);
		
		return resultHm;
	}
	
	
	
	@ResponseBody
	@RequestMapping(value = {"/job/proc"}, method = {RequestMethod.GET, RequestMethod.POST})
	public HashMap<String, Object> proc( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="job_seq", required=false, defaultValue="") String job_seq,
							
							@RequestParam(value="co_code_arr", required=false, defaultValue="") String[] co_code_arr,
							@RequestParam(value="job_type_arr", required=false, defaultValue="") String[] job_type_arr,
							
							@RequestParam(value="job_type", required=false, defaultValue="") String job_type,
							@RequestParam(value="meet_seq", required=false, defaultValue="") String meet_seq,
							@RequestParam(value="jm_code", required=false, defaultValue="") String jm_code,

							@RequestParam(value="an_01_yn", required=false, defaultValue="") String an_01_yn,
							@RequestParam(value="an_02_yn", required=false, defaultValue="") String an_02_yn,
							@RequestParam(value="an_03_yn", required=false, defaultValue="") String an_03_yn,
							@RequestParam(value="an_04_yn", required=false, defaultValue="") String an_04_yn,
							@RequestParam(value="an_05_yn", required=false, defaultValue="") String an_05_yn,
							
							@RequestParam(value="reqdate", required=false, defaultValue="") String reqdate,
							@RequestParam(value="bigo", required=false, defaultValue="") String bigo,
							@RequestParam(value="bigo_job", required=false, defaultValue="") String bigo_job,
							
							@RequestParam(value="procMode", required=false, defaultValue="") String procMode,
							
							Model model	) {
	
		HashMap<String, Object> resultHm = new HashMap<String, Object>();
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		
		//job_type, meet_seq, templet_yn, gumsu_yn, finish_yn, an_01_yn, an_02_yn, an_03_yn, an_04_yn, an_05_yn, bigo, bigo_job
		dbparam.put("job_seq", job_seq);
		
		dbparam.put("job_type", job_type);
		dbparam.put("meet_seq", meet_seq);
		dbparam.put("jm_code", jm_code);
		
		
		dbparam.put("an_01_yn", an_01_yn);
		dbparam.put("an_02_yn", an_02_yn);
		dbparam.put("an_03_yn", an_03_yn);
		dbparam.put("an_04_yn", an_04_yn);
		dbparam.put("an_05_yn", an_05_yn);
		
		dbparam.put("reqdate", reqdate);
		dbparam.put("bigo", bigo);
		dbparam.put("bigo_job", bigo_job);
		
		resultHm.put("isSuccess", false);
		
		int resultCnt = 0;
		String resultMessage = "";
		if ( "I".equals(procMode) || "M".equals(procMode) ) {
			//작업 등록
			
			//1. 이미 등록된 작업인지 확인한다.
			//1.1 이미 등록된 작업이면 update 한다.
			//2. 등록되지 않은 작업이면 insert 한다.
			
			for ( String s : job_type_arr ) { //등록할때는 양식을 선택하여 등록함.
				
				dbparam.put("job_seq", "");
				dbparam.put("del_yn", "");
				dbparam.put("job_type", s);
				
				//System.out.println(job_type_arr.length + ":" + dbparam);
				HashMap<String, Object> checkHm = jobService.selectJob(dbparam);
				//System.out.println(s + ":" + checkHm);
				if ( checkHm == null ) {
					//insert
					dbparam.put("del_yn", "N");
					resultCnt = jobService.insertJob(dbparam);
					if ( resultCnt > 0 ) {
						resultMessage += "템플릿 ("+s+") 등록완료\n";
					} else {
						resultMessage += "템플릿 ("+s+") 등록실패(오류)\n";
					}
				} else {
					//upadte
					dbparam.put("job_seq", checkHm.get("job_seq"));
					dbparam.put("del_yn", "N");
					resultCnt = jobService.updateJob(dbparam);
					if ( resultCnt > 0 ) {
						resultMessage += "템플릿 ("+s+") 수정등록완료\n";
					} else {
						resultMessage += "템플릿 ("+s+") 수정등록실패(오류)\n";
					}
				}
				
			}
			
			
			for ( String s : co_code_arr ) { //등록할때는 양식을 선택하여 등록함.
				
				dbparam.put("req_seq", "");
				dbparam.put("del_yn", "");
				dbparam.put("co_code", s); //고객코드
				HashMap<String, Object> checkHm = jobCustomerService.selectJobCustomer(dbparam);
				
				HashMap<String, Object> checkCo = commonService.selectCo(dbparam);
				
				dbparam.put("tem_type", checkCo.get("co_templet"));
				
				if ( checkHm == null ) {
					//insert
					dbparam.put("del_yn", "N");
					resultCnt = jobCustomerService.insertJobCustomer(dbparam);
					if ( resultCnt > 0 ) {
						resultMessage += "기관 ("+checkCo.get("co_sname")+") 등록완료\n";
					} else {
						resultMessage += "기관 ("+checkCo.get("co_sname")+") 등록실패(오류)\n";
					}
				} else {
					//upadte
					dbparam.put("req_seq", checkHm.get("req_seq"));
					dbparam.put("del_yn", "N");
					resultCnt = jobCustomerService.updateJobCustomer(dbparam);
					if ( resultCnt > 0 ) {
						resultMessage += "기관 ("+checkCo.get("co_sname")+") 수정등록완료\n";
					} else {
						resultMessage += "기관 ("+checkCo.get("co_sname")+") 수정등록실패(오류)\n";
					}
				}
			}
			
			if ( "".equals(resultMessage)) {
				resultMessage = "등록 대상이 없습니다.";
			}
			
			resultHm.put("isSuccess", true);
			
		} else if ( "D".equals(procMode) ) {
			//작업 삭제
			dbparam.put("del_yn", "Y");
			//1. 작업에서 템플릿 유형을 삭제한다.
			for ( String s : job_type_arr ) { //등록할때는 양식을 선택하여 등록함.
				dbparam.put("job_type", s);
				resultCnt = jobService.deleteGbJob(dbparam);
				if ( resultCnt > 0 ) {
					resultMessage += "템플릿 ("+s+") 삭제완료\n";
				} else {
					resultMessage += "템플릿 ("+s+") 삭제실패(오류)\n";
				}
			}
			//2. 작업(고객)에서 고객을 삭제한다.
			for ( String s : co_code_arr ) { //등록할때는 양식을 선택하여 등록함.
				dbparam.put("co_code", s);
				HashMap<String, Object> checkCo = commonService.selectCo(dbparam);
				
				resultCnt = jobCustomerService.deleteGbJobCustomer(dbparam);
				if ( resultCnt > 0 ) {
					resultMessage += "기관 ("+checkCo.get("co_sname")+") 삭제완료\n";
				} else {
					resultMessage += "기관 ("+checkCo.get("co_sname")+") 삭제실패(오류)\n";
				}
			}
			
		} else if ( "DD".equals(procMode) ) {
			//작업 완전 삭제
			
		}
		
		resultHm.put("message", resultMessage);
		
		
		return resultHm;
	}
	
}
