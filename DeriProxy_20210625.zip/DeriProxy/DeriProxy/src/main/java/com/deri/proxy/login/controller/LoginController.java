package com.deri.proxy.login.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.deri.common.util.StringUtil;
import com.deri.common.util.PasswordEncoding;
import com.deri.common.util.SHAPasswordEncoder;
import com.deri.common.util.SessionManager;
import com.deri.proxy.Define;
import com.deri.proxy.login.service.LoginService;

/** 
 *계정관리 D/4avRoIIVNTwjPW4AlhPpXuxCU4Mqdhryj/N6xaFQw=
 * 
 * 사용자 계정 컨트롤러
 * 
 * 로그인 화면
 * 로그인 프로세스
 * 
 * @author 
 *
 */
@Controller
public class LoginController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class);
	
	@Autowired private LoginService				loginService				= new LoginService();
	
	private final String ERROR_MESSAGE_01 = "요청하신 사용자 정보가 없습니다.";
	private final String ERROR_MESSAGE_02 = "비밀번호를 확인하시기 바랍니다.";
	
	
	private final String SUCCESS_MESSAGE_01 = "로그인 처리 되었습니다.";
	private final String SUCCESS_MESSAGE_02 = "비밀번호를 변경하시기 바랍니다.";
	
	
	@RequestMapping(value = {"/login"}, method = RequestMethod.GET)
	public String login( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		if ( !"".equals(SessionManager.getSession(request, "loginType"))  ) {
			return "redirect:/main";
		} else {
			return "/web/login/login.jsp";
		}
	}
	
	@RequestMapping(value = {"/devLogin"}, method = RequestMethod.GET)
	public String devlogin( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/login/devlogin.jsp";
	}
	
	@RequestMapping(value = {"/logout"}, method = {RequestMethod.GET, RequestMethod.POST})
	public String logout(	HttpServletRequest request, HttpServletResponse response, 
							Model model ) {
	
		SessionManager.DestorySession(request);
		
		return "redirect:/login";
	}
	
	@ResponseBody
	@RequestMapping(value = {"/login/proc"}, method = {RequestMethod.GET, RequestMethod.POST})
	public HashMap<String, Object> loginProc( 	HttpServletRequest request, HttpServletResponse response,
			
								@RequestParam(value="input_id", required=false, defaultValue="") String input_id,
								@RequestParam(value="input_password", required=false, defaultValue="") String input_password,
			
								Model model	) {
	
		HashMap<String, Object> paramHm = new HashMap<String, Object>();
		HashMap<String, Object> resultHm = new HashMap<String, Object>();
		HashMap<String, Object> messageHm = new HashMap<String, Object>();
		
		
		messageHm.put("isLogin", "false");
		
		String loginType = "";
		//로그인 처리시 6자리 텍스트면 직원, @ 있으면 고객이다.
		if ( input_id.indexOf("@") > -1 ) {
			loginType = Define.LOGIN_TYPE_C;
		} else if ( input_id.length() == 6 ){
			loginType = Define.LOGIN_TYPE_M;
		} else {
			//잘못된 아이디 유형
			messageHm.put("message", ERROR_MESSAGE_01);
			return messageHm;
		}
		
		paramHm.put("gubun", loginType);
		paramHm.put("input_id", input_id);
		

		//1. DB 조회한후
		resultHm = loginService.selectUserInfo(paramHm);
		
		System.out.println("***********" + resultHm + "**********"); 
		
		//1.1 조회값이 없으면 바로 리턴 한다.
		if ( resultHm == null ) {
			
			messageHm.put("message", ERROR_MESSAGE_01);
			return messageHm;
		}
		 
		//2. 비밀번호를 체크하고
		String dbPassword = "";
		if ( loginType.equals(Define.LOGIN_TYPE_C ) ) {
			dbPassword = StringUtil.nullToEmpt(resultHm.get("addr_pwd")); 
		} else {
			dbPassword = StringUtil.nullToEmpt(resultHm.get("s_pwd"));
		}
		
		paramHm.clear();
		
		paramHm.put("gubun", loginType);
		paramHm.put("login_type", loginType);
		paramHm.put("login_id", input_id);
		paramHm.put("addr_seq", resultHm.get("addr_seq"));
		
		//login_ip
		//외부망 아이피
		String ip = request.getRemoteAddr();
		//내부망 아이피
		String pip = StringUtil.nullToEmpt(request.getHeader("Proxy-Client-IP"));
		if ( !"".equals(pip) ) {
			paramHm.put("login_ip", pip);
		} else {
			paramHm.put("login_ip", ip);
		}
		
		
		//암호화
		SHAPasswordEncoder shaPasswordEncoder = new SHAPasswordEncoder(256);
        shaPasswordEncoder.setEncodeHashAsBase64(true);
        PasswordEncoding passwordEncoding = new PasswordEncoding(shaPasswordEncoder);
        String loginpw_enc = passwordEncoding.encode(input_password);
        boolean match_pw = passwordEncoding.matches(input_password, dbPassword);
        
        //System.out.println(input_password + "||" + dbPassword + "||" + loginpw_enc );
		
        if ( match_pw == false ) { //비밀번호 불일치
        	messageHm.put("message", ERROR_MESSAGE_02);
			
			//로그인 실패 로그
			//login_type, id_seq, login_time, login_ip, success_yn, bigo			
        	paramHm.put("success_yn","N");
			paramHm.put("bigo", "비밀번호 틀림");
			loginService.insertUserLog(paramHm);
			
			messageHm.put("loginsuccess", "N");
			loginService.updateUserLogin(paramHm);
			
			return messageHm;

		} else {
			
			//비밀번호변경일
			String pwchange_daycnt = StringUtil.nullToEmpt(String.valueOf(resultHm.get("pwchange_daycnt")),"-1");
			
			//고객은 무조건 변경해야 하고. 직원은 1111 그대로 유지해도 되도록
			if ( !loginType.equals(Define.LOGIN_TYPE_C ) ) {
				pwchange_daycnt = "";
			}
			
			if ( "-10000".equals(pwchange_daycnt) ) {
				//비밀번호를 변경하지 않은경우
				paramHm.put("success_yn","N");
				paramHm.put("bigo", "비밀번호 변경X");
				loginService.insertUserLog(paramHm);
				
				messageHm.put("isLogin", "pass");
				messageHm.put("message", "비밀번호를 변경하여 주시기 바랍니다.");
				
				messageHm.put("loginsuccess", "N");
				loginService.updateUserLogin(paramHm);
				
				return messageHm;
				
			} else {
				//3. 일치하면 로그인 성공
				paramHm.put("success_yn","Y");
				
				//3.1 비번이 1111 이라면 비번 변경 화면으로 이동
				
				//5. 로그 쌓고
				//로그인성공
				//login_type, id_seq, login_time, login_ip, success_yn, bigo
				loginService.insertUserLog(paramHm);
				
				
				//6. 세션을 생성한다.
				
				//세션을 생성한다.
				HttpSession session  			=  request.getSession();
				resultHm.put("loginType", loginType);
				SessionManager.MakeSession(session, resultHm, StringUtil.nullToEmpt(paramHm.get("login_ip")));
				
				//7. 리턴
				messageHm.put("isLogin", "true");
				messageHm.put("loginsuccess", "Y");
				loginService.updateUserLogin(paramHm);
				
				return messageHm;
			}
			
		}
		
	}
	
	@RequestMapping(value = {"/login/password"}, method = RequestMethod.GET)
	public String form( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/login/password.pop-tiles";
	}
	
	@ResponseBody
	@RequestMapping(value = {"/login/password_proc"}, method = {RequestMethod.GET, RequestMethod.POST})
	public HashMap<String, Object> passwordProc( 	HttpServletRequest request, HttpServletResponse response, 
	
							@RequestParam(value="input_id", required=false, defaultValue="") String input_id,
							@RequestParam(value="input_password", required=false, defaultValue="") String input_password,
							@RequestParam(value="change_password", required=false, defaultValue="") String change_password,
							
							Model model	) {
	
		HashMap<String, Object> paramHm = new HashMap<String, Object>();
		HashMap<String, Object> resultHm = new HashMap<String, Object>();
		HashMap<String, Object> messageHm = new HashMap<String, Object>();
		
		messageHm.put("isLogin", "false");
		
		String loginType = "";
		//로그인 처리시 6자리 텍스트면 직원, @ 있으면 고객이다.
		if ( input_id.indexOf("@") > -1 ) {
			loginType = Define.LOGIN_TYPE_C;
		} else if ( input_id.length() == 6 ){
			loginType = Define.LOGIN_TYPE_M;
		} else {
			//잘못된 아이디 유형
			messageHm.put("message", ERROR_MESSAGE_01);
			return messageHm;
		}
		
		paramHm.put("gubun", loginType);
		paramHm.put("input_id", input_id);
		
		
		//login_ip
		//외부망 아이피
		String ip = request.getRemoteAddr();
		//내부망 아이피
		String pip = StringUtil.nullToEmpt(request.getHeader("Proxy-Client-IP"));
		if ( !"".equals(pip) ) {
			paramHm.put("login_ip", pip);
		} else {
			paramHm.put("login_ip", ip);
		}
				
				
		//1. DB 조회한후
		resultHm = loginService.selectUserInfo(paramHm);
		

		//1.1 조회값이 없으면 바로 리턴 한다.
		if ( resultHm == null ) {
			
			messageHm.put("message", ERROR_MESSAGE_01);
			return messageHm;
		}
		 
		//2. 비밀번호를 체크하고
		String dbPassword = "";
		if ( loginType.equals(Define.LOGIN_TYPE_C ) ) {
			dbPassword = StringUtil.nullToEmpt(resultHm.get("addr_pwd")); 
		} else {
			dbPassword = StringUtil.nullToEmpt(resultHm.get("s_pwd"));
		}
		
		paramHm.clear();
		paramHm.put("gubun", loginType);
		paramHm.put("login_type", loginType);
		paramHm.put("login_id", input_id);
		
		//암호화
		SHAPasswordEncoder shaPasswordEncoder = new SHAPasswordEncoder(256);
        shaPasswordEncoder.setEncodeHashAsBase64(true);
        PasswordEncoding passwordEncoding = new PasswordEncoding(shaPasswordEncoder);
        String loginpw_enc = passwordEncoding.encode(input_password);
        String change_password_enc = passwordEncoding.encode(change_password);
        boolean match_pw = passwordEncoding.matches(input_password, dbPassword);
        
        //System.out.println(input_password + "||" + dbPassword + "||" + loginpw_enc );
		
        if ( match_pw == false ) { //비밀번호 불일치
        	messageHm.put("message", ERROR_MESSAGE_02);
			
			//로그인 실패 로그
			//login_type, id_seq, login_time, login_ip, success_yn, bigo			
        	paramHm.put("success_yn","N");
			paramHm.put("bigo", "비밀번호 틀림");
			loginService.insertUserLog(paramHm);
			
			return messageHm;

		} else {
			//비밀번호가 일치하니. 비밀번호를 변경하고 로그인 프로세스를 진행한다 (세션저장)
			//세션저장을 완료하고 메인 프레임을 main 으로 이동시킨다.
			paramHm.put("addr_email", input_id);
			paramHm.put("addr_seq", resultHm.get("addr_seq"));
			paramHm.put("addr_pwd", change_password_enc);
//System.out.println(paramHm);	
			int rcnt = loginService.updateUserPassword(paramHm);
			if ( rcnt == 0 ) {
				//업데이트 안됨
				messageHm.put("message", "비밀번호 업데이트에 실패하였습니다.");
			} else {
				//업데이트 됨
				messageHm.put("isLogin", "true");
				messageHm.put("message", "비밀번호가 변경되었습니다.");
				
				HttpSession session  			=  request.getSession();
				resultHm.put("loginType", loginType);
				SessionManager.MakeSession(session, resultHm, StringUtil.nullToEmpt(paramHm.get("login_ip")));
				
				messageHm.put("loginsuccess", "N");
				loginService.updateUserLogin(paramHm);
			}
			
		}
		return messageHm;
	}
	
}
