package com.deri.proxy.doc.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * 
 * 보고서 생성 컨트롤러

 * @author 
 *
 */
@Controller
public class DocController {

	@RequestMapping(value = {"/doc"}, method = RequestMethod.GET)
	public String index( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/doc/doc.tiles";
	}
	
	@RequestMapping(value = {"/doc/analysis"}, method = RequestMethod.GET)
	public String analysis( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/doc/doc_analysis.tiles";
	}
	
	@RequestMapping(value = {"/doc/correct"}, method = RequestMethod.GET)
	public String correct( 	HttpServletRequest request, HttpServletResponse response, 
							Model model	) {
	
		
		return "/web/doc/doc_correct.tiles";
	}
	
	@RequestMapping(value = {"/doc/examination","/doc/finish","/doc/old"}, method = RequestMethod.GET)
	public String examination( 	HttpServletRequest request, HttpServletResponse response, 
								Model model	) {


		return "/web/doc/doc_correct.tiles";
	}
}
