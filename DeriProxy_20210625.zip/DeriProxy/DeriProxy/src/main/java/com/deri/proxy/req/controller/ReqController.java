package com.deri.proxy.req.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.deri.common.util.BoardFileVo;
import com.deri.common.util.SessionManager;
import com.deri.common.util.StringUtil;
import com.deri.common.util.PageUtil;
import com.deri.proxy.Define;
import com.deri.proxy.common.service.CommonService;
import com.deri.proxy.common.service.SendMailService;
import com.deri.proxy.req.service.ReqService;
import com.deri.proxy.user.service.CompanyService;

/**
 * 
 * 의안분석 요청 컨트롤러
 * 
 * @author 
 *
 */
@Controller
public class ReqController {

	private static final Logger logger = LoggerFactory.getLogger(ReqController.class);
	
	@Autowired private ReqService				reqService;
	@Autowired private CompanyService			companyService;
	@Autowired private CommonService			commonService;

	String uploadPath = "/resources/upload/req";
	
	@ResponseBody
	@RequestMapping(value = {"/req/test"}, method = RequestMethod.GET)
	public String list( 	HttpServletRequest request, HttpServletResponse response, 
							
							Model model	) {
		
		
		//boolean isSend = mailService.sendMail("jaeyoung.jang@daishin.com", "이메일테스트", "이메일 발송 테스트");
		boolean isSend = false;
		try {
			isSend = SendMailService.sendMail("jaeyoung.jang@daishin.com", "보내는사람이름변경3", "이메일 발송 테스트<br><Br>html 도 확인");
			//isSend = SendMailService.sendMail2("jaeyoung.jang@daishin.com", "이메일테스트", "이메일 발송 테스트");
		} catch (Exception e){
			e.printStackTrace();
		}
		if (isSend)
		{
			System.out.println("email send finish");
			return "메일이 발송되었다!!";
		}
		else
		{
			System.out.println("email send error");
			return "메일 보내기 실패 : 로그 확인 바람.!!";
		}
				
		
	}
	
	
	/**
	 * 의안분석 요청 목록
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/req"}, method = RequestMethod.GET)
	public String list( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="use_yn", required=false, defaultValue="") String use_yn,
							@RequestParam(value="co_code", required=false, defaultValue="") String co_code,
							@RequestParam(value="jm_code", required=false, defaultValue="") String jm_code,
							@RequestParam(value="jm_name", required=false, defaultValue="") String jm_name,
							
							@RequestParam(value="req_title_content", required=false, defaultValue="") String req_title_content,
							
							@RequestParam(value="pageno", required=false, defaultValue="1") String pageno,
			
							@RequestParam(value="pagecount", required=false, defaultValue="10") String pagecount,
			
							Model model	) {
	
		String loginType = SessionManager.getSession(request, "loginType");
		String viewPage = "cust";
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		if ( Define.LOGIN_TYPE_C.equals(loginType) ) {
			//고객용
			viewPage = "cust";
			
			co_code = SessionManager.getSession(request, "co_code");
			dbparam.put("co_code", co_code);
			
		} else if ( Define.LOGIN_TYPE_M.equals(loginType) ) {
			//분석담당자
			viewPage = "admin";
		} else if ( Define.LOGIN_TYPE_A.equals(loginType) ) {
			//관리자
			viewPage = "admin";
		}
		viewPage = "";
		
		//검색어 처리 영역
		dbparam.put("use_yn", use_yn);
		dbparam.put("co_code", co_code);
		dbparam.put("jm_code", jm_code);
		dbparam.put("jm_name", jm_name);
		dbparam.put("req_title_content", req_title_content);
		
		//전체 갯수 및 목록 호출부
		List<HashMap<String, Object>> list;
		int totalcnt = 0;
		Map<String, String> pageMap = new HashMap<String, String>();
		
		totalcnt = reqService.selectReqListCount(dbparam);
		PageUtil.pageSet(Integer.parseInt(pagecount),10);
		
		pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		list = reqService.selectReqList(dbparam);
		
		
		//목록
		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("pageno", pageno);
		model.addAttribute("pageMap", pageMap);
		model.addAttribute("list", list);
		
		model.addAttribute("pageno", pageno);
		
		
		//기관목록
		dbparam.clear();
		PageUtil.pageSet(40,10);
		pageMap = PageUtil.getPageStructure(1, 10000);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		model.addAttribute("companyList", companyService.selectCompanyList(dbparam));
		
		
		return "/web/req/req"+viewPage+".tiles";
	}
	
	/**
	 * 의안분석 조회
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/req/view"}, method = RequestMethod.GET)
	public String view( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="req_seq", required=false, defaultValue="") String req_seq,
							
							Model model	) {
	
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		HashMap<String, Object> content = new HashMap<String, Object>();
		List<HashMap<String, Object>> reply = new ArrayList<HashMap<String, Object>>();
		if ( !"".equals(req_seq) ) {
			dbparam.put("req_seq",  req_seq);
			content = reqService.selectReq(dbparam, false);
			
			//답변 목록을 호출 한다.
			reply = reqService.selectRepList(dbparam);
			
		}
		
		model.addAttribute("content", content);
		model.addAttribute("reply", reply);
		
		
		
		return "/web/req/req_view.tiles";
	}
	
	/**
	 * 의안분석 요청하기/수정하기
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/req/form"}, method = RequestMethod.GET)
	public String write( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="req_seq", required=false, defaultValue="") String req_seq,
							
							Model model	) {
	
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		

		HashMap<String, Object> content = new HashMap<String, Object>();
		if ( !"".equals(req_seq) ) {
			dbparam.put("req_seq",  req_seq);
			content = reqService.selectReq(dbparam, false);
		}
		
		model.addAttribute("content", content);
		
		
		String co_code = SessionManager.getSession(request, "co_code");
		if ( "".equals(co_code) ) {
			//로그인한 기관이 아니고 어드민 이라면 기관 목록을 리스트업 한다.
			
			//기관목록
			dbparam.clear();
			PageUtil.pageSet(40,10);
			Map<String, String> pageMap = new HashMap<String, String>();
			pageMap = PageUtil.getPageStructure(1, 10000);
			dbparam.put("pageHeader", pageMap.get("pageHeader"));
			dbparam.put("pageFooter", pageMap.get("pageFooter"));
			model.addAttribute("companyList", companyService.selectCompanyList(dbparam));
		}
		
		
		
		return "/web/req/req_form.tiles";
	}
	
	/**
	 * 의안분석 요청하기 프로세스 (취소포함)
	 * 취소요청은 이미 분석이 시작된 주총의 경우 alert 을 띄워준다.
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/req/proc"}, method = {RequestMethod.GET, RequestMethod.POST})
	public String proc( 	HttpServletRequest request, HttpServletResponse response, 
			
							@RequestParam(value="procMode", required=false, defaultValue="") String procMode,
							@RequestParam(value="idx", required=false, defaultValue="") String idx,
			
							@ModelAttribute("BoardFileVo") BoardFileVo files,
			 
							Model model) {
		
		Map<String, Object> result = new HashMap<String, Object>();
		
		String boardType = "";
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		String loginId = SessionManager.getSession(request, "loginId");
		dbparam.put("loginId", loginId);
		

		
		if ( "".equals(loginId)) {
			result.put("result", "false");
			result.put("message", "로그인 정보가 사라졌습니다. 새창으로 다시 로그인하여 주십시요.");
			
			model.addAttribute("result",result);
			return "/req/proc.empty";
		}
		
		
		//co_code, addr_email, addr_name, req_type, req_title, req_content, snum, del_yn, file_sys_nm, file_nm, regdate
		String req_seq = StringUtil.nullToEmpt(request.getParameter("req_seq"));
		
		String co_code = SessionManager.getSession(request, "co_code");
		String addr_email = SessionManager.getSession(request, "addr_email");
		String addr_name = SessionManager.getSession(request, "addr_name");
		String snum = SessionManager.getSession(request, "snum");
		
		String req_type = "";
		if ( !"".equals(snum) && "".equals(co_code)) {
			co_code = StringUtil.nullToEmpt(request.getParameter("co_code"));
			req_type = "A";
		} else {
			req_type = "C";
		}
		
		String req_title = StringUtil.nullToEmpt(request.getParameter("title"));
		String req_content = StringUtil.nullToEmpt(request.getParameter("content"));
		String del_yn = "N";
		String file_sys_nm = ""; 
		String file_nm = "";
		
		dbparam.put("co_code", co_code);
		dbparam.put("addr_email", addr_email);
		dbparam.put("addr_name", addr_name);
		dbparam.put("snum", snum);
		dbparam.put("del_yn", del_yn);
		dbparam.put("req_type", req_type);
		dbparam.put("req_title", req_title);
		dbparam.put("req_content", req_content);
		
		//디비에 저장하고
		result.put("result", "true");
		
		//결과 화면 RUL
		result.put("url", "");
		
		if ( !"".equals(idx) ) {
			dbparam.put("idx", idx);
		}
		
		MultipartFile file01 = files.getUploadFile01();
		
		String uploadPath = "/resources/upload/req";
		String realPath = request.getSession().getServletContext().getRealPath(uploadPath)+ "/";
		
		int isup = 0;
		try {
			
			if ( file01 != null ) { 
				
				Calendar cal = Calendar.getInstance();
				String fileType = "";//fileName.substring(fileName.lastIndexOf("."), fileName.length());
				String replaceName = "";//cal.getTimeInMillis() + fileType;
				String filesize = "";
				//
				File rPath = new File(realPath); //경로생성
				if ( !rPath.exists() ) {
					rPath.mkdirs(); //디렉토리 생성
				}
				
				if ( file01 != null ) { 
					if ( !file01.isEmpty() ) {
						fileType = file01.getOriginalFilename().substring(file01.getOriginalFilename().lastIndexOf("."), file01.getOriginalFilename().length());
						replaceName = cal.getTimeInMillis() + fileType;
						isup = FileCopyUtils.copy(file01.getInputStream(), new FileOutputStream(realPath+replaceName));
						if ( isup > 0 && !"".equals(file01.getName()) ) {
							dbparam.put("file_sys_nm", replaceName);
							dbparam.put("file_nm", file01.getOriginalFilename());
						}
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			
			result.put("result", "false");
			result.put("message", "파일 업로드에 실패하였습니다. 다시실행하여 주십시요.");
			
			model.addAttribute("result",result);
			return "/web/req/proc.empty";
		}
		
		
		
		//프로세싱 영역
		int resultcnt = 0;
		if ( "S".equals(procMode) ) { //글저장
			
			resultcnt = reqService.insertReq(dbparam);
			
			if ( "C".equals(req_type) ) {
				//고객이 요청한 글이라면 대상자에게 쪽지 발송을 위해 큐에 쌓는다.
				HashMap<String, Object> param = new HashMap<String, Object>();
				param.put("message_type", "요청");//수신자유형 : 요청, 템플릿, 분석완료
				String message_content = "";
				String co_name = SessionManager.getSession(request, "co_name");
				message_content = co_name + " [" +req_title+ "]" + " Proxy CRM 요청 접수";
				param.put("message_content", message_content);
				commonService.insertMessageContent(param);
			}
			
			
		} else if ( "M".equals(procMode) ) { //글수정
			
			//수정은 기존 컨텐츠를 M 으로 변경하고 새로 insert 한다.
			resultcnt = reqService.insertReq(dbparam);
			dbparam.put("del_yn", "M");
			resultcnt = reqService.deleteGbReq(dbparam);
			//resultcnt = reqService.updateReq(dbparam);
			
		} else if ( "D".equals(procMode) ) { //글삭제
			
			dbparam.put("del_yn", "Y");
			resultcnt = reqService.deleteGbReq(dbparam);
			
		} else if ( "DD".equals(procMode) ) { //글 완전 삭제
			
			resultcnt = reqService.deleteReq(dbparam);
		}
		
		if ( resultcnt == 1 ) {
			result.put("message", "처리가 완료 되었습니다.");
				
		} else {
			result.put("resultcnt", "["+resultcnt+"]");
			result.put("result", "false");
			result.put("message", "오류가 발생 하였습니다.");
		}
	
		//프로세스 처리결과
		model.addAttribute("result",result);
		return "/web/req/proc.empty";
	}
	
	
	
	
	//리플
	@ResponseBody
	@RequestMapping(value = {"/rep/proc"}, method = {RequestMethod.GET, RequestMethod.POST})
	public HashMap<String, Object> repproc( 	HttpServletRequest request, HttpServletResponse response, 
			
							@RequestParam(value="procMode", required=false, defaultValue="") String procMode,
							@RequestParam(value="rep_content", required=false, defaultValue="") String rep_content,
							@RequestParam(value="req_seq", required=false, defaultValue="") String req_seq,
			 
							Model model) {
		
		HashMap<String, Object> result = new HashMap<String, Object>();
		result.put("isSuccess", false);
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		String loginId = SessionManager.getSession(request, "loginId");
		dbparam.put("loginId", loginId);
		
		if ( "".equals(loginId)) {
			result.put("message", "로그인 정보가 사라졌습니다. 새창으로 다시 로그인하여 주십시요.");
			return result;
		}
		
		if ( "".equals(rep_content) || "".equals(req_seq) ) {
			result.put("message", "잘못된 호출 입니다.");
			return result;
		}
		
		//String rep_content = StringUtil.nullToEmpt(request.getParameter("rep_content"));
		//String req_seq = StringUtil.nullToEmpt(request.getParameter("req_seq"));
		
		dbparam.put("snum", loginId);
		dbparam.put("req_seq", req_seq);
		dbparam.put("rep_content", rep_content);
		
		int resultCnt = reqService.insertRep(dbparam);
		if ( resultCnt < 1 ) {
			result.put("message", "등록을 실패하였습니다.");
			return result;
		} else {
			result.put("isSuccess", true);
			result.put("message", "등록 되었습니다.");
			return result;
		}
		
		
	}
	
	
	//파일 다운로드
	@RequestMapping(value = {"/req/file"}, method = {RequestMethod.GET, RequestMethod.POST})
	protected void fileopen( HttpServletRequest request, HttpServletResponse response,
			
							@RequestParam(value="req_seq", required=false, defaultValue="") String req_seq,
							@RequestParam(value="file_nm", required=false, defaultValue="") String file_nm,
							
							@ModelAttribute("BoardFileVo") BoardFileVo param
							) throws Exception {
			  
		
		String realPath = request.getSession().getServletContext().getRealPath(uploadPath)+ "/"+param.getBoardType()+"/";
				
		//게시물을 조회하고
				
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		dbparam.put("req_seq",  req_seq);
		//dbparam.put("file_nm",  file_nm);
		
		//System.out.println(dbparam);
		HashMap<String, Object> hm = new HashMap<String, Object>();
		hm = reqService.selectReq(dbparam, false);
		
		//file_nm 값이 없을경우 어떻게 할 것인가. empty text 파일을 내린다.
		File file = null;
		String fileName = "";
		
		if ( hm == null ) {
			response.setContentType("text/html; utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('잘못된 페이지 요청입니다.1');location.href='#';</script>");
			out.flush();
			return;
		}
		
		//System.out.println(param.getFile_nm());
		//System.out.println(hm.get("file_nm"));
		
		if ( param.getFile_nm().equals(hm.get("file_nm")) ) {
			
			file = new File(realPath + hm.get("file_sys_nm"));
			fileName = String.valueOf(hm.get("file_nm"));
			
		} else {
			
			response.setContentType("text/html; utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>alert('잘못된 페이지 요청입니다.2');location.href='#';</script>");
			out.flush();
			return;
		
		}
		
		//파일 다운로드 로그를 남긴다.
		boolean isCustomer = false;
		
		if ( Define.LOGIN_TYPE_C.equals(SessionManager.getSession(request, "loginType") ) ) {
			isCustomer = true;
		}
		
		if ( file != null ) {
					
			//파일 다운로드 카운트 증가하고 로그 쌓는다
			
			String snum = SessionManager.getSession(request, "snum");
			String addr_email = SessionManager.getSession(request, "addr_email");
			
			
			String ip = request.getHeader("X-Forwarded-For");
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("Proxy-Client-IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("WL-Proxy-Client-IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("HTTP_CLIENT_IP"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getHeader("HTTP_X_FORWARDED_FOR"); 
	    	} 
	    	if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) { 
	    	    ip = request.getRemoteAddr(); 
	    	}
	    	String aip = ip;
	    	
	    	
	    	//처리 결과를 입력한다.
			HashMap<String, Object> resultHm = new HashMap<String, Object>();
			if ( isCustomer ) {
				/*
				//고객의 경우 Log 쌓기.
				reqService.updateReportDownCnt(dbparam);
				
				//doc_seq, co_code, addr_email, regdate
				resultHm.put("doc_seq", req_seq);
				resultHm.put("co_code", SessionManager.getSession(request, "co_code"));
				resultHm.put("addr_email", SessionManager.getSession(request, "addr_email"));
				reqService.insertReportDownCnt(resultHm);
				*/
			}
			
			
			
			
			response.setContentType("application/pdf; utf-8");
			response.setContentLength((int) file.length());
				 
			String userAgent = request.getHeader("User-Agent");
					
			//fileName = java.net.URLEncoder.encode(fileName,"utf-8");
			//fileName = fileName.replace("+"," ");
					
			if ( !"".equals(param.getViewmode()) ) {
				response.setHeader("Content-Disposition", "inline;");
			} else {
				if (userAgent.indexOf("MSIE") > -1 || userAgent.indexOf("Trident") > -1) {   // 					
					fileName = java.net.URLEncoder.encode(fileName, "UTF-8").replaceAll("\\+", "%20");
					response.setHeader("Content-Disposition", "attachment; filename=" + fileName);
				} else {                                                                                             					
					response.setHeader("Content-Disposition", "attachment; filename="  + new String(fileName.getBytes("UTF-8"), "ISO-8859-1").replaceAll("\\+", "\\ ") + ";");
				}
				
				response.setHeader("Content-Transfer-Encoding", "binary");
			}
			
			
			OutputStream out = response.getOutputStream();
			FileInputStream fis = null;
			try {
				fis = new FileInputStream(file);
				FileCopyUtils.copy(fis, out);
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				if (fis != null) {
					try {
						fis.close();
					} catch (Exception e) {
					}
				}
			}
			out.flush();
		}
	}
	
}


