package com.deri.proxy.job.service;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.deri.proxy.job.dao.JobCustomerDao;


@Service
public class JobCustomerService {

	@Autowired private JobCustomerDao jobCustomerDao;
	
	
	//목록
	public int selectJobCustomerListCount(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobCustomerDao.selectJobCustomerListCount(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	public List<HashMap<String, Object>> selectJobCustomerList(HashMap<String, Object> param) {
		List<HashMap<String, Object>> result = null;
		try {
			result = jobCustomerDao.selectJobCustomerList(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//조회
	public HashMap<String, Object> selectJobCustomer(HashMap<String, Object> param) {
		HashMap<String, Object> result = null;
		try {

			result = jobCustomerDao.selectJobCustomer(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
			
	//등록
	public int insertJobCustomer(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobCustomerDao.insertJobCustomer(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//수정
	public int updateJobCustomer(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobCustomerDao.updateJobCustomer(param);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
		
	//삭제
	public int deleteGbJobCustomer(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobCustomerDao.deleteGbJobCustomer(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	//완전 삭제
	public int deleteJobCustomer(HashMap<String, Object> param) {
		int result = 0;
		try {
			result = jobCustomerDao.deleteJobCustomer(param);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	
	
}
