package com.deri.proxy.common.controller;

import java.io.FileInputStream;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CommonController {

	
	public void excelDown(String excelPath, HttpServletResponse response, List<List<String>> lists, String filename, List<String> header) {
		FileInputStream file = null;
		XSSFWorkbook wb = null;
		try {
			
			file = new FileInputStream(excelPath);
			wb = new XSSFWorkbook(file);
			
			XSSFSheet sheet = wb.getSheetAt(0);

			int columnIndex = 0;
			int count = 1;
			XSSFCell cell = null;
			int rows = sheet.getPhysicalNumberOfRows();	

			CellStyle style = wb.createCellStyle();
			style.setAlignment(HSSFCellStyle.ALIGN_CENTER);
			
			if(header != null) {
				XSSFRow row = sheet.createRow(rows++);
				columnIndex = 0;
//				cell = row.createCell(columnIndex++);
//				cell.setCellStyle(style);
//				cell.setCellType(cell.CELL_TYPE_STRING);
//				cell.setCellValue(count++ + "");
				
				for(String data : header) {
					cell = row.createCell(columnIndex++);
					cell.setCellStyle(style);
					cell.setCellType(cell.CELL_TYPE_STRING);
					cell.setCellValue(data);
				}
			}
			
			style.setAlignment(HSSFCellStyle.ALIGN_LEFT);
			
			for(List<String> list : lists) {
				XSSFRow row = sheet.createRow(rows++);
				columnIndex = 0;
//				cell = row.createCell(columnIndex++);
//				cell.setCellStyle(style);
//				cell.setCellType(cell.CELL_TYPE_STRING);
//				cell.setCellValue(count++ + "");
				
				for(String data : list) {
					cell = row.createCell(columnIndex++);
					cell.setCellStyle(style);
					cell.setCellType(cell.CELL_TYPE_STRING);
					cell.setCellValue(data);
				}
			}

			SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
			Calendar cal = Calendar.getInstance();
			String today = format.format(cal.getTime());
			Timestamp time = Timestamp.valueOf(today);
			
			response.setContentType("ms-vnd/excel");
			response.setHeader("Content-Disposition", "attachment;filename=" + filename + "_" + time.getTime() + ".xlsx");
			wb.write(response.getOutputStream());
			wb.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}
