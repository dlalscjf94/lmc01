package com.deri.proxy.job.dao;

import java.util.HashMap;
import java.util.List;

public interface JobCustomerDao {

	
	///////////////////////////////발송 대상 보고서 목록/////////////////////////////////////////////////
	//목록
	public int selectJobCustomerListCount(HashMap<String, Object> param);
	public List<HashMap<String, Object>> selectJobCustomerList(HashMap<String, Object> param);
	
	
	///////////////////////////////조회/////////////////////////////////////////////////
	//조회
	public HashMap<String, Object> selectJobCustomer(HashMap<String, Object> param);
	
	
	///////////////////////////////등록/////////////////////////////////////////////////
	//등록
	public int insertJobCustomer(HashMap<String, Object> param);
	
	
	///////////////////////////////수정/////////////////////////////////////////////////
	//수정
	public int updateJobCustomer(HashMap<String, Object> param);
	
	
	///////////////////////////////삭제/////////////////////////////////////////////////
	//삭제
	public int deleteGbJobCustomer(HashMap<String, Object> param);
	
	
	///////////////////////////////완전 삭제/////////////////////////////////////////////////
	//완전 삭제
	public int deleteJobCustomer(HashMap<String, Object> param);



}
