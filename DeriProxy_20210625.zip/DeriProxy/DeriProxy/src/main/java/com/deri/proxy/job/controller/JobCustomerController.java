package com.deri.proxy.job.controller;

import java.io.File;
import java.io.FileOutputStream;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.deri.common.util.BoardFileVo;
import com.deri.common.util.SessionManager;
import com.deri.common.util.StringUtil;
import com.deri.common.util.PageUtil;
import com.deri.proxy.Define;
import com.deri.proxy.common.service.CommonService;
import com.deri.proxy.job.service.JobCustomerService;
import com.deri.proxy.job.service.JobService;
import com.deri.proxy.user.service.CompanyService;

/**
 * 
 * 의안분석 완료 및 보고서 등록전 대상 처리 컨트롤러
 * 
 * @author 
 *
 */
@Controller
public class JobCustomerController {

	private static final Logger logger = LoggerFactory.getLogger(JobCustomerController.class);
	
	@Autowired private CommonService			commonService;
	@Autowired private JobService				jobService;
	@Autowired private JobCustomerService		jobCustomerService;
	@Autowired private CompanyService			companyService;
	
	/**
	 * 의안분석 완료 목록
	 * @param request
	 * @param response
	 * @param model
	 * @return
	 */
	@RequestMapping(value = {"/jobCustomer"}, method = RequestMethod.GET)
	public String list( 	HttpServletRequest request, HttpServletResponse response, 
							
							@RequestParam(value="use_yn", required=false, defaultValue="") String use_yn,
							@RequestParam(value="co_code", required=false, defaultValue="") String co_code,
							@RequestParam(value="tem_type", required=false, defaultValue="") String tem_type,
							@RequestParam(value="jm_code", required=false, defaultValue="") String jm_code,
							@RequestParam(value="jm_name", required=false, defaultValue="") String jm_name,
							@RequestParam(value="pageno", required=false, defaultValue="1") String pageno,
							@RequestParam(value="pagecount", required=false, defaultValue="10") String pagecount,
							@RequestParam(value="meet_gb", required=false, defaultValue="") String meet_gb,
							@RequestParam(value="gumsu_yn", required=false, defaultValue="Y") String gumsu_yn,
							@RequestParam(value="doc_yn", required=false, defaultValue="N") String doc_yn,
							
			
							Model model	) {
	
		String loginType = SessionManager.getSession(request,"loginType");
		String viewPage = "cust";
		
		//System.out.println("loginType:"+loginType + ":" + SessionManager.getSession(request,"loginType"));
		
		HashMap<String, Object> dbparam = new HashMap<String, Object>();
		
		//검색어 처리 영역
		dbparam.put("use_yn", use_yn);
		dbparam.put("co_code", co_code);
		dbparam.put("tem_type", tem_type);
		dbparam.put("jm_code", jm_code);
		dbparam.put("jm_name", jm_name);
		dbparam.put("meet_gb", meet_gb);
		
		model.addAttribute("gumsu_yn", gumsu_yn);
		model.addAttribute("doc_yn", doc_yn);
		
		if ( "all".equals(gumsu_yn)) gumsu_yn = "";
		if ( "all".equals(doc_yn)) doc_yn = "";
		
		dbparam.put("gumsu_yn", gumsu_yn);
		dbparam.put("doc_yn", doc_yn);
		
		
		//전체 갯수 및 목록 호출부
		List<HashMap<String, Object>> list;
		int totalcnt = 0;
		Map<String, String> pageMap = new HashMap<String, String>();
		
		totalcnt = jobCustomerService.selectJobCustomerListCount(dbparam);
		PageUtil.pageSet(Integer.parseInt(pagecount),10);
		
		pageMap = PageUtil.getPageStructure(Integer.parseInt(pageno), totalcnt);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		list = jobCustomerService.selectJobCustomerList(dbparam);
		
		
		//목록
		model.addAttribute("totalcnt", totalcnt);
		model.addAttribute("pageno", pageno);
		model.addAttribute("pageMap", pageMap);
		model.addAttribute("list", list);
		
		model.addAttribute("pageno", pageno);
		
		//기관목록
		dbparam.clear();
		PageUtil.pageSet(40,10);
		pageMap = PageUtil.getPageStructure(1, 10000);
		dbparam.put("pageHeader", pageMap.get("pageHeader"));
		dbparam.put("pageFooter", pageMap.get("pageFooter"));
		model.addAttribute("companyList", companyService.selectCompanyList(dbparam));
		
		
		return "/web/jobCustomer/jobCustomer.tiles";
	}
	
	
}


