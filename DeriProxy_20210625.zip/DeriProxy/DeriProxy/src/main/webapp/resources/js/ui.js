$(document).ready(function(){
	if( $('#nav').length ) { navi(); } //상단 네이게이션
	if( $('.setPsOff').length ) { mySet(); }
	if( $('.scrapBtnArea').length ) { snsSet(); }
	if( $('.familySite').length ) { family(); } //푸터 패밀리사이트
	if( $('.calendarbox').length ) { calendar(); } //달력
	$('.btnAllPrint').click(printPage); //인쇄
	
	Tab(); //탭메뉴2
	layerPopOpen(); //레이어팝업
	summaryList(); //
	faqToggle(); //faqToggle
//	menuAreaToggle(); //펀드매매 STEP
	slideDownList(); //종목검색
	setupBox(); //차트설정영역
	overLayer(); //overLayerPopup
	clickLayer(); //OverLayerPopup

//	if( $('.tipOpen').length ) { tipMenu(); } //종목에 팁메뉴
	
	if( $('.stepList').length ) { stepA(); }
	if( $('.findH').length ) { findH(); } //높이값구하기
	if( $('.findHUl').length ) { findHUl(); } //높이값구하기
	if( $('.findHOl').length ) { findHOl(); } //높이값구하기
	if( $('.checkPointBox').length ) { checkPointBox(); }	 //tableProdList th 높이값구하기
	if( $('.tabNav').length ) { tabMenus(); } //탭메뉴

	$(".tipBox .tipBoxClose").click(function(){ //tipBox
		$('.tipBox').hide();
		return false;
	})
	
	if( $('.gnb').length ) {  Nav(); } //네비게이션
	if( $('.miniGnb').length ) {  miniGnb(); } //모의투자, 퇴직연금 네비게이션
	if( $('.breadCrumb').length ) {  breadCrumb(); } //로케이션	
	if( $('.fundDashboard').length ) { doFundDashboardNav(); } //글로벌펀드동향
	if( $('.fundDashboardMap').length ) { doControlMap(); } //글로벌펀드동향
	if( $('.radioStyle').length ) { doCustomRadio(); } //라디오 디자인 버튼
	if( $('.searchList').length ) { doCustomSelect(); } //셀렉트 디자인
	if( $('.alternativeInvest').length ) { alternativeInvest(); }
	if( $('.logBox input').length ) { logBox(); } //로그인폼
	if( $('.popStockGuide').length ) { stockGuide(); } //증권업무 안내 팝업 내 함수
	if( $('.sidebar').length ) { sidebar(); }	
	if( $('.todayBanner').length ) { doSlider('.todayBanner', 2900, 'true'); } //메인 비주얼 영역 슬라이드 함수 실행, 파라메터 (슬라이드 실행 영역, 모션 간격, 자동플레이)
	if( $('.todayBox').length ) { doSlider('.todayBox', 5400, 'true'); } //메인 비주얼 영역 슬라이드 함수 실행, 파라메터 (슬라이드 실행 영역, 모션 간격, 자동플레이)
	if( $('.eventArea').length ) { doSlider('.eventArea', 5400, 'true'); } //메인 비주얼 영역 슬라이드 함수 실행, 파라메터 (슬라이드 실행 영역, 모션 간격, 자동플레이)
	if( $('.seminarBox').length ) { doSlider('.seminarBox', 2900, 'true'); } //메인 비주얼 영역 슬라이드 함수 실행, 파라메터 (슬라이드 실행 영역, 모션 간격, 자동플레이)
	if( $('.slideBanner').length ) { doSlider('.slideBanner', 5400, 'true'); } //메인 비주얼 영역 슬라이드 함수 실행, 파라메터 (슬라이드 실행 영역, 모션 간격, 자동플레이)
	if( $('.todayReport').length ) { doVerticalSlider('.todayReport', 5400, 'true'); } //메인 비주얼 영역 슬라이드 함수 실행, 파라메터 (슬라이드 실행 영역, 모션 간격, 자동플레이)
	
	
});

$(window).load(function() {
	if( $('.tabDefault').length ) { addTabTitle(); }
});

function addTabTitle(){
	var l_bTabTitle = $(".tabDefault").attr("bTabTitle");
	if(l_bTabTitle == "false") return;
	
	var l_sContentTitle = $("head>title").html();
	var l_sActiveTabNm = $(".tabDefault").find("li.on>a").text();
	//$("head>title").html(l_sActiveTabNm + " - " + l_sContentTitle);
	document.title = l_sActiveTabNm + " - " + l_sContentTitle;
}

function stepA(){
	$('.stepList').find('li.on').prepend('<span class="hTitle">현재진행단계</span>');
}

function Nav(){
	$('.depth4').parent().addClass('incSub');
	var timeS;
	$(".gnb > li .depth1").bind('mouseover focus', function(){
		var current = $(this).parent().index();
		function gnbS() {
			$('.gnb > li').each(function(i){
				if(i == current){
					$(this).find('.snbWrap').css('visibility','visible');
					$(this).addClass('on');
				}else{
					$(this).find('.snbWrap').css('visibility','hidden');
					$(this).removeClass('on');
				};
			});	
		}
		timeS = setTimeout(gnbS,200);		
	});
	if( $('.mnArea .depth3' ).parent().has('.incSub') ){
		$('.incSub').mouseover(function(){						
			$('.mnArea .depth4').removeAttr('style');
			NavDepth();
			$(this).addClass('on');
		})
	}
	$(".gnb > li").mouseleave(function(){
		function gnbE(){
			$(".gnb > li").find('.snbWrap').css('visibility','hidden');
			$(".gnb > li").removeClass('on');
			$('.gnb li').find('.depth1').removeClass('on');
		}
		var timeE = setTimeout(gnbE,200);
		clearTimeout(timeS);
	});
	$('.mnArea').mouseleave(function(){
		$('.mnArea .depth4').removeAttr('style');
	})

	$(".gnbSearch > a, .gnbHouse > a").focus(function(){
		$(".gnb > li").find('.snbWrap').css('visibility','hidden');
		$('.gnb > li').removeClass('on');
		$('.gnb > li').find('.depth1').removeClass('on');
	})
};

function miniGnb(){
	//$('.snbWrap').hide();

	$(".miniGnb").bind('mouseover focus', function(){
		//$('.snbWrap').show();
		$('.snbWrap').css('visibility','visible');
		if($('.mnArea').has('.depth4')){
			$('.depth4').parent().addClass('incSub');
			$('.incSub').mouseover(function(){
				$('.mnArea .depth4').removeAttr('style');
				NavDepth();
				$(this).addClass('on');
			})
		}
	});

	$(".miniGnb").bind('mouseleave', function(){
		$('.snbWrap').css('visibility','hidden');
		$('.mnArea .depth4').removeAttr('style');
		
		//$('.miniGnb > li').find('.depth1').removeClass('on');
	});
	$('.mnArea').mouseleave(function(){
		$('.mnArea .depth4').removeAttr('style');
	})

	$(".miniGnb > li .depth1").bind('focus', function(e){
		$(".mnArea").removeClass("on");
		$('.snbWrap').css('visibility','visible');
	});

	$(".miniGnb > li .depth1").keydown(function(e){
		var miniGnbCurrent;
		var length;

		if(e.which == 9 && e.shiftKey){
			if($(this).parent().index() > 0){
				miniGnbCurrent = $(this).parent().index() - 1;
				length = $(".snbWrap > ul > li").eq(miniGnbCurrent).find("> ul").find("> li").length - 1;
			}else{
				return;
			};
			
			$(".snbWrap > ul > li").eq(miniGnbCurrent).find("> ul").find("> li:eq(" + length + ") > div").find("> a").focus();
			e.stopPropagation();
			e.preventDefault();

		}else if(e.which == 9){
			if($(this).parent().index() < $(".miniGnb > li").length){
				miniGnbCurrent = $(this).parent().index();
			}else{
				return;
			};
			
			$(".snbWrap > ul > li").eq(miniGnbCurrent).find("> ul").find("> li:eq(0) > div").find("> a").focus();
			e.stopPropagation();
			e.preventDefault();
		};
	});

	$(".snbWrap > ul > li > ul > li:first-child div > a").keydown(function(e){
		var miniGnbCurrent;
		
		if(e.which == 9 && e.shiftKey){
			if($(this).parent().parent().parent().parent().index() >= 0){
				miniGnbCurrent = $(this).parent().parent().parent().parent().index();
			}else{
				return;
			};

			$(".miniGnb > li").eq(miniGnbCurrent).find("a").focus();
			e.stopPropagation();
			e.preventDefault();
		};
	});

	$(".snbWrap > ul > li > ul > li:last-child > div > a").keydown(function(e){
		var miniGnbCurrent;
		
		if(e.which == 9 && e.shiftKey){
			
		}else if(e.which == 9){
			if($(this).parent().parent().parent().parent().index() < $(".miniGnb > li").length - 1 && $(this).parent().hasClass("incSub") == false){
				miniGnbCurrent = $(this).parent().parent().parent().parent().index() + 1;
			}else{
				return;
			};
			
			$(".miniGnb > li").eq(miniGnbCurrent).find("a").focus();
			e.stopPropagation();
			e.preventDefault();
		};
	});

	$(".snbWrap > ul > li > ul > li:last-child > div .depth4 > ul > li:last-child > a").keydown(function(e){
		var miniGnbCurrent;
		
		if(e.which == 9 && e.shiftKey){
			
		}else if(e.which == 9){
			if($(this).parent().parent().parent().parent().parent().parent().parent().index() < $(".miniGnb > li").length - 1){
				miniGnbCurrent = $(this).parent().parent().parent().parent().parent().parent().parent().index() + 1;
			}else{
				return;
			};
			
			$(".miniGnb > li").eq(miniGnbCurrent).find("a").focus();
			e.stopPropagation();
			e.preventDefault();
		};
	});

	$(".snbWrap").bind('mouseover',function(){
		$('.snbWrap').css('visibility','visible');
	});

	$(".snbWrap").bind('mouseleave',function(){
		$('.snbWrap').css('visibility','hidden');
	});

	$(".myAssetProd select, .breadCrumb > a, .logMn > a").focus(function(){
		$('.snbWrap').css('visibility','hidden');
	});
};

function NavDepth(){
	$('.snbWrap ul li ul li').removeAttr('style');
	$('.mnArea').find('.depth4').each(function(){
		$gnbSub = $(this);
		$gnbSubW = $gnbSub.width();
		$gnbSubM = $gnbSub.parent().find('a.depth3').width();		
		$gnbSub.css('min-width','90px');
		$gnbSub.css('width',$gnbSubW+15);		
		$gnbSub.css('left',$gnbSubM+20);
	})

	$('.findH li:nth-child(5) .mnArea .depth4').addClass('lastMn');
	$('.findH li ul li:nth-child(5) .mnArea .depth4').removeClass('lastMn');
	$('.findH li:nth-child(5) ul li:nth-child(5) .mnArea .depth4').addClass('lastMn');
	
	$('.incSub').find('.depth3').each(function(){
		/*$(this).bind('mouseover focus', function(){
			$(this).parent().addClass('on');
		})*/
		$('.incSub').mouseover(function(){
			$(this).addClass('on');
		})
		$('.incSub').mouseleave(function(){
			$(this).removeClass('on');
		})
		/*$('.depth4 li:last-child').focusout(function(){
			$('.incSub').removeClass('on');
		})*/
	})

	$(".mnArea .depth3").focus(function(){
		if($(this).parent().hasClass("incSub")){
			$(".mnArea").removeClass("on");
			$(this).parent().addClass('on');
		}else{
			$(".mnArea").removeClass("on");
		};
	});

	$(".depth2").focus(function(){
		$(".mnArea").removeClass("on");
	});
}
//피싱, 파밍 미설정
function mySet(){
	$('.setPsOff a.tipShow').bind('mouseover focus', function(){
		$('.setPsOff .tip').show();
	})
	$('.setPsOff').mouseleave(function(){
		$(this).parent().find('.tip').hide();
	})
	$('.setPsOff .tip a').focusout(function(){
		$('.setPsOff .tip').hide();
	})
}
//퍼가기
function snsSet(){
	$('.scrapBtnArea a.btnScrap').focus(function(){
		$('.scrapBtnArea').addClass('on');
	})
	$('.scrapBtnArea .scrapArea li.last').focusout(function(){
		$('.scrapBtnArea').removeClass('on');
	})
	$('.dicBtnArea a.btnDic').focus(function(){
		$('.scrapBtnArea').removeClass('on');
	})
}
//footer
function family(){
	$('#footer .outArea .familySite a.title').click(function(){
		$('.familyArea').slideToggle(function(){
			 if($(this).is(":visible")){
				$('.familySite a.title').addClass('close');
			} else {
				$('.familySite a.title').removeClass('close');
			}
		})
		$('.familyArea').mouseout(function(){
			$('.familyArea').hide();
			$('.familySite a.title').removeClass('close');
		})
		$('.familyArea').mouseover(function(){
			$('.familyArea').show();
		})
		$('.familyArea li:last-child').focusout(function(){
			$('.familyArea').hide();
		})
		return false;
	})
}

function sidebar() {
	var $sidebar = $('#aside'),
		$sidebarTrigger = $('.sidebarBlinde'),
		$sidebarTrigger2 = $('.sidebarX'),
		$DropdownTrigger = $('.sidebarNav a'),
		$Dropdown = $('.dropdownGroup > div'),
		$count = $('.sidebarNav .count');

	$sidebarTrigger.on({
		click : function() {
			if ($sidebar.hasClass('active')) {
				closeSlide();
				$(this).text('My자산 Today 정보 레이어 열기');
			} else {
				openSlide();
				$sidebar.addClass('active');
				$DropdownTrigger.eq(0).parent().toggleClass('active');
				$(this).text('My자산 Today 정보 레이어 닫기');
				$Dropdown.eq(0).addClass('active').siblings().removeClass('active');
			}

			return false;
		}
	});

	$sidebarTrigger2.on({
		click : function() {
			if ($sidebar.hasClass('active')) {
				closeSlide();
			} else {
				openSlide();
				$sidebar.addClass('active');
				$DropdownTrigger.eq(0).parent().toggleClass('active');
				$Dropdown.eq(0).addClass('active').siblings().removeClass('active');
			}

			return false;
		}
	});

	$DropdownTrigger.on({
		click : function() {
			openSlide();
			$(this).parent().addClass('active').siblings().removeClass('active');
			$Dropdown.eq($(this).parent().index()).addClass('active').siblings().removeClass('active');
			$sidebar.addClass('active');
			$sidebarTrigger.text('My자산 Today 정보 레이어 닫기');

			return false;
		}
	});

	$count.on({
		click : function() {
			$(this).prev().trigger('click');

			return false;
		}
	});

	function openSlide() {
		$sidebar.animate({
			right : 0
		}, 200);
	}

	function closeSlide() {
		$sidebar.animate({
			right : -265
		}, 200, function() {
			$sidebar.removeClass('active');
			$DropdownTrigger.parent().removeClass('active');
		});
	}
}

//로케이션
function breadCrumb(){
	breadW();
	$('.breadCrumb .depth2 a.depth').bind('focus click', function(){
		$(this).addClass('on');
		$('.subCate').css('visibility','visible');
		$('.subCate').mouseleave(function(){
			$(this).parent().find('a.depth').removeClass('on');
			$(this).css('visibility','hidden');
		})
		return false;
	})
	$('.subCate li:last-child').focusout(function(){
		$('.breadCrumb .depth2 a.depth').removeClass('on');
		$('.subCate').css('visibility','hidden');
	})
	$('.breadCrumb .goHome').focus(function(){
		$('.subCate').css('visibility','hidden');
		$('.breadCrumb .depth2 a.depth').removeClass('on');
	})
	$('.breadCrumb p.mn a').focus(function(){
		$('.subCate').css('visibility','hidden');
		$('.breadCrumb .depth2 a.depth').removeClass('on');
	})
	function breadW(){
		$breadDepthW = $('.breadCrumb .subCate ul li').width() + 30;
		$('.breadCrumb .depth2').css('width',$breadDepthW);
		$('.subCate').css('width',$breadDepthW);
	}
}

//탭
function tabMenus(){
	var $tabMn = $(".tabArea");
    $tabMn.each(function(){
        var $trigger = $(this).find(".tabNav li a");
        var $tabCont = $(this).find(".tabContent"); 
        //$trigger.parent().eq(0).addClass("on"); 
        $tabCont.not(":first").hide();
        $trigger.each(function(){
            $(this).bind({
                "click" : function(){
                    if( !$(this).parent().hasClass("on") ){
                        var $clickCont = $($(this).attr("href"));                                               
                        $tabCont.hide();
                        $trigger.parent().removeClass("on");
                        $(this).parent().addClass("on");
                        $clickCont.show();
                    }
                    return false;
                }
            })
        })
    })
}

function Tab(){
	//$(".TabList .subCont").css("display","none"); // Tab
	//$(".TabList").find('.subCont:first').css("display","block");
	//$(".TabList .subTabM>li").click(function(){
		//$(".subCont").css("display","none");
		//$(".subCont").eq($(this).index()).css("display","block");
		//$(".subTabM>li").removeClass("on");
		//$(this).addClass("on");
		 //return false;
	//});

	$(".TabList").each(function(){
		$(this).find(".subCont").css("display", "none");
		$(this).find(".subCont:first").css("display", "block");
		$(this).find(".subTabM > li > a").click(function(){
			var inx = $(this).parent("li").index();
			$(this).parents(".subTabM").siblings(".subCont").hide().eq(inx).show();
			$(this).parent("li").addClass("on").siblings("li").removeClass("on");

			 return false;
		});
	});
}

//Nav
function navi(){
	var nav = $("div#nav");
	var navTop = nav.offset().top + 50;
	var navTopCheck = false;
	$(window).scroll(function () {
		var winTop = $(this).scrollTop();
		if (winTop >= navTop) {
			if(navTopCheck == false){
				navTopCheck = true;
				nav.css("top", "-100px");
				nav.addClass("fixed").stop().animate({top:"0"}, 250)
			};
		} else if (winTop <= navTop) {
			if(navTopCheck == true){
				navTopCheck = false;
				nav.removeClass("fixed");
			};
		}
	});
}

//AllPrint
function printPage() {
	window.print();
	return false;
}

////레이어팝업
function layerPopOpen(){
//	var dimmed = '<div class="dimmed"></div>';
	$(".popOpen").each(function(){
		var $pop = $($(this).attr("href"));
		$(this).click(function(){
//			$('body').append(dimmed);
//			$('#header').css('z-index','1');
			$('.layerPopup .layerBox').hide();
			$('.layerPopup').removeClass("on");
			$pop.show().parent().addClass("on");
			$(".popClose").click(function(){
				$pop.hide();
				$pop.parent().removeClass("on");
//				$('.dimmed').remove();
//				$('#header').removeAttr('style');

				return false;
			});
			$(".pClose").click(function(){
				$pop.hide();
				$pop.parent().removeClass("on");
//				$('.dimmed').remove();
//				$('#header').removeAttr('style');

				return false;
			});
			return false;
		})
	})
	
	$('.layerOperateAll .popClose').click(function(){
		$('.opArea a.popOpen').focus();
	})
}
//summary
function summaryList(){
	sumH = $('.summaryList li').height();
	$('.summaryList li').css('height',sumH);
}
//달력
function calendarFormat(chk){
	var str;
	var y = chk.substr(0,4);
	var m = chk.substr(4,2);
	var d = chk.substr(6,2);
	var mArray = new Array(1,3,5,7,8,10,12);
	var dChk = false;
	
	if(m > 12){
		alert("12월까지 있습니다.");

		return;
	};
	
	for(i = 0; i < mArray.length; i++){
		if(m == mArray[i]){
			dChk = true;
		};
	};

	if(m == 2){
//		console.log("2")
		if(d > 29){
			alert("29일? 28일?;;");

			return;
		};
	}else{

		if(dChk == false && d > 30){
			alert("30일까지 있습니다.");

			return;
		};

		if(dChk == true && d > 31){
			alert("31일까지 있습니다.")

			return;
		};
	};

//	console.log("final")
	str = y + "/" + m + "/" + d;

	return str;
};
function calendar(){
	$( ".datepicker" ).datepicker({
		beforeShow: function (input) { 
			//console.log('beforeShow');
			dpClearButton(input);
		}
		,onChangeMonthYear: function (input) { 
			//console.log('onChangeMonthYear');
			dpClearButton(input);
		}
		});

		function dpClearButton (input) {
			setTimeout(function() {
				$('<button type=button class=clear><span>clear</span></button>').click(function(){
					var instance = input;
						$.datepicker._clearDate( instance );
					}).insertAfter('.ui-datepicker-current.ui-state-default.ui-priority-secondary.ui-corner-all');
				$( "#ui-datepicker-div" ).wrapInner( "<div class='datepickerbox'></div>");
		}, 1 );
	}
	$(".calendarbox input").each(function(){
		
		$(this).focusout(function(){
			var str = $(this).val();
			str = str.split("/");
			str = str.join("");
			
			if(str.length > 0){
				if(str.length != 8){
					alert("날짜 형식 안 맞음");
					$(this).val("");

					return;
				}else{
					$(this).val(calendarFormat(str));
				};
			};
		});
	});
}
//overLayerPopup
function overLayer(){
	$(".OverLayerPopup").bind('mouseover mouseout ', function(){
			$(this).toggleClass("on");
	})
	$(".OverLayerPopup a.btnOverInfo").bind(' focus focusout', function(){
			$('.OverLayerPopup').toggleClass("on");
	})
}
//clickLayerPopup
function clickLayer(){
	$('.clicklayerPopup .layerBox').hide();
	$('.clicklayerPopup>a').click(function(){
		$('.layerWrap .on .layerBox').hide().parent().removeClass("on");
		$(this).parent().find('.layerBox').show().parent().addClass("on");
		return false;
	})
	$('.clicklayerPopup .layerBox .popClose').click(function(){
		$('.clicklayerPopup .layerBox').hide().parent().removeClass("on");
		return false;
	})
	$('.clicklayerPopup .layerBox .pClose').click(function(){
		$('.clicklayerPopup .layerBox').hide().parent().removeClass("on");
		return false;
	})
}
//slideDownList
function slideDownList(){
	$(".detailCode table tr").hover( //mouseOver
		function () {
			$(this).toggleClass("on")
		}
	);
	
	$(".slideDownList ul>li").each(function(){ //depth
		$(".slideDownList ul.none").parent().removeClass("subDepth");
		if($(this).find(">ul").length != 0){
			$(this).addClass("subDepth");
		};
	});

	$(".slideDownList ul li ul").hide();
	$(".slideDownList ul li.on ul").show();
	$(".slideDownList ul>li.subDepth>a").click(function () {
		if ($(this).parent("li").find("ul").length > 0) {
			if (!$(this).parent("li").hasClass("on")) {
				$(this).parent().parent().find("li.on ul").slideUp("500").end().find("li.on").removeClass("on");
				$(this).parent("li").addClass("on").find(">ul").slideDown("500");
			} else {
				$(this).parent().parent().find("li.on ul").parent().removeClass("on").children("ul").slideUp("500");
			}
			return false;
		}
	});
}
//차트설정영역
function setupBox(){
	$(".setupBox ul>li").each(function(){ //depth
		$(".setupBox ul.none").parent().removeClass("subDepth");
		if($(this).find(">ul").length != 0){
			$(this).addClass("subDepth");
		};
	});

	$(".setupBox ul li ul").hide();
	$(".setupBox ul li.on ul").show();
	$(".setupBox ul>li.subDepth>a").click(function () {
		if ($(this).parent("li").find("ul").length > 0) {
			if (!$(this).parent("li").hasClass("on")) {
				$(this).parent().parent().find("li.on ul").slideUp("500").end().find("li.on").removeClass("on");
				$(this).parent("li").addClass("on").find(">ul").slideDown("500");
			} else {
				//$(this).parent().parent().find("li.on ul").parent().removeClass("on").children("ul").slideUp("500");
			}
			return false;
		}
	});
}
//faqToggle
function faqToggle(){
	$(".faqList dd").hide();
	// Click Event
	$(".faqList dt>a").click(function () {
		if ($(this).parent().hasClass("on")){
				$(this).parent().removeClass("on").next("dd:first").slideUp();
			} else {
				$(this).parent().parent().find("dt").removeClass("on").next("dd").slideUp();
				$(this).parent().addClass("on").next("dd:first").slideDown();
			}
			return false;
		});

		//if ($(".faqList dt.on").length == 0){ //첫번재아이가 오픈되어있을경우 (html코드에서 dt class="on")
			//$(".faqList dt:first>a").trigger("click");
				//} else {
			//$(".faqList dt.on").removeClass("on").find("a").trigger("click");
		//}
}
//펀드매매 Toggle
function menuAreaToggle(){
	$(".menuArea dl dd").hide();
	// Click Event
	$(".menuArea dl dt>a").click(function () {
		if ($(this).parent().hasClass("on")){
				$(this).parent().removeClass("on").next("dd:first").slideUp('300');
			} else {
				$(this).parent().parent().find("dt").removeClass("on").next("dd").slideUp('300');
				$(this).parent().addClass("on").next("dd:first").slideDown('300', function() {				
					$(this).find('.fnTradeRight').outerHeight($(this).outerHeight());
				});
			}
			return false;
		});

	if ($(".menuArea dl dt.on").length == 0){ //첫번재아이가 오픈되어있을경우 (html코드에서 dt class="on")

			$(".menuArea dl dt:first>a").trigger("click");
			} else {
		$(".menuArea dl dt.on").removeClass("on").find("a").trigger("click");
		}
		
}


/* 종목명 팁메뉴
function tipMenu(){
	var tipArrow = '<p class="arrow"></p>';
	$('.tipArea').append(tipArrow);
	$('.tipOpen').each(function(i){
		var tipLength =  $('.tipOpen').length;
		$tipCon = $('.tipArea');
		$tipOpen = $('.tipOpen');
		$(this).click(function(){
			 if($tipCon.eq(i).is(':hidden')){
				$tipCon.hide();
				$tipCon.eq(i).show();
				$tipCon.eq(i).mouseover(function(){
					$(this).show();
				});
			 }
			  return false;
		});
		$tipCon.mouseout(function(){
			$(this).hide();
		})
		$('.tipArea li:last-child').focusout(function(){
			$tipCon.hide();
		})
	})
}
 */
/* 높이구하기 */
function findH(){
	$stepHeight = 0;
	$( '.hBox' ).parent('.findH').each(function(){
		var $this = $(this),
			$target = $this.find('.hBox'),
			$size = $target.size(),
			$stepMax = 0,
			$height;
		for (var i=0; i < $size ; i++){
			$height = $target.eq(i).height();
			if ($height > $stepMax)	{
				$stepMax = $height;
			}
		}
		$stepHeight = $stepHeight + $stepMax;
		$target.css('height',($stepMax) + 'px');
	});
//	$('.findH .hBox').css({height : $stepHeight});
}
function findHUl(){
	$stepHeight = 0;
	$( '.findHUl').each(function(){
		var $this = $(this),
			$target = $this.find('li'),
			$size = $target.size(),
			$stepMax = 0,
			$height;
		for (var i=0; i < $size ; i++){
			$height = $target.eq(i).height();
			if ($height > $stepMax)	{
				$stepMax = $height;
			}
		}
		$stepHeight = $stepHeight + $stepMax;
		$target.css('height',($stepMax) + 'px');
	});
//	$('.findHUl > li').css({height : $stepHeight});
}
function findHOl(){
	$stepHeight = 0;
	$( '.findHOl').each(function(){
		var $this = $(this),
			$target = $this.find('li div'),
			$size = $target.size(),
			$stepMax = 0,
			$height;
		for (var i=0; i < $size ; i++){
			$height = $target.eq(i).height();
			if ($height > $stepMax)	{
				$stepMax = $height;
			}
		}
		$stepHeight = $stepHeight + $stepMax;
		$target.css('height',($stepMax) + 'px');
	});
//	$('.findHUl > li').css({height : $stepHeight});
}
function checkPointBox(){
	$('.tableProdList th .checkPointBox').each(function(){
		$(this).height(parseInt($(this).parent().innerHeight()) -2 + "px");
/*
		if ($(this).parent('th').hasClass('sortUp')){
			$(this).height(parseInt($(this).parent().innerHeight()) -2 + "px"); //border 2px 제거용
		} else if ($(this).parent('th').hasClass('sortDn')){
			$(this).height(parseInt($(this).parent().innerHeight()) -2 + "px"); //border 2px 제거용
		}
*/		
		$('.tableProdList th .checkPointBox span').parent('p').each(function(){
			var innerH = $(this).find('span').height();
			$(this).css('height',innerH);
		})
		$('.tableProdList th .checkPointBox span').parent('a').each(function(){
			var innerH = $(this).find('span').height();
			$(this).css('height',innerH);
		})
	});
}  
function doFundDashboardNav() {
	var $nav = $('.fundDashboardNav'),
		navWidth = $nav.width(),
		activeIdx = $nav.find('.on').index();

	$nav.css({
		backgroundPposition : '-' + activeIdx * navWidth + 'px, 0'
	});
}
function doControlMap() {
	var $regionWrap = $('.fundDashboardRegion'),
		$regionElem = $regionWrap.find('.localItem'),
		$regionName = $regionWrap.find('.localName'),
		$nationWrap = $('.fundDashboardNation'),
		$viewGlobal = $('.viewGlobal'),
		$widgetButton = $('.fundDashboardWidget.topArea a'),
		$tabLink = $('.tabMap li a'),
		initPosX = 0,
		currentPosX = 0,
		currentPosY = 0,
		initMapBgPosX = '0px ',
		hoverMapBgPosX = '-355px ',
		activeMapBgPosX = '-722px ',
		initMapBgPosY = 0;

	function getMapBgPosY($this) {
		if (navigator.userAgent.toLowerCase().indexOf('msie 8.0') !== -1) {
			initMapBgPosY = $this.css('backgroundPositionY');

			return initMapBgPosY;
		} else {
			if (typeof($this.css('backgroundPosition')) !== 'undefined') {
				initMapBgPosY = $this.css('backgroundPosition').split(' ')[1];
							
				return initMapBgPosY;
			} else {
				return false;
			}
		}			
	}

	function setMapBgPos($this, bgPosX) { //지도 이미지 제어	
		$this.css({			
			'backgroundPosition' : bgPosX + getMapBgPosY($this)
		});		
	}

	function getInitPos($this) {
		initPosX = $this.outerWidth() / 2;
	}

	function setPos($this) {
		currentPosX = -($this.outerWidth() / 2) + initPosX - 1;
		currentPosY = -($this.outerHeight() / 2 + 5);

		$this.css({
			marginTop : currentPosY,
			marginLeft : currentPosX
		});		 		
	}

	function doControlTab($this) {
		var mapTrigger = $this.text(),
			mapTriggerLength = mapTrigger.length;

		$('.tabMap a').each(function() {			
			if ($(this).text().split('(')[0].indexOf(mapTrigger) !== -1 && $(this).text().split('(')[0].length === mapTriggerLength) {				
				$(this).trigger('click');				
			}
		});			
	}

	$tabLink.on({
		click : function() {
			var tabTrigger = $(this).text().split('(')[0],
				tabTriggerLength = tabTrigger.length;

			$regionName.each(function() {
				if ($(this).text().indexOf(tabTrigger) !== -1 && $(this).text().length === tabTriggerLength) {								
					getInitPos($(this));
					
					$regionElem.filter('.active').each(function() {
						setMapBgPos($(this), initMapBgPosX);
					}).removeClass('active').find('.localInfo').css({
						marginTop : 0,
						marginLeft : 0
					});

					$(this).parents('.localItem').addClass('active');
					setMapBgPos($(this).parents('.localItem'), activeMapBgPosX);
					setPos($(this).parent('.localInfo'));				
					$regionWrap.removeClass('active');
				}
			});

			/*if (tabTrigger === '글로벌') {
				$regionWrap.addClass('active');
			
				$regionElem.each(function() {
					setMapBgPos($(this), initMapBgPosX);
				}).removeClass('active').find('.localInfo').css({
					marginTop : 0,
					marginLeft : 0
				});
			}*/
		}
	});

	$regionName.on({
		mouseenter : function() {			
			$regionWrap.removeClass('active');			
			setMapBgPos($(this).parents('.localItem').not('.active'), hoverMapBgPosX);
		},
		mouseleave : function() {
			setMapBgPos($(this).parents('.localItem').not('.active'), initMapBgPosX);
		}
		/*click : function() {			
			doControlTab($(this));

			return false;
		}*/
	});

	/*$viewGlobal.on({
		click : function() {
			$regionWrap.addClass('active');
			
			$regionElem.each(function() {
				setMapBgPos($(this), initMapBgPosX);
			}).removeClass('active').find('.localInfo').css({
				marginTop : 0,
				marginLeft : 0
			});			

			$('.tabMap a:eq(5)').trigger('click');

			return false;
		}
	});*/

	$widgetButton.on({
		click : function() {
			$(this).addClass('on').siblings().removeClass('on');
			
			/*if ($(this).index() === 0) {
				$regionWrap.show();
				$nationWrap.hide();
			} else if ($(this).index() === 1) {
				$regionWrap.hide();
				$nationWrap.show();
			} else {
				return false;
			}*/

			return false;
		}
	});
}
function alternativeInvest() {
	$('.alternativeInvest a').on({
		click : function() {
			var tabMenu = $(this).text();

			$('.tabMap a').each(function() {							
				if ($(this).text().indexOf(tabMenu) !== -1) {
					$(this).trigger('click');
				}
			});

			return false;
		}
	});
}
function doCustomRadio() {
	var $radioTrigger = $('.radioStyle'),
		radioName = null,
		radioToggle = 'on';

	function init(thisName) {
		
		$radioTrigger.each(function() {
			if ($(this).find('input').attr('name') === thisName) {
				$(this).removeClass(radioToggle);
				
				if($(this).index() == 0){
					
				}else{

				}
			}
		});
	}
	
	$radioTrigger.on({
		click : function() {
			//init($(this).find('input').attr('name'));
			$(this).parent().each(function(){
				$(this).find(".radioStyle").removeClass(radioToggle)
			});

			$(this).addClass(radioToggle);
			
			if($(this).parent().parent().index() == 1){
				if($(this).index() == 0){
					$(this).parent().parent().find("> div").each(function(i){
						if(i < 2){
							$(this).show();
						}else{
							$(this).hide();
						};
					});
				}else{
					$(this).parent().parent().find("> div").each(function(i){
						if(i != 1){
							$(this).show();
						}else{
							$(this).hide();
						};
					});
				};
			}else if($(this).parent().parent().index() == 2){
				if($(this).index() == 0){
					$(this).parent().parent().find("> div").each(function(i){
						if(i < 3){
							$(this).show();
						}else{
							$(this).hide();
						};
					});
				}else{
					$(this).parent().parent().find("> div").each(function(i){
						if(i != 2){
							$(this).show();
						}else{
							$(this).hide();
						};
					});
				};
			};
		}
	});
}
function doCustomSelect() {
	var $dropdown = $('.dropdown'),
		$trigger = $dropdown.find('.toggle'),
		$dropdownGroup = $dropdown.find('ul'),
		$dropdownInput = $dropdown.find('input');

	$trigger.on({
		click : function() {
			if ($dropdownGroup.is(':visible')) {
				$dropdownGroup.hide();
			} else {
				$dropdownGroup.show();
				$dropdown.find('label.on').prev().focus();
			}
			return false;
		}
	});

	$dropdownInput.on({
		mouseup : function() {
			$trigger.text($(this).next().text());						
			$(this).next().addClass('on').parent().siblings().find('label').removeClass('on');
			$dropdownGroup.hide();
		},
		keyup : function() {
			$trigger.text($(this).next().text());						
			$(this).next().addClass('on').parent().siblings().find('label').removeClass('on');			
		},
		keydown : function(event) {
			if (event.keyCode === 13 || event.keyCode === 9) {
				$dropdownGroup.hide();
			}

			if (event.keyCode === 13) {
				$('.inputKeyword').focus();
			}
		}
	});

	$(document).on({
		click : function(event) {
			if (event.target.parentElement.className !== 'keywordList' && event.target.className !== 'toggle') {
				$dropdownGroup.hide();
			}
		}
	});

	$('.searchBox').on({
		mouseleave : function() {
			$dropdownGroup.hide();
		}
	});
}
function logBox(){
	var bT;
	$(".logBox input").each(function(){
		$(this).focusin(function(){		
			if($(this).attr("type") == "text" || $(this).attr("type") == "password"){
				if($(this).prev().text() != ""){
					bT = $(this).prev().text();
				};
				$(this).prev().text("");
			};
		}).focusout(function(){
			if($(this).attr("type") == "text" || $(this).attr("type") == "password"){
				if($(this).val() == ""){
					$(this).prev().text(bT);
				};
			};
		});
		
	});
}

function slider(initText, changeText, callback, chapter) {
	var $slideWrap = $('.analyzePortfolio'),
		$slideTarget = $slideWrap.find('.questionWrapOuter'),
		$slideTrigger = $slideWrap.find('.btnStyle'),
		$nextButton = $slideTrigger.find('.next'),
		$stepbar = $('.analyzeStep li'),	
		distance = $slideWrap.outerWidth(),
		minimumCount = 0,
		maximumCount = $slideWrap.find('.questionWrap').last().index(),
		currentCount = minimumCount;
		
		(function init() {
			$slideTarget.outerWidth((maximumCount + 1) * distance);
		})();
		
		$slideTrigger.on({
			click : function(event) {
				if ($(this).hasClass('btnPrevSlide')) {
					if(currentCount == 0){
						history.back();
						event.preventDefault();
					};
					doCounting('+');
				} else if ($(this).hasClass('btnNextSlide')) {
					if("FUNDFOLIO" == chapter) {
						if(doChkValid(currentCount)) {
							doCounting('-');
						} else {
							return false;
						}
					} else {
						doCounting('-');
					}
				} else {
					return false;
				}

				return false;
			},
			mouseup : function() {
				if ($(this).children().hasClass('viewResult') && currentCount === maximumCount) {
					if(typeof callback != "undefined" && typeof callback != null){
						callback();
					}
				}
			}		
		});
		
		if(chapter == "retire"){
			$(".questionWrap .searchBlockOuter").each(function(i){
				if($(this).hasClass("selWrap") || $(this).hasClass("selWrap2") || $(this).parent().find("> div").length == 1){
					$(this).find(".searchBlock:last-child input").keydown(function(e){
						if(e.which == 9 && e.shiftKey){

						}else if(e.which == 9){
							$(".btnArea .btnPrevSlide").focus();

							e.stopPropagation();
							e.preventDefault();
						};
					});
				};

				$(this).find(".searchBlock:first-child .pullLeft .searchL > a").keydown(function(e){
					if(e.which == 9 && e.shiftKey){
						if(currentCount == 1 || currentCount == 2 && $(this).parents(".searchBlockOuter").index() != 1){
							return;
						};

						$(".tabNav li:eq(1) > a").focus();

						e.stopPropagation();
						e.preventDefault();
					}
				});
			});

			$(".questionWrapOuter > div:eq(1) .radioWrap > label input").keydown(function(e){
				if(e.which == 9 && e.shiftKey){
					if($(this).parent().hasClass("on")){
						return;
					};

					$(".tabNav li:eq(1) > a").focus();

					e.stopPropagation();
					e.preventDefault();
				};
			});

			$(".tabNav li:eq(1) > a").keydown(function(e){
				if(e.which == 9 && e.shiftKey){

				}else if(e.which == 9){
					if(currentCount == 1){
						$(".questionWrapOuter > div:eq(" + currentCount + ") .radioWrap > label input").focus();
					}else{
						$(".questionWrapOuter > div:eq(" + currentCount + ") > div:eq(0) .searchBlock:first-child .pullLeft .searchL > a").focus();
					};

					e.stopPropagation();
					e.preventDefault();
				};
			});

			$(".btnArea .btnPrevSlide").keydown(function(e){
				if(e.which == 9 && e.shiftKey){
					$(".questionWrapOuter > div:eq(" + currentCount + ") .searchBlockOuter .searchBlock:last-child input").focus();

					e.stopPropagation();
					e.preventDefault();
				}
			});
		}else if(chapter == "portfolio"){
			$(".questionWrap .choiceList li input").keydown(function(e){
				
				if($(this).parents(".questionWrap").index() == 0){
					if($(this).parents("li").index() == 2){
						if(e.which == 9 && e.shiftKey){
							$(".tabNav li:eq(2) > a").focus();

							e.stopPropagation();
							e.preventDefault();
						}else if(e.which == 9){
							$(".btnArea .btnPrevSlide").focus();

							e.stopPropagation();
							e.preventDefault();
						};
					};
				}else{
					if(e.which == 9 && e.shiftKey){
						$(".tabNav li:eq(2) > a").focus();

						e.stopPropagation();
						e.preventDefault();
					}else if(e.which == 9){
						$(".btnArea .btnPrevSlide").focus();

						e.stopPropagation();
						e.preventDefault();
					};
				};
			});

			$(".tabNav li:eq(2) > a").keydown(function(e){
				if(e.which == 9 && e.shiftKey){

				}else if(e.which == 9){
					if(currentCount == 0){
						$(".questionWrapOuter > div:eq(" + currentCount + ") .choiceList li label.on input").focus();
					}else{
						$(".questionWrapOuter > div:eq(" + currentCount + ") .choiceList li label.on input").focus();
					};

					e.stopPropagation();
					e.preventDefault();
				};
			});

			$(".btnArea .btnPrevSlide").keydown(function(e){
				if(e.which == 9 && e.shiftKey){
					$(".questionWrapOuter > div:eq(" + currentCount + ") .choiceList li label.on input").focus();

					e.stopPropagation();
					e.preventDefault();
				}
			});
		};

		function doCounting(direction) {					
			if (direction === '+' && currentCount > minimumCount) {
				currentCount -= 1;		
				doSlideMotion(direction);		
			} else if (direction === '-' && currentCount < maximumCount) {
				currentCount += 1;		
				doSlideMotion(direction);		
			}			
			
			doControlStepbar();
			changeButtonText();
		}

		function doSlideMotion(direction) {			
			$slideTarget.animate({
				left : direction + '=' + distance
			});
		}		

		function changeButtonText() {
			if (currentCount === maximumCount) {
				$nextButton.text(changeText).addClass('viewResult');		
			} else {
				$nextButton.text(initText).removeClass('viewResult');
			}			
		}

		function doControlStepbar() {
			$stepbar.eq(currentCount).addClass('on').siblings().removeClass('on');
		}
}

//smartDrag
//var valueArr = new Array([-10, 0, 10, 20, 30, 40], [0.5, 1, 1.5, 2, 2.5, 3], [100, 500, 1000, 3000, 5000, 10000]);
var valueArr = new Array([-10, 40, 10], [0.5, 3, 0.5], [0, 5, 1]);
var fundArr = new Array(100, 500, 1000, 3000, 5000, 10000);
var smartTotalW = 535;
var smartW = 107;
var sliderArr = new Array();

function smartDrag(setArr){
	$(".searchAreaR .searchBlock").each(function(i){
		
		var slider = $(this).find(".condiSearch").find("div").slider({
			range: true, min: valueArr[i][0], max: valueArr[i][1], values: [ setArr[i][0], setArr[i][1] ], step:valueArr[i][2], slide: function( event, ui ) {
				if(i == 2){
					$(this).parents(".searchBlock").find(".condiResult").find("input:eq(1)").val( fundArr[ui.values[ 0 ]]);
					$(this).parents(".searchBlock").find(".condiResult").find("input:eq(2)").val( + fundArr[ui.values[ 1 ]]);
				}else{
					$(this).parents(".searchBlock").find(".condiResult").find("input:eq(1)").val( ui.values[ 0 ]);
					$(this).parents(".searchBlock").find(".condiResult").find("input:eq(2)").val( + ui.values[ 1 ]);
				};

				$(this).parents(".searchBlock").find(".condiResult").find(".inputArea").find("input").attr("checked", false);
				
				//-------------------------------------------------------------------------------------------------------------------------------------------------------
				//dSChartContr.setSlide 함수 선택한 유형 전달 개발 전달시 이 함수 주석 제거 - 총 4군데 주석 처리 되어있음
				//-------------------------------------------------------------------------------------------------------------------------------------------------------
				dSChartContr.setSlide(i);
			}
		});
		sliderArr.push(slider);
		var allChk=false;
		if(i==0){ allChk=$("#allmonth").prop("checked");}
		if(i==1){ allChk=$("#allmonth1").prop("checked");}
		if(i==2){ allChk=$("#allmonth2").prop("checked");}
		if(!allChk){
			if(i == 2){
				$(this).find(".condiResult").find("input:eq(1)").val(fundArr[slider.slider( "values", 0 )]);
				$(this).find(".condiResult").find("input:eq(2)").val(fundArr[slider.slider( "values", 1 )]);
			}else{
				$(this).find(".condiResult").find("input:eq(1)").val(slider.slider( "values", 0 ));
				$(this).find(".condiResult").find("input:eq(2)").val(slider.slider( "values", 1 ));
			};
		}
		

		$(this).find(".condiResult").find(".inputArea").find("input").change(function(){
			if($(this).is(":checked")){
				slider.slider( "values", [valueArr[i][0], valueArr[i][1]] );
//				if(i == 2){
//					$(this).parents(".condiResult").find("input:eq(1)").val(fundArr[slider.slider( "values", 0 )]);
//					$(this).parents(".condiResult").find("input:eq(2)").val(fundArr[slider.slider( "values", 1 )]);
//				}else{
//					$(this).parents(".condiResult").find("input:eq(1)").val(slider.slider( "values", 0 ));
//					$(this).parents(".condiResult").find("input:eq(2)").val(slider.slider( "values", 1 ));
//				};
				
				
				dSChartContr.setSlide(i);
			}
		});
		
		var l_sTitle = $(".conditionBox:eq("+i+")>strong").text();
		$(".condiSearch:eq("+i+")>div a:eq(0)").append("<span class='ctrlBtn'>"+l_sTitle +" 시작 조건 드래그</span>")
		$(".condiSearch:eq("+i+")>div a:eq(1)").append("<span class='ctrlBtn'>"+l_sTitle +" 마지막 조건 드래그</span>")
	});
		
};

//스마트 검색 초기화
function smartSet(setArr){
	$(".searchAreaR .searchBlock").each(function(i){
			/*var firstValue = valueArr[i][0];
			var lastValue = valueArr[i][5];
			
			$(this).find(".conditionBox .condiResult input:eq(1)").val(firstValue);
			$(this).find(".conditionBox .condiResult input:eq(2)").val(lastValue);
			
			$(this).find(".conditionBox .condiResult input:eq(1)").val("");
			$(this).find(".conditionBox .condiResult input:eq(2)").val("");

			$(this).find(".searchBar .searchL").css({"width" : 0});
			$(this).find(".searchBar .searchL > a").css({"left" : 0});

			$(this).find(".searchBar .searchR").css({"width" : 0});
			$(this).find(".searchBar .searchRHandle").css({"left" : smartTotalW + "px"});*/
			sliderArr[i].slider( "values", [valueArr[i][0], valueArr[i][1]] );

			if(i == 2){
				$(this).parents(".condiResult").find("input:eq(1)").val(fundArr[sliderArr[i].slider( "values", 0 )]);
				$(this).parents(".condiResult").find("input:eq(2)").val(fundArr[sliderArr[i].slider( "values", 1 )]);
			}else{
				$(this).parents(".condiResult").find("input:eq(1)").val(sliderArr[i].slider( "values", 0 ));
				$(this).parents(".condiResult").find("input:eq(2)").val(sliderArr[i].slider( "values", 1 ));
			};
		});

		//smartValue(0, 30, 1, 3, 100, 3000);
};

//스마트 검색 검색 후 value 유지
function smartValue(num1, num2, num3, num4, num5, num6){
	num1 = smartCode(0, num1);
	num2 = smartCode(0, num2);
	num3 = smartCode(1, num3);
	num4 = smartCode(1, num4);
	num5 = smartCode(2, num5);
	num6 = smartCode(2, num6);

	$(".searchAreaR .searchBlock").each(function(i){
		if(i == 0){
			$(this).find(".searchBar .searchL").css({"width" : (smartW * num1) + "px"});
			$(this).find(".searchBar .searchL > a").css({"left" : (smartW * num1) + "px"});

			$(this).find(".searchBar .searchR").css({"width" : (smartTotalW -smartW * num2) + "px"});
			$(this).find(".searchBar .searchRHandle").css({"left" : (smartW * num2) + "px"});

			if(num2 == 5){
				$(this).find(".searchBar .searchRHandle").css({"margin-left" : "-9px"});
			}else{
				$(this).find(".searchBar .searchRHandle").css({"margin-left" : "0"});
			};
		}else if(i == 1){
			$(this).find(".searchBar .searchL").css({"width" : (smartW * num3) + "px"});
			$(this).find(".searchBar .searchL > a").css({"left" : (smartW * num3) + "px"});

			$(this).find(".searchBar .searchR").css({"width" : (smartTotalW -smartW * num4) + "px"});
			$(this).find(".searchBar .searchRHandle").css({"left" : (smartW * num4) + "px"});

			if(num4 == 5){
				$(this).find(".searchBar .searchRHandle").css({"margin-left" : "-9px"});
			}else{
				$(this).find(".searchBar .searchRHandle").css({"margin-left" : "0"});
			};
		}else{
			$(this).find(".searchBar .searchL").css({"width" : (smartW * num5) + "px"});
			$(this).find(".searchBar .searchL > a").css({"left" : (smartW * num5) + "px"});

			$(this).find(".searchBar .searchR").css({"width" : (smartTotalW -smartW * num6) + "px"});
			$(this).find(".searchBar .searchRHandle").css({"left" : (smartW * num6) + "px"});

			if(num6 == 5){
				$(this).find(".searchBar .searchRHandle").css({"margin-left" : "-9px"});
			}else{
				$(this).find(".searchBar .searchRHandle").css({"margin-left" : "0"});
			};
		};
		
	});
};

function smartCode(chk1, chk2){
	var codeNum;

	for(i = 0; i < 6; i++){
		if(chk2 == valueArr[chk1][i]){
			codeNum = i;
		};
	};

	return codeNum;
};

//fund worldcup
var fundWorldcupCurrent = 0;
var disappearX = -390;
var selectDisX = 850;
var appearX = 0;
var mX = 230;
var selectCard;
var selectDir;
var cardHtml;
var cardMotion = false;

function fundWorldcup(){
	fundFirstSet();
	
	
	$(".fundWorldcupBox > div:eq(0) > a").click(function(){
		//fundWorldcupCurrent = 1;
		fundPage(fundWorldcupCurrent);

		return false;
	});

	$(".fundWorldcupBox > .inner > .leftCard").click(function(){
		if(cardMotion == true){
			return false;
		};

		selectCard = $(this);
		selectDir = "left";
		cardHtml = $(this).find(".cardTop").html();
		$(this).find(".cardBottom").find("a").text("선택완료");
		fundAppendHtml($(this).parent().index(), cardHtml);

		$(this).addClass("on");
		fundWorldcupCurrent++;
		fundPage(fundWorldcupCurrent);

		return false;
	}).hover(function(){
		$(this).addClass("on");
	},function(){
		if(cardMotion == true){
			return;
		};
		$(this).removeClass("on");
	});

	$(".fundWorldcupBox > .inner > .rightCard").click(function(){
		if(cardMotion == true){
			return false;
		};

		selectCard = $(this);
		selectDir = "right";
		cardHtml = $(this).find(".cardTop").html();
		$(this).find(".cardBottom").find("a").text("선택완료");
		fundAppendHtml($(this).parent().index(), cardHtml);

		$(this).addClass("on");
		fundWorldcupCurrent++;
		fundPage(fundWorldcupCurrent);

		return false;
	}).hover(function(){
		$(this).addClass("on");
	},function(){
		if(cardMotion == true){
			return;
		};
		$(this).removeClass("on");
	});

	//결과보기
	$(".widget > a:eq(0)").click(function(){
		//결과보기 페이지 이동

		return false;
	});

	//재경기
	$(".widget > a:eq(1)").click(function(){
		fundFirstSet();

		return false;
	});

};

function fundPage(chk){
	cardMotion = true;
	if(chk == 0){
		/*$(".fundWorldcupBox > div:eq(" + chk + ") p").css("position", "relative");
		$(".fundWorldcupBox > div:eq(" + chk + ") h3").stop().animate({"top" : "-200px"}, 400, "easeInCirc");
		$(".fundWorldcupBox > div:eq(" + chk + ") p").stop().delay(100).animate({"top" : "-300px"}, 400, "easeInCirc", function(){
			chk++;
			fundPageView(chk);
		});
		$(".fundWorldcupBox > div:eq(0) > a").fadeOut(500);*/

		$(".fundWorldcupBox > div:eq(" + chk + ") h3").fadeOut(500);
		$(".fundWorldcupBox > div:eq(" + chk + ") p").fadeOut(500);
			
		$(".fundWorldcupBox > div:eq(0) > a").fadeOut(500, function(){
			chk++;
			fundPageView(chk);
		});
	}else{
		//left right -390 disappear middle  230px
		//$(".fundWorldcupBox > div:eq(" + chk + ") .matchRound").fadeIn(500);
		
		if(selectDir == "left"){
			$(".fundWorldcupBox > div:eq(" + chk + ") .rightCard").stop().animate({"right" : disappearX + "px"}, 400, "easeInCirc");
			$(".fundWorldcupBox > div:eq(" + chk + ") .leftCard").stop().delay(400).animate({"left" : mX + "px"}, 400, "easeOutCirc", function(){
				if(chk < 7){
					$(this).delay(1000).animate({"left" : selectDisX + "px"}, 400, "easeInCirc", function(){
						chk++;
						fundPageView(chk);
					});
				}else{
					//$(".fundWorldcupBox > div:eq(" + chk + ") .rightCard").css("display", "none");
					$(".fundWorldcupBox .widget").fadeIn(500);
				};
			});

		}else{
			$(".fundWorldcupBox > div:eq(" + chk + ") .leftCard").stop().animate({"left" : disappearX + "px"}, 400, "easeInCirc");
			$(".fundWorldcupBox > div:eq(" + chk + ") .rightCard").stop().delay(400).animate({"right" : mX + "px"}, 400, "easeOutCirc", function(){
				
				if(chk < 7){
					$(this).delay(1000).animate({"right" : selectDisX + "px"}, 400, "easeInCirc", function(){
						chk++;
						fundPageView(chk);
					});
				}else{
					//$(".fundWorldcupBox > div:eq(" + chk + ") .leftCard").css("display", "none");
					$(".fundWorldcupBox .widget").fadeIn(500);
				};
			});
		};
		
		/*$(".fundWorldcupBox > div:eq(" + chk + ") .leftCard").stop().animate({"left" : disappearX + "px"}, 400, "easeInCirc");
		$(".fundWorldcupBox > div:eq(" + chk + ") .rightCard").stop().animate({"right" : disappearX + "px"}, 400, "easeInCirc", function(){
			$(".fundWorldcupBox > div:eq(" + chk + ") .matchRound").fadeOut(500);

			chk++;
			
			if(selectDir == "left"){
				selectCard.css({"top" : "-330px", "left" : "50%", "margin-left" : "-130px"});
			}else{
				selectCard.css({"top" : "-330px", "right" : "50%", "margin-right" : "-130px"});
			};
			
			selectCard.delay(1000).animate({"top" : "60px"}, 400, "easeOutBack", function(){
				selectCard.delay(1000).animate({"top" : "-330px"}, 400, "easeInBack", function(){
					fundPageView(chk);	
				});
				
			})
			
		});*/
	};
	
};

function fundPageView(chk){
	$(".fundWorldcupBox > div").each(function(i){
		if(chk == i){
			$(this).css("display", "block");
			
			
			//$(".fundWorldcupBox > div:eq(" + chk + ") .matchRound").fadeIn(500);
			$(".fundWorldcupBox > div:eq(" + chk + ") .leftCard").stop().delay(200).animate({"left" : appearX + "px"}, 400, "easeOutCirc");
			$(".fundWorldcupBox > div:eq(" + chk + ") .rightCard").stop().delay(200).animate({"right" : appearX + "px"}, 400, "easeOutCirc", function(){
				cardMotion = false;	
			});
		}else{
			$(this).css("display", "none");
		};
	});
};

function fundFirstSet(){
	$(".widget").css("display", "none");
	$(".fundWorldcupBox > div").each(function(i){
		$(this).css("display", "block");
		if(i != 0){
			//$(this).find(".matchRound").css("display", "none");
			$(this).find("div").removeClass("on");
			$(this).find(".leftCard").css("left", disappearX + "px");
			$(this).find(".leftCard").find(".cardBottom").find("a").text("선택하기");
			$(this).find(".rightCard").css("right", disappearX + "px");
			$(this).find(".rightCard").find(".cardBottom").find("a").text("선택하기");
		}else{
			fundWorldcupCurrent = 0;
			$(this).find("h3").fadeIn(500);
			$(this).find("p").fadeIn(500);
			$(this).find("a").fadeIn(500);
		};
	});
};

function fundAppendHtml(num, html){
	if(num == 1){
		$(".fundWorldcupBox > div:eq(5) .leftCard .cardTop").html(html);
	}else if(num == 2){
		$(".fundWorldcupBox > div:eq(5) .rightCard .cardTop").html(html);
	}else if(num == 3){
		$(".fundWorldcupBox > div:eq(6) .leftCard .cardTop").html(html);
	}else if(num == 4){
		$(".fundWorldcupBox > div:eq(6) .rightCard .cardTop").html(html);
	}else if(num == 5){
		$(".fundWorldcupBox > div:eq(7) .leftCard .cardTop").html(html);
	}else if(num == 6){
		$(".fundWorldcupBox > div:eq(7) .rightCard .cardTop").html(html);
	};	
};

// 증권업무 안내
function stockGuide() {
	function goPageTop() {
		$('.goTop').click(function() {
			$('.stockGuideContent').scrollTop(0);

			return false;
		});
	}
	goPageTop();

	function nav() {
		var $commonMenu = $('.nav a'),
			$dropdown = $('.dropdown > li');

		$commonMenu.each(function() { //브라우저 주소창 url과 $commonMenu의 링크주소를 비교
			if (document.location.href.indexOf($(this).attr('href')) !== -1) {
				$(this).parent().addClass('active');
			}
		});

		$dropdown.each(function() { //2뎁스 활성화
			if ($(this).hasClass('active')) {
				$(this).parent().andSelf().parent().addClass('active');
			} else {

			}
		});
	}
	nav();
}
// 증권업무 안내

//슬라이드배너
function doSlider(object, delay, autoplay) {
	var $elemWrap = $(object),
		$elem = $elemWrap.find('.js-slide-container > *'),
		$sideMotionTrigger = $elemWrap.find('.js-slide-button'),
		$counterTrigger = $elemWrap.find('.js-slide-counter > *'),
		$slideStopTrigger = $elemWrap.find('.js-slide-stop'),
		timer = 0,
        speed = 500,                                        //슬라이드 이동 속도
        interval = delay,                                   //슬라이드 시간 간격
        direction = '-',                                    //슬라이드 이동 방향
        distance = null,         							//슬라이드 이동 거리
        endLeftPos = null,    								//좌측 한계선
        endRightPos = null,      							//우측 한계선
        initLeftPos = null,                            		//endLeftPos 도착 시 $elem의 재설정 위치
        initRightPos = null,                           		//endRightPos 도착 시 $elem의 재설정 위치
        currentCounter = 0,                                 //카운터 현재 위치
        directionCounter = 1,                               //카운터 이동 방향
        isAnimating = false;                                //현재 슬라이드 동작 유무 설정($sideMotionTrigger의 연속 클릭에 대한 오작동 방지)
	
	function initialize() {
		distance = $elemWrap.innerWidth(),
        endLeftPos = -(distance * $elem.last().index()),
        endRightPos = distance * $elem.last().index(),
        initLeftPos = distance,
        initRightPos = -distance;

		$elem.each(function() {
			$(this).css('left', $(this).index() * distance);
			$elem.find('a').attr('tabindex', -1);
			$elem.eq(0).find('a').attr('tabindex', 0);
		});
		
		startMotion();
	}

	function doMotion(count) {
        isAnimating = true;

        if (count !== undefined) { //$counterTrigger 클릭했을 경우
            currentCounter = count;

            $elem.each(function() {
                $(this).animate({
                    left : ($(this).index() - count) * distance
                }, speed, function() {
                	isAnimating = false;

                	if ($(this).position().left === 0) {
	            		$elem.find('a').attr('tabindex', -1);
	            		$(this).find('a').attr('tabindex', 0);
	            	}
                });
            });

        } else {
            $elem.each(function() {
                if ($(this).position().left >= endRightPos) {$(this).css('left', initRightPos);}
                if ($(this).position().left <= endLeftPos) {$(this).css('left', initLeftPos);}
            });

            $elem.animate({
                left : direction + '=' + distance
            }, speed, function() {
            	isAnimating = false;

            	if ($(this).position().left === 0) {
            		$elem.find('a').attr('tabindex', -1);
            		$(this).find('a').attr('tabindex', 0);
            	}
            });

            //카운터 동작
            currentCounter = currentCounter + directionCounter;
            if (currentCounter > $counterTrigger.last().index()) {currentCounter = 0;}
            if (currentCounter < 0) {currentCounter = $counterTrigger.last().index();}
        }

        $counterTrigger.eq(currentCounter).addClass('active').siblings().removeClass('active');
    }

    //화면 회전시 재설정
    $(window).on('orientationchange resize', function(event) {
    	initialize();
    });

    //슬라이드 시작 함수
    function startMotion() {
    	if (autoplay === 'true') {
        	if (timer === 0) {timer = setInterval(doMotion, interval);}
        }
    }

    //슬라이드 정지 함수
    function stopMotion() {
        if (timer !== 0) {
            clearInterval(timer);
            timer = 0;
        }
    }

    //사이드이동 버튼 클릭 시 동작 함수
    $sideMotionTrigger.on({
        click : function() {
            if ($(this).hasClass('js-slide-prev')) {
                direction = '+';
                directionCounter = -1;
            } else {
                direction = '-';
                directionCounter = 1;
            }

            if (!isAnimating) {
                doMotion();
                stopMotion();
            }

            return false;
        }
    });

    //카운터 클릭 시 동작 함수
    $counterTrigger.on({
        click : function() {
            var count = $(this).index();

            if (!isAnimating) {
                doMotion(count);
                stopMotion();
            }

            return false;
        }
    });

    //슬라이드 정지 버튼
    $slideStopTrigger.on({
    	click : function() {
    		if ($(this).hasClass('active')) {
    			startMotion();
    			$(this).removeClass('active').text('정지');    			    		
    		} else {
    			stopMotion();
    			$(this).addClass('active').text('재생');
    		}

    		return false;
    	}
    });

    //포커스
    $elem.find('a').on({
    	focus : function() {
    		stopMotion();
    	},
    	blur : function() {
    		startMotion();
    	},
    	mouseenter : function() {
    		stopMotion();
    	},
    	mouseleave : function() {
    		startMotion();
    	}
    });

    $(window).onOrientationChange = function() {
    	switch(window.orientation) {
    		case 0 :
    			init();
    			break;
    		case 90 : 
    			init();
    			break; 
    	}
    };

    initialize();
}

function doVerticalSlider(object, delay, autoplay) {
	var $elemWrap = $(object),
		$elem = $elemWrap.find('.js-slide-container > *'),
		$sideMotionTrigger = $elemWrap.find('.js-slide-button'),
		$counterTrigger = $elemWrap.find('.js-slide-counter > *'),
		$slideStopTrigger = $elemWrap.find('.js-slide-stop'),
		timer = 0,
        speed = 500,                                        //슬라이드 이동 속도
        interval = delay,                                   //슬라이드 시간 간격
        direction = '-',                                    //슬라이드 이동 방향
        distance = null,         							//슬라이드 이동 거리
        endLeftPos = null,    								//좌측 한계선
        endRightPos = null,      							//우측 한계선
        initLeftPos = null,                            		//endLeftPos 도착 시 $elem의 재설정 위치
        initRightPos = null,                           		//endRightPos 도착 시 $elem의 재설정 위치
        currentCounter = 0,                                 //카운터 현재 위치
        directionCounter = 1,                               //카운터 이동 방향
        isAnimating = false;                                //현재 슬라이드 동작 유무 설정($sideMotionTrigger의 연속 클릭에 대한 오작동 방지)
	
	function initialize() {
		distance = $elemWrap.innerHeight(),
        endLeftPos = -(distance * $elem.last().index()),
        endRightPos = distance * $elem.last().index(),
        initLeftPos = distance,
        initRightPos = -distance;

		$elem.each(function() {
			$(this).css('top', $(this).index() * distance);
			$elem.find('a').attr('tabindex', -1);
			$elem.eq(0).find('a').attr('tabindex', 0);
		});
		
		startMotion();
	}

	function doMotion(count) {
        isAnimating = true;

        if (count !== undefined) { //$counterTrigger 클릭했을 경우
            currentCounter = count;

            $elem.each(function() {
                $(this).animate({
                    top : ($(this).index() - count) * distance
                }, speed, function() {
                	isAnimating = false;

                	if ($(this).position().top === 0) {
	            		$elem.find('a').attr('tabindex', -1);
	            		$(this).find('a').attr('tabindex', 0);
	            	}
                });
            });

        } else {
            $elem.each(function() {
                if ($(this).position().top >= endRightPos) {$(this).css('top', initRightPos);}
                if ($(this).position().top <= endLeftPos) {$(this).css('top', initLeftPos);}
            });

            $elem.animate({
                top : direction + '=' + distance
            }, speed, function() {
            	isAnimating = false;

            	if ($(this).position().top === 0) {
            		$elem.find('a').attr('tabindex', -1);
            		$(this).find('a').attr('tabindex', 0);
            	}
            });

            //카운터 동작
            currentCounter = currentCounter + directionCounter;
            if (currentCounter > $counterTrigger.last().index()) {currentCounter = 0;}
            if (currentCounter < 0) {currentCounter = $counterTrigger.last().index();}
        }

        $counterTrigger.eq(currentCounter).addClass('active').siblings().removeClass('active');
    }

    //화면 회전시 재설정
    $(window).on('orientationchange resize', function(event) {
    	initialize();
    });

    //슬라이드 시작 함수
    function startMotion() {
    	if (autoplay === 'true') {
        	if (timer === 0) {timer = setInterval(doMotion, interval);}
        }
    }

    //슬라이드 정지 함수
    function stopMotion() {
        if (timer !== 0) {
            clearInterval(timer);
            timer = 0;
        }
    }

    //사이드이동 버튼 클릭 시 동작 함수
    $sideMotionTrigger.on({
        click : function() {
            if ($(this).hasClass('js-slide-prev')) {
                direction = '+';
                directionCounter = -1;
            } else {
                direction = '-';
                directionCounter = 1;
            }

            if (!isAnimating) {
                doMotion();
                stopMotion();
            }

            return false;
        }
    });

    //카운터 클릭 시 동작 함수
    $counterTrigger.on({
        click : function() {
            var count = $(this).index();

            if (!isAnimating) {
                doMotion(count);
                stopMotion();
            }

            return false;
        }
    });

    //슬라이드 정지
    $slideStopTrigger.on({
    	click : function() {
    		stopMotion();
    		return false;
    	}
    });

    //포커스
    $elem.find('a').on({
    	focus : function() {
    		stopMotion();
    	},
    	blur : function() {
    		startMotion();
    	},
    	mouseenter : function() {
    		stopMotion();
    	},
    	mouseleave : function() {
    		startMotion();
    	}
    });

    $(window).onOrientationChange = function() {
    	switch(window.orientation) {
    		case 0 :
    			init();
    			break;
    		case 90 : 
    			init();
    			break; 
    	}
    };

    initialize();
}

//퇴직연금시뮬레이션
var l = 587; //드래그 width
var valTime;

var rangeArr = new Array([20, 60, 1], [0, 30000, 50], [50, 80, 1], [50, 110, 1], [0, 10, 0.1], [0, 1000, 2], [20, 60, 1], [0, 10, 0.1], [0, 1000, 5], [0, 500, 1], [0, 500, 1], [0, 1000, 2], [0, 20, 0.1], [0, 1000, 2], [0, 1000, 2]);
var spaceArr = new Array([1,50,1,1,0.1],[2,1,0.1],[5,1,1,2,0.1],[2,2])

var rangeArr2 = new Array([0, 1000], [20, 60], [0, 10]);

var rangeArr3 = new Array([0, 1000], [0, 500], [0, 500], [0, 1000], [0, 20]);

var rangeArr4 = new Array([0, 1000], [0, 1000]);
function oldagePension(){
	$(".questionWrap .searchBlockOuter .searchBlock").each(function(i){
		var slider = $(this).find(".pullLeft .searchBar > div").slider({
			range: "min", min: rangeArr[i][0], max: rangeArr[i][1], values: rangeArr[i][0], step:rangeArr[i][2], slide: function( event, ui ) {
				$(this).parents(".searchBlock").find(".pullRight .condiResult input").val( ui.value);
			}
		});

		$(this).find('.pullRight input').blur(function(){
			//최소 0 최대값 1
			var min = rangeArr[i][0];//rangeValue(currentStep, current, 0);
			var max = rangeArr[i][1];//rangeValue(currentStep, current, 1);

			if($(this).val().length >= 1){
				if($(this).val() < min){
					$(this).val(min);
				}else if($(this).val() > max){
					$(this).val(max);
				}
			};
			
			//drag 위치 조정
			slider.slider("value", $(this).val());
		});

		$(this).find('.pullRight input').on('propertychange input', function(){
			//현재 단계
			var currentStep = $(this).parent().parent().parent().parent().parent().index();
			//현재 스크롤
			var current = $(this).parent().parent().parent().index();
			//radio 체크
			var radioChk = $(this).parent().parent().parent().parent().index();

			if(currentStep == 1 && radioChk == 4){
				current++;
			}else if(currentStep == 2 && radioChk == 4){
				current++;
			}else if(currentStep == 2 && radioChk == 5){
				current += 2;
			};

			//최소 0 최대값 1
			var min = rangeArr[i][0];//rangeValue(currentStep, current, 0);
			var max = rangeArr[i][1];//rangeValue(currentStep, current, 1);

			if($(this).val().length >= 2){
				if($(this).val() < min && $(this).val().length >= $(this).attr("maxlength")){
					$(this).val(min);
				}else if($(this).val() > max){
					$(this).val(max);
				}
			};

			//숫자 간격 체크
			var currentVal;
			var $this = $(this);
			
			clearTimeout(valTime);

			valTime = setTimeout(function(){
				if(spaceArr[currentStep][current] > 1){
					
					currentVal = Math.round($this.val() / spaceArr[currentStep][current]) * spaceArr[currentStep][current];

					$this.val(currentVal);

					var chk = parseInt(($this.val() - min) / (max - min) * l);

					$this.parent().parent().parent().find(".pullLeft").find(".searchL").css("width", chk + "px");
					$this.parent().parent().parent().find(".pullLeft").find(".searchL").find("a").css("left", chk + "px");
				};
			}, 1000);
			
			//drag 위치 조정
			slider.slider("value", $(this).val())
		});
	});
};

var pensionRangeArr = new Array([20, 60, 1], [0, 1000, 5], [5, 30, 1], [0, 10, 0.1], [0, 10, 0.1], [0, 20, 0.1], [20, 60, 1]);
//var pensionRangeArr1 = new Array([0, 10], [0, 10], [0, 20], [20, 60]);
var pensionSpaceArr = new Array([1,5,1],[0.1,0.1,0.1,1])

function pension(){
	$(".questionWrap .searchBlockOuter .searchBlock").each(function(i){
		var slider = $(this).find(".pullLeft .searchBar > div").slider({
			range: "min", min: pensionRangeArr[i][0], max: pensionRangeArr[i][1], values: pensionRangeArr[i][0], step:pensionRangeArr[i][2], slide: function( event, ui ) {
				$(this).parents(".searchBlock").find(".pullRight .condiResult input").val( ui.value);
			}
		});

		$(this).find('.pullRight input').blur(function(){
			//최소 0 최대값 1
			var min = pensionRangeArr[i][0];//rangeValue(currentStep, current, 0);
			var max = pensionRangeArr[i][1];//rangeValue(currentStep, current, 1);

			if($(this).val().length >= 1){
				if($(this).val() < min){
					$(this).val(min);
				}else if($(this).val() > max){
					$(this).val(max);
				}
			};
			
			//drag 위치 조정
			slider.slider("value", $(this).val());
		});

		$(this).find('.pullRight input').on('propertychange input', function(){
			//현재 단계
			var currentStep = $(this).parent().parent().parent().parent().parent().index();
			//현재 스크롤
			var current = $(this).parent().parent().parent().index();
			//radio 체크
			var radioChk = $(this).parent().parent().parent().parent().index();

			if(currentStep == 1 && radioChk == 4){
				current++;
			}else if(currentStep == 2 && radioChk == 4){
				current++;
			}else if(currentStep == 2 && radioChk == 5){
				current += 2;
			};

			//최소 0 최대값 1
			var min = pensionRangeArr[i][0];//rangeValue(currentStep, current, 0);
			var max = pensionRangeArr[i][1];//rangeValue(currentStep, current, 1);

			if($(this).val().length >= 2){
				if($(this).val() < min && $(this).val().length >= $(this).attr("maxlength")){
					$(this).val(min);
				}else if($(this).val() > max){
					$(this).val(max);
				}
			};

			//숫자 간격 체크
			var currentVal;
			var $this = $(this);
			
			clearTimeout(valTime);

			valTime = setTimeout(function(){
				if(pensionSpaceArr[currentStep][current] > 1){
					
					currentVal = Math.round($this.val() / spaceArr[currentStep][current]) * spaceArr[currentStep][current];

					$this.val(currentVal);

					var chk = parseInt(($this.val() - min) / (max - min) * l);

					$this.parent().parent().parent().find(".pullLeft").find(".searchL").css("width", chk + "px");
					$this.parent().parent().parent().find(".pullLeft").find(".searchL").find("a").css("left", chk + "px");
				};
			}, 1000);
			
			//drag 위치 조정
			slider.slider("value", $(this).val())
		});
	});
};

function rangeValue(chk1, chk2, chk3){
	var chk;
	
	if(chk1 == 0){
		chk = rangeArr[chk2][chk3];
	}else if(chk1 == 1){
		chk = rangeArr2[chk2][chk3];
	}else if(chk1 == 2){
		chk = rangeArr3[chk2][chk3];
	}else if(chk1 == 3){
		chk = rangeArr4[chk2][chk3];
	};
	
	return chk;
};

function pensionValue(chk1, chk2, chk3){
	var chk;
	
	if(chk1 == 0){
		chk = pensionRangeArr[chk2][chk3];
	}else if(chk1 == 1){
		chk = pensionRangeArr1[chk2][chk3];
	}else if(chk1 == 2){
		chk = rangeArr3[chk2][chk3];
	}else if(chk1 == 3){
		chk = rangeArr4[chk2][chk3];
	};
	
	return chk;
};

function inputVal(min, max, chk){
	var val = parseInt((chk / l) * (max - min) + min);

	return val;
};

function inputValPoint(min, max, chk){
	var val = (chk / l) * (max - min) + min;

	val = val.toFixed(1);

	return val;
};