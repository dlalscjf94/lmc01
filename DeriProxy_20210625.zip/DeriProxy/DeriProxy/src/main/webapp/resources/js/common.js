//자문사 검색 팝업
function popSearch() {

	window.open('/search_keyword','popup','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=700');
	
}
//종목 검색 팝업
function popStockSearch() {

	window.open('/market/stock','popup','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=660');
	
}
//마켓 검색 팝업
function popMarketSearch(viewtarget) {

	window.open('/market/pop?target='+viewtarget,'popup','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=yes,resizable=yes,width=600,height=660');
	
}