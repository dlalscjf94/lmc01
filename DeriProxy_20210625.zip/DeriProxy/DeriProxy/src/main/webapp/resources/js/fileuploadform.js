var selectedFiles;
var filecnt = 0;
var maxfilecnt = 1;
function randomString() {
	return "";
}

function filedeleteClick() {
	if (filecnt < 1) {
        alert('등록한 파일이 없습니다.');
        return;
    } else {
        if ($("input:checkbox[name=btndel]:checked").length <= 0) {
            alert('선택된 파일이 없습니다.');
            return;
        } else {
            $("input:checkbox[name=btndel]:checked").each(function () {
                filecnt = parseInt(filecnt) - 1;
                //data.delete($(this).val());
                map.remove($(this).val());
                $("#" + $(this).val()).remove();
                if (filecnt == 0) $("#box").html("<span class='default'>파일을 드래그앤 드롭으로 첨부할 수 있습니다.</span><ul></ul>");
            })
        }
    }
}
$(document).ready(function () {
    var box;
    box = document.getElementById("box");
    
    if ( box == null ) return;
    
    box.addEventListener("dragenter", function (e) {
        e.stopPropagation();
        e.preventDefault();
    }, false);
    box.addEventListener("dragover", function (e) {
        e.stopPropagation();
        e.preventDefault();
    }, false);
    box.addEventListener("drop", function (e) {
        
    	if ( filecnt < maxfilecnt ) {
    	
	    	e.stopPropagation();
	        e.preventDefault();
	
	        if (filecnt == 0) $("#box").html("<ul></ul>");
	
	        selectedFiles = e.dataTransfer.files
	
	        for (var i = 0; i < selectedFiles.length; i++) {
	
	            filecnt = parseInt(filecnt) + 1;
	            var filename = selectedFiles[i].name.replace('.', '') + randomString();
	
	            map.put(filename, selectedFiles[i]);
	           	
	            $("#box > ul").append("<li id='" + filename + "' ><span class='chk'><input type='checkbox' name='btndel' value='" + filename + "'></span> <span class='name'>" + selectedFiles[i].name + "</span></li>"); //<span class='size'>" + selectedFiles[i].size + "</span>
	        }
    	} else {
    		alert(maxfilecnt +'개 만 등록 가능합니다.');
    	}
        console.log(map);
    }, false);

    
    
    
    $("#filedelete").click(function () {
    	filedeleteClick();
    });
    $("#upload").click(function () {
        if (filecnt < 1) {
            alert("파일을 등록해주세요.");
            return false;
        } else {
            var data = new FormData();
            $(map.keys()).each(function (id) {
                alert(this + " " + map.get(this));
                data.append(this, map.get(this));
            });
            $.ajax({
                type: "POST",
                //비하인드 호출 핸들러 주소
                url: "FileUploadPro.ashx",
                contentType: false,
                processData: false,
                data: data,
                success: function (result) {
                    alert(result);
                    map.clear();
                    $("input:checkbox[name=btndel]").each(function () {
                        this.checked = true;
                    });
                    $("#filedelete").click();
                },
                error: function () {
                    alert("There was error uploading files!");
                }
            });
        }
    });

    $("#files-upload").change(function () {

        var files = this.files;

        if (filecnt == 0) $("#box").html("<ul></ul>");

        for (var i = 0, il = files.length; i < il; i++) {

            file = files[i];
            filecnt = parseInt(filecnt) + 1;

            var filename = file.name.replace('.', '') + randomString();
            //data.append(filename, file);
            map.put(filename, file);
            $("#box > ul").append("<li id='" + filename + "' ><span class='chk'><input type='checkbox' name='btndel' value='" + filename + "'></span><span class='name'>" + file.name + "</span><span class='size'>" + file.size + "</span></li>");
        };
    });
    $("#fileadd").click(function () {
        $("#files-upload").click();
    });
});